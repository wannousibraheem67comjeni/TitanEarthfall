(()=>{var Df=Object.defineProperty;var kf=(i,t)=>{for(var e in t)Df(i,e,{get:t[e],enumerable:!0})};var Jr={ar:{title:"\u0625\u064A\u0628\u0648\u062A: \u0645\u0637\u0627\u0631\u062F\u0629 \u0627\u0644\u0630\u0647\u0628",subtitle:"\u0637\u0627\u0631\u062F \u063A\u0644\u064A\u062A\u0634 \u0648\u0627\u0633\u062A\u0639\u062F \u0630\u0647\u0628\u0643!",loading:"\u062C\u0627\u0631\u064A \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u2026",tapToStart:"\u0627\u0644\u0645\u0633 \u0644\u0644\u0628\u062F\u0621",play:"\u0627\u0644\u0639\u0628",gold:"\u0630\u0647\u0628",gems:"\u062C\u0648\u0627\u0647\u0631",batteries:"\u0628\u0637\u0627\u0631\u064A\u0627\u062A",headstart:"\u0627\u0646\u0637\u0644\u0627\u0642\u0629 \u0635\u0627\u0631\u0648\u062E\u064A\u0629",vault:"\u062E\u0632\u0646\u0629",score:"\u0627\u0644\u0646\u0642\u0627\u0637",best:"\u0627\u0644\u0623\u0641\u0636\u0644",distance:"\u0627\u0644\u0645\u0633\u0627\u0641\u0629",m:"\u0645",multiplier:"\u0627\u0644\u0645\u0636\u0627\u0639\u0641",daily:"\u064A\u0648\u0645\u064A",missions:"\u0627\u0644\u0645\u0647\u0627\u0645",wheel:"\u0627\u0644\u0639\u062C\u0644\u0629",gift:"\u0647\u062F\u064A\u0629",vaults:"\u0627\u0644\u062E\u0632\u0627\u0626\u0646",shop:"\u0627\u0644\u0645\u062A\u062C\u0631",settings:"\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",characters:"\u0627\u0644\u0634\u062E\u0635\u064A\u0627\u062A",build:"\u0627\u0644\u0628\u0646\u0627\u0621",worlds:"\u0627\u0644\u0639\u0648\u0627\u0644\u0645",upgrades:"\u0627\u0644\u062A\u0637\u0648\u064A\u0631\u0627\u062A",profile:"\u0627\u0644\u0645\u0644\u0641",close:"\u0625\u063A\u0644\u0627\u0642",back:"\u0631\u062C\u0648\u0639",ok:"\u062D\u0633\u0646\u0627\u064B",yes:"\u0646\u0639\u0645",no:"\u0644\u0627",cancel:"\u0625\u0644\u063A\u0627\u0621",free:"\u0645\u062C\u0627\u0646\u0627\u064B",claim:"\u0627\u0633\u062A\u0644\u0645",claimed:"\u062A\u0645 \u0627\u0644\u0627\u0633\u062A\u0644\u0627\u0645",open:"\u0627\u0641\u062A\u062D",buy:"\u0634\u0631\u0627\u0621",select:"\u0627\u062E\u062A\u0631",selected:"\u0645\u064F\u062E\u062A\u0627\u0631",locked:"\u0645\u0642\u0641\u0644",owned:"\u0645\u0645\u0644\u0648\u0643",equip:"\u0627\u0631\u062A\u062F\u0650",equipped:"\u0645\u064F\u0631\u062A\u062F\u0649",unlock:"\u0627\u0641\u062A\u062D",max:"\u0627\u0644\u0623\u0642\u0635\u0649",level:"\u0627\u0644\u0645\u0633\u062A\u0648\u0649",duration:"\u0627\u0644\u0645\u062F\u0629",sec:"\u062B",h:"\u0633",min:"\u062F",pu_magnet:"\u0645\u063A\u0646\u0627\u0637\u064A\u0633",pu_shield:"\u062E\u0648\u0630\u0629 \u0627\u0644\u062F\u0631\u0639",pu_jet:"\u0627\u0644\u0637\u0627\u0626\u0631\u0629 \u0627\u0644\u0646\u0641\u0627\u062B\u0629",pu_double:"\u0630\u0647\u0628 \u0645\u0636\u0627\u0639\u0641",pu_magnet_d:"\u064A\u062C\u0630\u0628 \u0643\u0644 \u0633\u0628\u0627\u0626\u0643 \u0627\u0644\u0630\u0647\u0628 \u0627\u0644\u0642\u0631\u064A\u0628\u0629",pu_shield_d:"\u064A\u062D\u0645\u064A\u0643 \u0645\u0646 \u0627\u0635\u0637\u062F\u0627\u0645 \u0648\u0627\u062D\u062F",pu_jet_d:"\u062D\u0644\u0651\u0642 \u0641\u0648\u0642 \u0627\u0644\u0639\u0648\u0627\u0626\u0642 \u0648\u0627\u062C\u0645\u0639 \u0630\u0647\u0628 \u0627\u0644\u0633\u0645\u0627\u0621",pu_double_d:"\u0643\u0644 \u0633\u0628\u064A\u0643\u0629 \u062A\u0633\u0627\u0648\u064A \u0627\u062B\u0646\u062A\u064A\u0646",paused:"\u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A",resume:"\u0645\u062A\u0627\u0628\u0639\u0629",home:"\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",restart:"\u0625\u0639\u0627\u062F\u0629",revive:"\u0625\u0646\u0642\u0627\u0630!",reviveQ:"\u0647\u0644 \u062A\u0631\u064A\u062F \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629\u061F",reviveWith:"\u0627\u0633\u062A\u062E\u062F\u0645 {n}",skip:"\u062A\u062E\u0637\u064A",results:"\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u062C\u0648\u0644\u0629",newBest:"\u0631\u0642\u0645 \u0642\u064A\u0627\u0633\u064A \u062C\u062F\u064A\u062F!",goldCollected:"\u0627\u0644\u0630\u0647\u0628 \u0627\u0644\u0645\u062C\u0645\u0648\u0639",doubleIt:"\u0636\u0627\u0639\u0641\u0647 \u0628\u0640 {n}",collect:"\u0627\u0633\u062A\u0644\u0627\u0645",playAgain:"\u0627\u0644\u0639\u0628 \u0645\u062C\u062F\u062F\u0627\u064B",tutJump:"\u0627\u0633\u062D\u0628 \u0644\u0644\u0623\u0639\u0644\u0649 \u0644\u0644\u0642\u0641\u0632",tutSlide:"\u0627\u0633\u062D\u0628 \u0644\u0644\u0623\u0633\u0641\u0644 \u0644\u0644\u0627\u0646\u0632\u0644\u0627\u0642",tutLane:"\u0627\u0633\u062D\u0628 \u064A\u0645\u064A\u0646\u0627\u064B \u0648\u064A\u0633\u0627\u0631\u0627\u064B \u0644\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0645\u0633\u0627\u0631",tutGo:"\u0627\u062C\u0645\u0639 \u0627\u0644\u0630\u0647\u0628 \u0648\u0637\u0627\u0631\u062F \u063A\u0644\u064A\u062A\u0634!",thiefTaunt:"\u0647\u064A\u0647\u064A\u0647\u064A! \u0627\u0644\u0630\u0647\u0628 \u0644\u064A!",thiefEscape:"\u0644\u0646 \u062A\u0645\u0633\u0643\u0646\u064A \u064A\u0627 \u0625\u064A\u0628\u0648\u062A!",bossIncoming:"\u0634\u0627\u062D\u0646\u0629 \u063A\u0644\u064A\u062A\u0634 \u0642\u0627\u062F\u0645\u0629!",bossHint:"\u0627\u0631\u0643\u0644 \u0627\u0644\u0642\u0646\u0627\u0628\u0644 \u0627\u0644\u0632\u0631\u0642\u0627\u0621 \u0646\u062D\u0648 \u0627\u0644\u0634\u0627\u062D\u0646\u0629!",bossDefeated:"\u0647\u0632\u0645\u062A \u063A\u0644\u064A\u062A\u0634!",bossEscaped:"\u0647\u0631\u0628 \u063A\u0644\u064A\u062A\u0634\u2026",shieldBroken:"\u0627\u0646\u0643\u0633\u0631 \u0627\u0644\u062F\u0631\u0639!",useHeadstart:"\u0627\u0646\u0637\u0644\u0627\u0642\u0629 \u0635\u0627\u0631\u0648\u062E\u064A\u0629!",stumble:"\u0627\u0646\u062A\u0628\u0647!",buildHouse:"\u0627\u0628\u0646\u0650 \u0627\u0644\u0628\u064A\u062A",stage:"\u0627\u0644\u0645\u0631\u062D\u0644\u0629",built:"\u0645\u0628\u0646\u064A",next:"\u0627\u0644\u062A\u0627\u0644\u064A",complete:"\u0645\u0643\u062A\u0645\u0644!",houseOf:"\u0628\u064A\u062A {w}",houseDone:"\u0627\u0643\u062A\u0645\u0644 \u0627\u0644\u0628\u064A\u062A! \u062A\u0645 \u0641\u062A\u062D {c} \u0648{w}",needMore:"\u062A\u062D\u062A\u0627\u062C \u0627\u0644\u0645\u0632\u064A\u062F",notEnough:"\u0631\u0635\u064A\u062F \u063A\u064A\u0631 \u0643\u0627\u0641\u064D",getMore:"\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0632\u064A\u062F",multiplierInfo:"\u0643\u0644 \u0645\u0631\u062D\u0644\u0629 \u0628\u0646\u0627\u0621 \u062A\u0632\u064A\u062F \u0645\u0636\u0627\u0639\u0641 \u0627\u0644\u0646\u0642\u0627\u0637 +1",worldLocked:"\u0623\u0643\u0645\u0644 \u0628\u064A\u062A {w} \u0644\u0641\u062A\u062D \u0647\u0630\u0627 \u0627\u0644\u0639\u0627\u0644\u0645",currentWorld:"\u0627\u0644\u0639\u0627\u0644\u0645 \u0627\u0644\u062D\u0627\u0644\u064A",go:"\u0627\u0646\u0637\u0644\u0642",unlockByHouse:"\u064A\u064F\u0641\u062A\u062D \u0639\u0646\u062F \u0625\u0643\u0645\u0627\u0644 \u0628\u064A\u062A {w}",unlockByGems:"\u0627\u0641\u062A\u062D \u0628\u0640 {n} \u062C\u0648\u0647\u0631\u0629",perk:"\u0627\u0644\u0645\u064A\u0632\u0629",perk_magnet:"\u0645\u063A\u0646\u0627\u0637\u064A\u0633 \u0623\u0637\u0648\u0644",perk_shield:"\u062F\u0631\u0639 \u0623\u0637\u0648\u0644",perk_jet:"\u0637\u064A\u0631\u0627\u0646 \u0623\u0637\u0648\u0644",perk_double:"\u0645\u0636\u0627\u0639\u0641\u0629 \u0623\u0637\u0648\u0644",perk_score:"\u0646\u0642\u0627\u0637 \u0623\u0643\u062B\u0631",skins:"\u0627\u0644\u0623\u0632\u064A\u0627\u0621",vaultSlots:"\u062E\u0627\u0646\u0627\u062A \u0627\u0644\u062E\u0632\u0627\u0626\u0646",emptySlot:"\u062E\u0627\u0646\u0629 \u0641\u0627\u0631\u063A\u0629",unlocking:"\u062C\u0627\u0631\u064A \u0627\u0644\u0641\u062A\u062D",openNow:"\u0627\u0641\u062A\u062D \u0627\u0644\u0622\u0646",startUnlock:"\u0627\u0628\u062F\u0623 \u0627\u0644\u0641\u062A\u062D",freeVaultIn:"\u062E\u0632\u0646\u0629 \u0645\u062C\u0627\u0646\u064A\u0629 \u0628\u0639\u062F {t}",freeVaultReady:"\u062E\u0632\u0646\u0629 \u0645\u062C\u0627\u0646\u064A\u0629 \u062C\u0627\u0647\u0632\u0629!",buyVault:"\u0627\u0634\u062A\u0631\u0650",odds:"\u0646\u0633\u0628 \u0627\u0644\u062D\u0638",slotsFull:"\u062E\u0627\u0646\u0627\u062A \u0627\u0644\u062E\u0632\u0627\u0626\u0646 \u0645\u0645\u062A\u0644\u0626\u0629",vaultFound:"\u0648\u062C\u062F\u062A \u062E\u0632\u0646\u0629!",contains:"\u064A\u062D\u062A\u0648\u064A {n} \u062C\u0648\u0627\u0626\u0632",spin:"\u0623\u062F\u0631",spinFree:"\u062F\u0648\u0631\u0629 \u0645\u062C\u0627\u0646\u064A\u0629",spinFor:"\u0623\u062F\u0631 \u0628\u0640 {n}",nextSpin:"\u0627\u0644\u062F\u0648\u0631\u0629 \u0627\u0644\u0645\u062C\u0627\u0646\u064A\u0629 \u0628\u0639\u062F {t}",jackpot:"\u0627\u0644\u062C\u0627\u0626\u0632\u0629 \u0627\u0644\u0643\u0628\u0631\u0649!",dailyTitle:"\u0627\u0644\u0645\u0643\u0627\u0641\u0622\u062A \u0627\u0644\u064A\u0648\u0645\u064A\u0629",day:"\u0627\u0644\u064A\u0648\u0645 {n}",comeBack:"\u0639\u062F \u063A\u062F\u0627\u064B \u0644\u0644\u0645\u0643\u0627\u0641\u0623\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629",giftReady:"\u0647\u062F\u064A\u0629 \u0645\u062C\u0627\u0646\u064A\u0629! +{n} \u0630\u0647\u0628",giftIn:"\u0627\u0644\u0647\u062F\u064A\u0629 \u0628\u0639\u062F {t}",missionsTitle:"\u0627\u0644\u0645\u0647\u0627\u0645",missionDone:"\u0627\u0643\u062A\u0645\u0644\u062A \u0627\u0644\u0645\u0647\u0645\u0629!",inOneRun:"\u0641\u064A \u062C\u0648\u0644\u0629 \u0648\u0627\u062D\u062F\u0629",m_gold:"\u0627\u062C\u0645\u0639 {n} \u0633\u0628\u064A\u0643\u0629 \u0630\u0647\u0628",m_dist:"\u0627\u0631\u0643\u0636 {n} \u0645\u062A\u0631",m_jumps:"\u0627\u0642\u0641\u0632 {n} \u0645\u0631\u0629",m_slides:"\u0627\u0646\u0632\u0644\u0642 {n} \u0645\u0631\u0629",m_pu_magnet:"\u0627\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0645\u063A\u0646\u0627\u0637\u064A\u0633 {n} \u0645\u0631\u0627\u062A",m_pu_jet:"\u0627\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0637\u0627\u0626\u0631\u0629 {n} \u0645\u0631\u0627\u062A",m_pu_shield:"\u0627\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u062F\u0631\u0639 {n} \u0645\u0631\u0627\u062A",m_pu_double:"\u0627\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0645\u0636\u0627\u0639\u0641 {n} \u0645\u0631\u0627\u062A",m_bosses:"\u0627\u0647\u0632\u0645 \u0634\u0627\u062D\u0646\u0629 \u063A\u0644\u064A\u062A\u0634 {n} \u0645\u0631\u0629",m_emps:"\u0627\u0631\u0643\u0644 {n} \u0642\u0646\u0628\u0644\u0629 \u0632\u0631\u0642\u0627\u0621",m_roofs:"\u0627\u0631\u0643\u0636 \u0641\u0648\u0642 {n} \u0634\u0627\u062D\u0646\u0629",m_runs:"\u0627\u0644\u0639\u0628 {n} \u062C\u0648\u0644\u0627\u062A",m_gemsPicked:"\u0627\u062C\u0645\u0639 {n} \u062C\u0648\u0627\u0647\u0631 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0631\u0643\u0636",m_lanes:"\u063A\u064A\u0651\u0631 \u0627\u0644\u0645\u0633\u0627\u0631 {n} \u0645\u0631\u0629",tabGems:"\u062C\u0648\u0627\u0647\u0631",tabGold:"\u0630\u0647\u0628",tabOffers:"\u0639\u0631\u0648\u0636",tabItems:"\u0623\u062F\u0648\u0627\u062A",p_starter_pack:"\u062D\u0632\u0645\u0629 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",p_starter_pack_d:"300 \u062C\u0648\u0647\u0631\u0629 + 8000 \u0630\u0647\u0628 + 5 \u0628\u0637\u0627\u0631\u064A\u0627\u062A + 3 \u0627\u0646\u0637\u0644\u0627\u0642\u0627\u062A",p_gold_doubler:"\u0645\u0636\u0627\u0639\u0641 \u0627\u0644\u0630\u0647\u0628 \u0627\u0644\u062F\u0627\u0626\u0645",p_gold_doubler_d:"\u0643\u0644 \u0627\u0644\u0630\u0647\u0628 \u0627\u0644\u0630\u064A \u062A\u062C\u0645\u0639\u0647 \xD72 \u0644\u0644\u0623\u0628\u062F",p_ebot_club:"\u0646\u0627\u062F\u064A \u0625\u064A\u0628\u0648\u062A",p_ebot_club_d:"\u0627\u0634\u062A\u0631\u0627\u0643 \u0634\u0647\u0631\u064A: 60 \u062C\u0648\u0647\u0631\u0629 + 2 \u0628\u0637\u0627\u0631\u064A\u0629 \u064A\u0648\u0645\u064A\u0627\u064B",tag_popular:"\u0627\u0644\u0623\u0643\u062B\u0631 \u0634\u0639\u0628\u064A\u0629",tag_value:"\u0642\u064A\u0645\u0629 \u0631\u0627\u0626\u0639\u0629",tag_best:"\u0623\u0641\u0636\u0644 \u0639\u0631\u0636",tag_starter:"\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629",tag_forever:"\u0644\u0644\u0623\u0628\u062F",tag_club:"\u0627\u0634\u062A\u0631\u0627\u0643",purchased:"\u062A\u0645 \u0627\u0644\u0634\u0631\u0627\u0621",active:"\u0645\u0641\u0639\u0651\u0644",restore:"\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0627\u062A",restored:"\u062A\u0645\u062A \u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0627\u062A",purchaseOk:"\u062A\u0645 \u0627\u0644\u0634\u0631\u0627\u0621 \u0628\u0646\u062C\u0627\u062D!",purchaseFail:"\u062A\u0639\u0630\u0651\u0631 \u0625\u062A\u0645\u0627\u0645 \u0627\u0644\u0634\u0631\u0627\u0621",purchaseCancel:"\u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0634\u0631\u0627\u0621",purchasePending:"\u0627\u0644\u062F\u0641\u0639 \u0642\u064A\u062F \u0627\u0644\u0645\u0639\u0627\u0644\u062C\u0629\u060C \u0633\u062A\u0635\u0644\u0643 \u0627\u0644\u062C\u0627\u0626\u0632\u0629 \u0639\u0646\u062F \u0627\u0644\u062A\u0623\u0643\u064A\u062F",storeUnavailable:"\u0645\u062A\u062C\u0631 Google Play \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062D\u0627\u0644\u064A\u0627\u064B",demoStore:"\u0646\u0633\u062E\u0629 \u0627\u0644\u0648\u064A\u0628: \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0627\u062A \u062A\u062C\u0631\u064A\u0628\u064A\u0629 \u0628\u062F\u0648\u0646 \u062F\u0641\u0639 \u062D\u0642\u064A\u0642\u064A. \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u062D\u0642\u064A\u0642\u064A \u0639\u0628\u0631 Google Play \u0641\u064A \u062A\u0637\u0628\u064A\u0642 \u0623\u0646\u062F\u0631\u0648\u064A\u062F.",demoConfirm:"\u0634\u0631\u0627\u0621 \u062A\u062C\u0631\u064A\u0628\u064A (\u0628\u062F\u0648\u0646 \u062F\u0641\u0639) \u0644\u0640 {p}\u061F",clubClaim:"\u062C\u0627\u0626\u0632\u0629 \u0627\u0644\u0646\u0627\u062F\u064A \u0627\u0644\u064A\u0648\u0645\u064A\u0629",clubActive:"\u0639\u0636\u0648 \u0641\u064A \u0646\u0627\u062F\u064A \u0625\u064A\u0628\u0648\u062A",perMonth:"/\u0634\u0647\u0631\u064A\u0627\u064B",sound:"\u0627\u0644\u0645\u0624\u062B\u0631\u0627\u062A",music:"\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649",vibration:"\u0627\u0644\u0627\u0647\u062A\u0632\u0627\u0632",language:"\u0627\u0644\u0644\u063A\u0629",quality:"\u0627\u0644\u0631\u0633\u0648\u0645\u064A\u0627\u062A",qLow:"\u0645\u0646\u062E\u0641\u0636\u0629",qHigh:"\u0639\u0627\u0644\u064A\u0629",on:"\u062A\u0634\u063A\u064A\u0644",off:"\u0625\u064A\u0642\u0627\u0641",privacy:"\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",resetProgress:"\u0625\u0639\u0627\u062F\u0629 \u0636\u0628\u0637 \u0627\u0644\u062A\u0642\u062F\u0645",resetConfirm:"\u0633\u064A\u062A\u0645 \u062D\u0630\u0641 \u0643\u0644 \u0627\u0644\u062A\u0642\u062F\u0645 (\u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0627\u062A \u0627\u0644\u0645\u0645\u0644\u0648\u0643\u0629 \u062A\u0628\u0642\u0649 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629). \u0645\u062A\u0623\u0643\u062F\u061F",rate:"\u0642\u064A\u0651\u0645 \u0627\u0644\u0644\u0639\u0628\u0629",version:"\u0627\u0644\u0625\u0635\u062F\u0627\u0631",stats:"\u0627\u0644\u0625\u062D\u0635\u0627\u0626\u064A\u0627\u062A",st_runs:"\u0627\u0644\u062C\u0648\u0644\u0627\u062A",st_dist:"\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0645\u0633\u0627\u0641\u0629",st_gold:"\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0630\u0647\u0628",st_bosses:"\u0647\u0632\u0627\u0626\u0645 \u063A\u0644\u064A\u062A\u0634",st_best:"\u0623\u0641\u0636\u0644 \u0646\u0642\u0627\u0637",st_bestDist:"\u0623\u0637\u0648\u0644 \u0645\u0633\u0627\u0641\u0629",records:"\u0623\u0641\u0636\u0644 \u0627\u0644\u062C\u0648\u0644\u0627\u062A",privacyText:"\u0625\u064A\u0628\u0648\u062A: \u0645\u0637\u0627\u0631\u062F\u0629 \u0627\u0644\u0630\u0647\u0628 \u0644\u0627 \u062A\u062C\u0645\u0639 \u0623\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0634\u062E\u0635\u064A\u0629. \u064A\u064F\u062D\u0641\u0638 \u062A\u0642\u062F\u0645\u0643 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0643 \u0641\u0642\u0637. \u062A\u062A\u0645 \u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 Google Play \u0648\u062A\u062E\u0636\u0639 \u0644\u0633\u064A\u0627\u0633\u0629 \u062E\u0635\u0648\u0635\u064A\u0629 Google. \u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0648\u0644\u0627 \u062A\u062A\u0628\u0639.",reward:"\u0645\u0643\u0627\u0641\u0623\u0629!",youGot:"\u062D\u0635\u0644\u062A \u0639\u0644\u0649",newChar:"\u0634\u062E\u0635\u064A\u0629 \u062C\u062F\u064A\u062F\u0629!",newWorld:"\u0639\u0627\u0644\u0645 \u062C\u062F\u064A\u062F!",confirmBuy:"\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0634\u0631\u0627\u0621",costIs:"\u0627\u0644\u062A\u0643\u0644\u0641\u0629: {c}"},en:{title:"EBOT: Gold Chase",subtitle:"Chase Glitch and win your gold back!",loading:"Loading\u2026",tapToStart:"Tap to start",play:"PLAY",gold:"Gold",gems:"Gems",batteries:"Batteries",headstart:"Rocket Start",vault:"Vault",score:"Score",best:"Best",distance:"Distance",m:"m",multiplier:"Multiplier",daily:"Daily",missions:"Missions",wheel:"Wheel",gift:"Gift",vaults:"Vaults",shop:"Shop",settings:"Settings",characters:"Characters",build:"Build",worlds:"Worlds",upgrades:"Upgrades",profile:"Profile",close:"Close",back:"Back",ok:"OK",yes:"Yes",no:"No",cancel:"Cancel",free:"FREE",claim:"Claim",claimed:"Claimed",open:"Open",buy:"Buy",select:"Select",selected:"Selected",locked:"Locked",owned:"Owned",equip:"Equip",equipped:"Equipped",unlock:"Unlock",max:"MAX",level:"Level",duration:"Duration",sec:"s",h:"h",min:"m",pu_magnet:"Magnet",pu_shield:"Shield Helmet",pu_jet:"Jet Plane",pu_double:"Double Gold",pu_magnet_d:"Pulls in all nearby gold bars",pu_shield_d:"Protects you from one crash",pu_jet_d:"Fly over obstacles and grab sky gold",pu_double_d:"Every gold bar counts twice",paused:"Paused",resume:"Resume",home:"Home",restart:"Restart",revive:"Revive!",reviveQ:"Keep running?",reviveWith:"Use {n}",skip:"Skip",results:"Run results",newBest:"New high score!",goldCollected:"Gold collected",doubleIt:"Double for {n}",collect:"Collect",playAgain:"Play again",tutJump:"Swipe up to jump",tutSlide:"Swipe down to slide",tutLane:"Swipe left/right to switch lanes",tutGo:"Grab the gold and chase Glitch!",thiefTaunt:"Hehehe! The gold is mine!",thiefEscape:"You'll never catch me, Ebot!",bossIncoming:"Glitch's van is coming!",bossHint:"Kick the blue bombs back at the van!",bossDefeated:"Glitch defeated!",bossEscaped:"Glitch got away\u2026",shieldBroken:"Shield broken!",useHeadstart:"Rocket start!",stumble:"Careful!",buildHouse:"Build house",stage:"Stage",built:"Built",next:"Next",complete:"Complete!",houseOf:"{w} house",houseDone:"House complete! Unlocked {c} and {w}",needMore:"Need more",notEnough:"Not enough",getMore:"Get more",multiplierInfo:"Every built stage adds +1 to your score multiplier",worldLocked:"Complete the {w} house to unlock",currentWorld:"Current world",go:"Go",unlockByHouse:"Unlocks with the {w} house",unlockByGems:"Unlock for {n} gems",perk:"Perk",perk_magnet:"Longer magnet",perk_shield:"Longer shield",perk_jet:"Longer jet",perk_double:"Longer double gold",perk_score:"More score",skins:"Outfits",vaultSlots:"Vault slots",emptySlot:"Empty slot",unlocking:"Unlocking",openNow:"Open now",startUnlock:"Start unlock",freeVaultIn:"Free vault in {t}",freeVaultReady:"Free vault ready!",buyVault:"Buy",odds:"Drop rates",slotsFull:"Vault slots are full",vaultFound:"Vault found!",contains:"Contains {n} rewards",spin:"SPIN",spinFree:"Free spin",spinFor:"Spin for {n}",nextSpin:"Free spin in {t}",jackpot:"JACKPOT!",dailyTitle:"Daily rewards",day:"Day {n}",comeBack:"Come back tomorrow for the next reward",giftReady:"Free gift! +{n} gold",giftIn:"Gift in {t}",missionsTitle:"Missions",missionDone:"Mission complete!",inOneRun:"in one run",m_gold:"Collect {n} gold bars",m_dist:"Run {n} m",m_jumps:"Jump {n} times",m_slides:"Slide {n} times",m_pu_magnet:"Use {n} magnets",m_pu_jet:"Use {n} jet planes",m_pu_shield:"Use {n} shields",m_pu_double:"Use {n} gold doublers",m_bosses:"Defeat Glitch's van {n} time(s)",m_emps:"Kick {n} blue bombs",m_roofs:"Run on top of {n} trucks",m_runs:"Play {n} runs",m_gemsPicked:"Pick up {n} gems while running",m_lanes:"Switch lanes {n} times",tabGems:"Gems",tabGold:"Gold",tabOffers:"Offers",tabItems:"Items",p_starter_pack:"Starter Pack",p_starter_pack_d:"300 gems + 8000 gold + 5 batteries + 3 rocket starts",p_gold_doubler:"Forever Gold Doubler",p_gold_doubler_d:"All gold you collect is doubled forever",p_ebot_club:"Ebot Club",p_ebot_club_d:"Monthly: 60 gems + 2 batteries every day",tag_popular:"Most popular",tag_value:"Great value",tag_best:"Best deal",tag_starter:"One time",tag_forever:"Forever",tag_club:"Subscription",purchased:"Purchased",active:"Active",restore:"Restore purchases",restored:"Purchases restored",purchaseOk:"Purchase successful!",purchaseFail:"Purchase could not be completed",purchaseCancel:"Purchase cancelled",purchasePending:"Payment is pending; you will get your reward once it is confirmed",storeUnavailable:"Google Play store is not available right now",demoStore:"Web version: purchases are a demo with no real payment. Real purchases use Google Play in the Android app.",demoConfirm:"Demo purchase (no payment) of {p}?",clubClaim:"Club daily reward",clubActive:"Ebot Club member",perMonth:"/month",sound:"Sound FX",music:"Music",vibration:"Vibration",language:"Language",quality:"Graphics",qLow:"Low",qHigh:"High",on:"On",off:"Off",privacy:"Privacy policy",resetProgress:"Reset progress",resetConfirm:"All progress will be erased (owned purchases can be restored). Are you sure?",rate:"Rate the game",version:"Version",stats:"Statistics",st_runs:"Runs",st_dist:"Total distance",st_gold:"Total gold",st_bosses:"Glitch defeats",st_best:"Best score",st_bestDist:"Longest run",records:"Top runs",privacyText:"EBOT: Gold Chase does not collect personal data. Your progress is stored only on your device. Purchases are processed by Google Play under Google's privacy policy. No ads, no tracking.",reward:"Reward!",youGot:"You got",newChar:"New character!",newWorld:"New world!",confirmBuy:"Confirm purchase",costIs:"Cost: {c}"}},Pi="ar";function Ko(i){Pi=Jr[i]?i:"ar";let t=document.documentElement;t.lang=Pi,t.dir=Pi==="ar"?"rtl":"ltr"}function Ii(){return Pi}function k(i,t){let e=(Jr[Pi]&&Jr[Pi][i])??Jr.en[i]??i;if(t)for(let n in t)e=e.split("{"+n+"}").join(t[n]);return e}function ye(i){return i?i[Pi]??i.en??"":""}function fe(i){return i=Math.floor(i),i.toLocaleString("en-US")}function Ke(i){return i=Math.floor(i),i>=1e6?(i/1e6).toFixed(i>=1e7?0:1).replace(/\.0$/,"")+"M":i>=1e4?(i/1e3).toFixed(i>=1e5?0:1).replace(/\.0$/,"")+"K":i.toLocaleString("en-US")}function jr(i){let t=Math.max(0,Math.ceil(i/1e3)),e=Math.floor(t/3600),n=Math.floor(t%3600/60),s=t%60;return e>0?`${e}${k("h")} ${n}${k("min")}`:n>0?`${n}${k("min")} ${s}${k("sec")}`:`${s}${k("sec")}`}var mu="ebot.goldchase.profile";function Kr(){return{v:2,created:Date.now(),gold:250,gems:10,batteries:2,headstart:1,char:"ebot",ownedChars:["ebot"],skins:{ebot:"classic"},ownedSkins:["ebot:classic"],upgrades:{magnet:0,shield:0,jet:0,double:0},houses:{city:0},world:"city",unlockedWorlds:["city"],vaults:[],woodNext:0,wheelNext:0,giftNext:0,daily:{day:0,last:""},missions:[],missionTotals:{},best:0,bestDist:0,records:[],stats:{runs:0,dist:0,gold:0,bosses:0,jumps:0,slides:0},iap:{tokens:[],starter:!1,doubler:!1,clubUntil:0,clubClaim:""},settings:{lang:null,sound:!0,music:!0,vibe:!0,quality:null},tutorialDone:!1}}function Uf(i){let t=Kr();for(let e in t)i[e]===void 0&&(i[e]=t[e]);for(let e of["upgrades","stats","iap","settings","daily"])i[e]=Object.assign({},t[e],i[e]);return i.v=2,i}function gu(){return typeof window<"u"&&window.EbotNative?window.EbotNative:null}function xu(){let i=null;try{i=localStorage.getItem(mu)}catch{}if(!i){let t=gu();try{t&&t.loadData&&(i=t.loadData())}catch{}}if(i)try{return Uf(JSON.parse(i))}catch{}return Kr()}var Qo=null;function _u(i){Qo||(Qo=setTimeout(()=>{Qo=null,Li(i)},50))}function Li(i){let t=JSON.stringify(i);try{localStorage.setItem(mu,t)}catch{}let e=gu();try{e&&e.saveData&&e.saveData(t)}catch{}}var pa={};kf(pa,{addVault:()=>ar,badges:()=>El,buildNextStage:()=>ll,buyDiamondVault:()=>pl,buySkin:()=>hl,buySteelVault:()=>fl,canAfford:()=>ir,changed:()=>me,charOwned:()=>$n,claimClub:()=>wl,claimDaily:()=>vl,claimGift:()=>_l,claimMission:()=>Ml,clubActive:()=>hs,clubClaimAvailable:()=>Sl,commitRunStats:()=>da,currentSkin:()=>ss,dailyAvailable:()=>ls,dailyIndex:()=>ua,ensureMissions:()=>yl,equipSkin:()=>oa,giftReady:()=>os,grant:()=>Be,houseComplete:()=>Eu,houseStage:()=>Tn,initProgress:()=>sl,isWorldUnlocked:()=>ki,liveMissionCheck:()=>bl,missionDef:()=>Wn,missionProgress:()=>cs,missionsClaimable:()=>Ru,multiplier:()=>Di,nextStageCost:()=>hi,onChange:()=>rl,openVault:()=>ca,openWoodVault:()=>dl,perkFor:()=>is,powerupDuration:()=>sr,profile:()=>Yt,recordRun:()=>fa,replaceProfile:()=>al,rollVault:()=>ha,selectChar:()=>rr,setWorld:()=>aa,skinOwned:()=>Ui,spend:()=>en,spinWheel:()=>gl,startVaultUnlock:()=>ul,totalStagesBuilt:()=>wu,unlockCharWithGems:()=>cl,upgradeCost:()=>ra,upgradePowerup:()=>ol,vaultInstantCost:()=>or,vaultOdds:()=>ml,vaultReady:()=>rs,vaultSlotsFree:()=>la,wheelFreeReady:()=>lr,wheelOdds:()=>xl,woodReady:()=>as});var vu="1.0.0";var dn=[-2.4,0,2.4],Ce={startSpeed:13,maxSpeedGain:17,speedRamp:2600,gravity:36,jumpVelocity:12.2,fastFall:-26,slideTime:.62,laneSpeed:17,playerHalfWidth:.42,standHeight:1.75,slideHeight:.72,jetHeight:8.5},tl={perMetre:1,perGold:5},Vn={magnet:{base:8,perLevel:2,color:16727386,radius:7.5},shield:{base:10,perLevel:2,color:3786495},jet:{base:5,perLevel:1,color:16756768},double:{base:10,perLevel:2,color:10181887}},Ks=["magnet","shield","jet","double"],el=[500,1200,2500,5e3,9e3,15e3],ta=el.length,Qs=[1,2,4,6],yu=12,bu=320,Qe=[{id:"city",unlocks:"nova",costFactor:1,name:{ar:"\u0645\u062F\u064A\u0646\u0629 \u0625\u064A\u0628\u0648\u062A",en:"Ebot City"},desc:{ar:"\u0634\u0648\u0627\u0631\u0639 \u0627\u0644\u0636\u0648\u0627\u062D\u064A \u0627\u0644\u0645\u0634\u0645\u0633\u0629 \u062D\u064A\u062B \u0628\u062F\u0623\u062A \u0627\u0644\u0633\u0631\u0642\u0629",en:"Sunny suburbs where the heist began"},sky:[6277375,14218239],fog:13496063,fogNear:60,fogFar:175,night:!1,ground:8179546,road:5264735,line:16777215,side:13222840,hemi:[16777215,8956518,1.05],sun:[16774102,1.35],palette:[16743001,16761165,6080767,10543216,16752335,11771391,16777215],obstacle:{low:"barrier",high:"gantry",block:"van",truck:"truck",cone:"cone",mover:"car"},props:"city",house:{wall:16773590,roof:15292223,trim:3113197,style:"classic"}},{id:"neon",unlocks:"bolt",costFactor:1.6,name:{ar:"\u062C\u0627\u062F\u0629 \u0627\u0644\u0646\u064A\u0648\u0646",en:"Neon Boulevard"},desc:{ar:"\u0644\u064A\u0644 \u0627\u0644\u0645\u062F\u064A\u0646\u0629 \u0627\u0644\u0645\u0636\u064A\u0621 \u0628\u0627\u0644\u0623\u0636\u0648\u0627\u0621",en:"The glowing city at night"},sky:[1182266,5906042],fog:2757200,fogNear:50,fogFar:160,night:!0,ground:1906744,road:2302778,line:3798015,side:3880294,hemi:[10255359,2230852,.85],sun:[16748264,.65],palette:[16727538,3798015,16769357,8086015,4063130],obstacle:{low:"neonBarrier",high:"holoGate",block:"hoverCar",truck:"neonTruck",cone:"neonCone",mover:"hoverCar"},props:"neon",house:{wall:2827600,roof:8086015,trim:16727538,style:"modern"}},{id:"island",unlocks:"zaytoon",costFactor:2.4,name:{ar:"\u062C\u0632\u064A\u0631\u0629 \u0627\u0644\u0646\u062E\u064A\u0644",en:"Palm Island"},desc:{ar:"\u0634\u0648\u0627\u0637\u0626 \u0627\u0633\u062A\u0648\u0627\u0626\u064A\u0629 \u0648\u0623\u0645\u0648\u0627\u062C \u0632\u0631\u0642\u0627\u0621",en:"Tropical beaches and blue waves"},sky:[3127551,16773314],fog:14284543,fogNear:60,fogFar:180,night:!1,ground:15914122,road:14266986,line:16774876,side:15254650,water:2017504,hemi:[16777215,14266986,1.1],sun:[16773320,1.4],palette:[16740193,3065014,16760681,13366256,16752412],obstacle:{low:"crate",high:"bambooBar",block:"hut",truck:"iceTruck",cone:"sandcastle",mover:"buggy"},props:"island",house:{wall:16769712,roof:13208380,trim:3065014,style:"beach"}},{id:"forest",unlocks:"frosty",costFactor:3.4,name:{ar:"\u063A\u0627\u0628\u0629 \u0627\u0644\u062A\u0631\u0648\u0633",en:"Gear Forest"},desc:{ar:"\u0623\u0634\u062C\u0627\u0631 \u0639\u0645\u0644\u0627\u0642\u0629 \u0648\u062A\u0631\u0648\u0633 \u0642\u062F\u064A\u0645\u0629",en:"Giant trees and ancient gears"},sky:[9426600,15859680],fog:13626575,fogNear:45,fogFar:150,night:!1,ground:5216838,road:9071173,line:12096612,side:6983486,hemi:[16056296,4090668,1],sun:[16774864,1.2],palette:[3112242,5025616,9159498,7162945,13491257],obstacle:{low:"log",high:"branch",block:"boulder",truck:"logTruck",cone:"stump",mover:"cart"},props:"forest",house:{wall:10251071,roof:4095282,trim:16036864,style:"cabin"}},{id:"snow",unlocks:"saqr",costFactor:4.6,name:{ar:"\u0642\u0645\u0629 \u0627\u0644\u062C\u0644\u064A\u062F",en:"Ice Peak"},desc:{ar:"\u0637\u0631\u0642 \u062B\u0644\u062C\u064A\u0629 \u0632\u0644\u0642\u0629 \u0648\u062C\u0628\u0627\u0644 \u0628\u064A\u0636\u0627\u0621",en:"Slippery snowy roads and white mountains"},sky:[10146047,16055295],fog:15267071,fogNear:45,fogFar:150,night:!1,snow:!0,ground:16054527,road:12965610,line:8368869,side:14937592,hemi:[16777215,12111078,1.1],sun:[16777215,1.2],palette:[14174794,3898840,2792847,16032353,16777215],obstacle:{low:"iceBlock",high:"icicleArch",block:"snowman",truck:"plowTruck",cone:"snowCone",mover:"sled"},props:"snow",house:{wall:9067067,roof:16777215,trim:14174794,style:"chalet"}},{id:"desert",unlocks:null,costFactor:6,name:{ar:"\u0648\u0627\u062D\u0629 \u0627\u0644\u0635\u0642\u0631",en:"Falcon Oasis"},desc:{ar:"\u0643\u062B\u0628\u0627\u0646 \u0630\u0647\u0628\u064A\u0629 \u0648\u0641\u0648\u0627\u0646\u064A\u0633 \u0648\u0642\u0628\u0627\u0628",en:"Golden dunes, lanterns and domes"},sky:[16757596,16773584],fog:16770495,fogNear:55,fogFar:170,night:!1,ground:15778426,road:13210458,line:16773584,side:14724202,hemi:[16774368,13210458,1.1],sun:[16769200,1.45],palette:[15320170,2792847,15167313,16032353,16777215],obstacle:{low:"sandbags",high:"carpetArch",block:"stall",truck:"caravan",cone:"jar",mover:"camelCart"},props:"desert",house:{wall:16180160,roof:13934615,trim:2792847,style:"arabian"}}],wn=[{gold:300,gems:0},{gold:800,gems:0},{gold:1600,gems:0},{gold:2800,gems:10},{gold:4500,gems:25}],Mu=[{ar:"\u0627\u0644\u0623\u0633\u0627\u0633\u0627\u062A \u0648\u0627\u0644\u062C\u062F\u0631\u0627\u0646",en:"Foundation & walls"},{ar:"\u0627\u0644\u0633\u0642\u0641",en:"Roof"},{ar:"\u0627\u0644\u0623\u0628\u0648\u0627\u0628 \u0648\u0627\u0644\u0646\u0648\u0627\u0641\u0630",en:"Doors & windows"},{ar:"\u0627\u0644\u062D\u062F\u064A\u0642\u0629",en:"Garden"},{ar:"\u0627\u0644\u0632\u064A\u0646\u0629 \u0648\u0627\u0644\u0623\u0636\u0648\u0627\u0621",en:"Decorations & lights"}];function Su(i,t){let e=Qe[i].costFactor,n=wn[t];return{gold:Math.round(n.gold*e/50)*50,gems:Math.round(n.gems*e)}}var Qr=[{id:"ebot",name:{ar:"\u0625\u064A\u0628\u0648\u062A",en:"Ebot"},bio:{ar:"\u0627\u0644\u0631\u0648\u0628\u0648\u062A \u0627\u0644\u0628\u0637\u0644 \u0627\u0644\u0630\u064A \u0633\u064F\u0631\u0642 \u0630\u0647\u0628\u0647",en:"The hero robot whose gold was stolen"},perk:{magnet:.3},unlock:{type:"start"},skins:[{id:"classic",name:{ar:"\u0643\u0644\u0627\u0633\u064A\u0643",en:"Classic"},body:16120063,accent:1619967,visor:1319229,eye:5111039},{id:"racer",name:{ar:"\u0627\u0644\u0645\u062A\u0633\u0627\u0628\u0642",en:"Racer"},body:16730942,accent:1776411,visor:1052688,eye:16769357,cost:{gold:15e3}},{id:"golden",name:{ar:"\u0627\u0644\u0630\u0647\u0628\u064A",en:"Golden"},body:16765773,accent:16752412,visor:3876096,eye:16777215,cost:{gems:180}}]},{id:"nova",name:{ar:"\u0646\u0648\u0641\u0627",en:"Nova"},bio:{ar:"\u0633\u0631\u064A\u0639\u0629 \u0648\u0630\u0643\u064A\u0629\u060C \u062A\u0636\u0627\u0639\u0641 \u0627\u0644\u0630\u0647\u0628 \u0644\u0648\u0642\u062A \u0623\u0637\u0648\u0644",en:"Fast and smart, doubles gold for longer"},perk:{double:.3},unlock:{type:"house",world:"city"},skins:[{id:"pink",name:{ar:"\u0648\u0631\u062F\u064A",en:"Blossom"},body:16773367,accent:16732067,visor:2822192,eye:16751856},{id:"mint",name:{ar:"\u0646\u0639\u0646\u0627\u0639",en:"Mint"},body:15138805,accent:1624474,visor:928548,eye:8257492,cost:{gold:18e3}},{id:"galaxy",name:{ar:"\u0627\u0644\u0645\u062C\u0631\u0629",en:"Galaxy"},body:3811980,accent:16732067,visor:591136,eye:10286591,cost:{gems:200}}]},{id:"bolt",name:{ar:"\u0628\u0648\u0644\u062A",en:"Bolt"},bio:{ar:"\u0645\u0647\u0648\u0648\u0633 \u0628\u0627\u0644\u0637\u064A\u0631\u0627\u0646 \u0648\u0627\u0644\u0646\u0641\u0627\u062B\u0627\u062A",en:"Obsessed with jets and flying"},perk:{jet:.3},unlock:{type:"house",world:"neon"},skins:[{id:"volt",name:{ar:"\u0641\u0648\u0644\u062A",en:"Volt"},body:16765503,accent:2236962,visor:1118481,eye:4059903},{id:"storm",name:{ar:"\u0627\u0644\u0639\u0627\u0635\u0641\u0629",en:"Storm"},body:7109257,accent:4059903,visor:724756,eye:16777215,cost:{gold:22e3}},{id:"plasma",name:{ar:"\u0628\u0644\u0627\u0632\u0645\u0627",en:"Plasma"},body:8073207,accent:15796131,visor:1179690,eye:16775936,cost:{gems:220}}]},{id:"zaytoon",name:{ar:"\u0632\u064A\u062A\u0648\u0646",en:"Zaytoon"},bio:{ar:"\u062F\u0631\u0639\u0647 \u0627\u0644\u0623\u062E\u0636\u0631 \u0644\u0627 \u064A\u064F\u0643\u0633\u0631 \u0628\u0633\u0647\u0648\u0644\u0629",en:"His green shield rarely breaks"},perk:{shield:.3},unlock:{type:"house",world:"island"},skins:[{id:"olive",name:{ar:"\u0632\u064A\u062A\u0648\u0646\u064A",en:"Olive"},body:9420618,accent:4156191,visor:1582092,eye:14221162},{id:"coral",name:{ar:"\u0645\u0631\u062C\u0627\u0646\u064A",en:"Coral"},body:16747109,accent:35195,visor:1710618,eye:16777215,cost:{gold:26e3}},{id:"jade",name:{ar:"\u0627\u0644\u064A\u0634\u0645",en:"Jade"},body:43115,accent:16766720,visor:11035,eye:16775080,cost:{gems:240}}]},{id:"frosty",name:{ar:"\u0641\u0631\u0648\u0633\u062A\u064A",en:"Frosty"},bio:{ar:"\u0631\u0648\u0628\u0648\u062A \u062C\u0644\u064A\u062F\u064A \u064A\u062D\u0628 \u0627\u0644\u0645\u063A\u0646\u0627\u0637\u064A\u0633 \u0648\u0627\u0644\u0637\u064A\u0631\u0627\u0646",en:"An icy bot who loves magnets and jets"},perk:{magnet:.2,jet:.2},unlock:{type:"house",world:"forest"},skins:[{id:"ice",name:{ar:"\u062C\u0644\u064A\u062F",en:"Ice"},body:14939903,accent:4892927,visor:731722,eye:12580095},{id:"aurora",name:{ar:"\u0627\u0644\u0634\u0641\u0642",en:"Aurora"},body:1914199,accent:5439416,visor:331032,eye:11766015,cost:{gold:3e4}},{id:"crystal",name:{ar:"\u0643\u0631\u064A\u0633\u062A\u0627\u0644",en:"Crystal"},body:13168895,accent:16743157,visor:2755386,eye:16777215,cost:{gems:260}}]},{id:"saqr",name:{ar:"\u0635\u0642\u0631",en:"Saqr"},bio:{ar:"\u062D\u0627\u0631\u0633 \u0627\u0644\u0648\u0627\u062D\u0629\u060C \u0633\u0631\u064A\u0639 \u0643\u0627\u0644\u0635\u0642\u0631",en:"Guardian of the oasis, swift as a falcon"},perk:{double:.2,shield:.2},unlock:{type:"house",world:"snow"},skins:[{id:"sand",name:{ar:"\u0631\u0645\u0644\u064A",en:"Sand"},body:15320170,accent:9198123,visor:2824714,eye:7012312},{id:"night",name:{ar:"\u0644\u064A\u0644\u064A",en:"Night"},body:2508371,accent:15320170,visor:329995,eye:16765286,cost:{gold:35e3}},{id:"royal",name:{ar:"\u0645\u0644\u0643\u064A",en:"Royal"},body:16777215,accent:13934615,visor:1776411,eye:58879,cost:{gems:300}}]},{id:"titan",name:{ar:"\u062A\u0627\u064A\u062A\u0646",en:"Titan"},bio:{ar:"\u0631\u0648\u0628\u0648\u062A \u0623\u0633\u0637\u0648\u0631\u064A: \u0643\u0644 \u0627\u0644\u0642\u062F\u0631\u0627\u062A \u0623\u0637\u0648\u0644 \u0648\u0646\u0642\u0627\u0637 \u0623\u0643\u062B\u0631",en:"Legendary bot: every power-up lasts longer, more score"},perk:{magnet:.15,shield:.15,jet:.15,double:.15,score:.1},unlock:{type:"gems",gems:1200},skins:[{id:"titan",name:{ar:"\u062A\u0627\u064A\u062A\u0646",en:"Titan"},body:2829634,accent:16758531,visor:0,eye:16727357},{id:"obsidian",name:{ar:"\u0633\u0628\u062C",en:"Obsidian"},body:1118481,accent:10181887,visor:0,eye:10286591,cost:{gems:350}},{id:"sun",name:{ar:"\u0627\u0644\u0634\u0645\u0633",en:"Sun"},body:16774084,accent:16739584,visor:3806464,eye:16771584,cost:{gems:450}}]}];function Ie(i){return Qr.find(t=>t.id===i)||Qr[0]}function Gn(i){return Qe.find(t=>t.id===i)||Qe[0]}function tr(i){return Math.max(0,Qe.findIndex(t=>t.id===i))}var Se={wood:{name:{ar:"\u062E\u0632\u0646\u0629 \u062E\u0634\u0628\u064A\u0629",en:"Wooden vault"},rolls:3,freeEveryH:6,table:[{k:"gold",min:150,max:450,w:40},{k:"gems",min:2,max:5,w:20},{k:"batteries",min:1,max:1,w:20},{k:"headstart",min:1,max:1,w:20}]},steel:{name:{ar:"\u062E\u0632\u0646\u0629 \u0641\u0648\u0644\u0627\u0630\u064A\u0629",en:"Steel vault"},rolls:3,unlockH:2,goldPrice:1500,table:[{k:"gold",min:500,max:1400,w:38},{k:"gems",min:5,max:12,w:24},{k:"batteries",min:1,max:3,w:22},{k:"headstart",min:1,max:2,w:16}]},diamond:{name:{ar:"\u062E\u0632\u0646\u0629 \u0645\u0627\u0633\u064A\u0629",en:"Diamond vault"},rolls:5,batteryPrice:6,gemPrice:60,guaranteeGems:!0,table:[{k:"gold",min:1500,max:4e3,w:30},{k:"gems",min:15,max:40,w:30},{k:"batteries",min:2,max:5,w:24},{k:"headstart",min:2,max:3,w:16}]}},er=4,an={freeEveryH:8,spinGemCost:10,segments:[{k:"gold",n:250,w:24,color:"#ffcf3f"},{k:"gems",n:5,w:16,color:"#4dd7ff"},{k:"batteries",n:1,w:12,color:"#7dff8a"},{k:"gold",n:600,w:14,color:"#ffb020"},{k:"headstart",n:1,w:13,color:"#ff7a59"},{k:"gems",n:15,w:9,color:"#39a0ff"},{k:"batteries",n:3,w:10.9,color:"#3ddc84"},{k:"gems",n:150,w:1.1,color:"#b06bff",jackpot:!0}]},nl={everyH:8,gold:200},ea=[[{k:"gold",n:200}],[{k:"gems",n:5}],[{k:"batteries",n:1}],[{k:"gold",n:600}],[{k:"gems",n:10}],[{k:"headstart",n:1},{k:"batteries",n:1}],[{k:"gems",n:25},{k:"vault",n:1,v:"steel"}]],na=[{id:"gold_run_s",stat:"gold",scope:"run",n:120,reward:{k:"gems",n:5}},{id:"gold_run_m",stat:"gold",scope:"run",n:300,reward:{k:"gems",n:10}},{id:"gold_run_l",stat:"gold",scope:"run",n:600,reward:{k:"gems",n:20}},{id:"gold_total",stat:"gold",scope:"total",n:2e3,reward:{k:"gems",n:15}},{id:"dist_run_s",stat:"dist",scope:"run",n:600,reward:{k:"gold",n:300}},{id:"dist_run_m",stat:"dist",scope:"run",n:1500,reward:{k:"gems",n:10}},{id:"dist_run_l",stat:"dist",scope:"run",n:3e3,reward:{k:"gems",n:25}},{id:"jumps",stat:"jumps",scope:"total",n:40,reward:{k:"gold",n:400}},{id:"slides",stat:"slides",scope:"total",n:30,reward:{k:"gold",n:400}},{id:"magnets",stat:"pu_magnet",scope:"total",n:3,reward:{k:"gems",n:6}},{id:"jets",stat:"pu_jet",scope:"total",n:3,reward:{k:"gems",n:6}},{id:"shields",stat:"pu_shield",scope:"total",n:3,reward:{k:"gems",n:6}},{id:"doubles",stat:"pu_double",scope:"total",n:3,reward:{k:"gems",n:6}},{id:"boss1",stat:"bosses",scope:"total",n:1,reward:{k:"batteries",n:2}},{id:"boss3",stat:"bosses",scope:"total",n:3,reward:{k:"gems",n:30}},{id:"emps",stat:"emps",scope:"total",n:6,reward:{k:"gems",n:10}},{id:"trucks",stat:"roofs",scope:"total",n:12,reward:{k:"gold",n:500}},{id:"runs",stat:"runs",scope:"total",n:5,reward:{k:"headstart",n:1}},{id:"gems_run",stat:"gemsPicked",scope:"total",n:3,reward:{k:"gold",n:600}},{id:"lanes",stat:"lanes",scope:"total",n:150,reward:{k:"gold",n:350}}],En=[{id:"gems_80",type:"inapp",consumable:!0,grant:[{k:"gems",n:80}],price:"$0.99",tag:null},{id:"gems_450",type:"inapp",consumable:!0,grant:[{k:"gems",n:450}],price:"$4.99",tag:"popular"},{id:"gems_1000",type:"inapp",consumable:!0,grant:[{k:"gems",n:1e3}],price:"$9.99",tag:null},{id:"gems_2200",type:"inapp",consumable:!0,grant:[{k:"gems",n:2200}],price:"$19.99",tag:"value"},{id:"gems_6000",type:"inapp",consumable:!0,grant:[{k:"gems",n:6e3}],price:"$49.99",tag:null},{id:"gems_13000",type:"inapp",consumable:!0,grant:[{k:"gems",n:13e3}],price:"$99.99",tag:"best"},{id:"gold_10k",type:"inapp",consumable:!0,grant:[{k:"gold",n:1e4}],price:"$1.99",tag:null},{id:"gold_60k",type:"inapp",consumable:!0,grant:[{k:"gold",n:6e4}],price:"$9.99",tag:"value"},{id:"starter_pack",type:"inapp",consumable:!1,oneTime:!0,price:"$2.99",tag:"starter",grant:[{k:"gems",n:300},{k:"gold",n:8e3},{k:"batteries",n:5},{k:"headstart",n:3}]},{id:"gold_doubler",type:"inapp",consumable:!1,oneTime:!0,price:"$5.99",tag:"forever",grant:[],entitlement:"doubler"},{id:"ebot_club",type:"subs",consumable:!1,price:"$3.99",tag:"club",grant:[],entitlement:"club"}],ia=[{k:"gems",n:60},{k:"batteries",n:2}],sa=[{id:"bat1",give:{k:"batteries",n:1},gems:8},{id:"bat5",give:{k:"batteries",n:5},gems:35},{id:"bat12",give:{k:"batteries",n:12},gems:75},{id:"hs1",give:{k:"headstart",n:1},gems:15},{id:"hs5",give:{k:"headstart",n:5},gems:60},{id:"gold1",give:{k:"gold",n:1e3},gems:20},{id:"gold6",give:{k:"gold",n:6e3},gems:100},{id:"gold15",give:{k:"gold",n:15e3},gems:220}],tn={firstAt:900,every:1700,hits:3,maxTime:42,gap:30,rewardGold:250,rewardGems:6};var nr=3600*1e3,nt=null,il=new Set;function sl(i){nt=i,yl(),nt.woodNext||(nt.woodNext=Date.now())}function Yt(){return nt}function rl(i){return il.add(i),()=>il.delete(i)}function me(){_u(nt),il.forEach(i=>{try{i(nt)}catch(t){console.error(t)}})}function al(i){nt=i,yl(),me()}function ir(i){return i?nt.gold>=(i.gold||0)&&nt.gems>=(i.gems||0)&&nt.batteries>=(i.batteries||0):!0}function en(i){return ir(i)?(nt.gold-=i.gold||0,nt.gems-=i.gems||0,nt.batteries-=i.batteries||0,me(),!0):!1}function Be(i,{silent:t=!1}={}){let e=[];for(let n of i||[]){let s=Math.max(0,Math.floor(n.n||0));switch(n.k){case"gold":nt.gold+=s;break;case"gems":nt.gems+=s;break;case"batteries":nt.batteries+=s;break;case"headstart":nt.headstart+=s;break;case"vault":for(let r=0;r<s;r++)ar(n.v||"steel",!0);break;default:continue}e.push({k:n.k,n:s,v:n.v})}return t||me(),e}function wu(){let i=0;for(let t of Qe)i+=nt.houses[t.id]||0;return i}function Di(){return 1+wu()}function is(i,t){return(Ie(i).perk||{})[t]||0}function sr(i,t=nt.char){let e=Vn[i];return(e.base+e.perLevel*(nt.upgrades[i]||0))*(1+is(t,i))}function ra(i){let t=nt.upgrades[i]||0;return t>=ta?null:el[t]}function ol(i){let t=ra(i);return t==null||!en({gold:t})?!1:(nt.upgrades[i]=(nt.upgrades[i]||0)+1,me(),!0)}function Tn(i){return nt.houses[i]||0}function Eu(i){return Tn(i)>=wn.length}function hi(i){let t=Tn(i);return t>=wn.length?null:Su(tr(i),t)}function ki(i){return nt.unlockedWorlds.includes(i)}function ll(i){let t=hi(i);if(!t||!ki(i)||!en(t))return{ok:!1};nt.houses[i]=Tn(i)+1;let e={ok:!0,stage:nt.houses[i],completed:!1};if(Eu(i)){e.completed=!0;let n=tr(i),s=Qe[n];if(s.unlocks&&!nt.ownedChars.includes(s.unlocks)){nt.ownedChars.push(s.unlocks);let a=Ie(s.unlocks);nt.skins[a.id]=a.skins[0].id,nt.ownedSkins.push(a.id+":"+a.skins[0].id),e.unlockedChar=a.id}let r=Qe[n+1];r&&!nt.unlockedWorlds.includes(r.id)&&(nt.unlockedWorlds.push(r.id),nt.houses[r.id]=nt.houses[r.id]||0,e.unlockedWorld=r.id),r||(e.rewards=Be([{k:"gems",n:500},{k:"vault",n:2,v:"diamond"}],{silent:!0}))}return me(),e}function aa(i){return ki(i)?(nt.world=i,me(),!0):!1}function $n(i){return nt.ownedChars.includes(i)}function cl(i){let t=Ie(i);return $n(i)||t.unlock.type!=="gems"||!en({gems:t.unlock.gems})?!1:(nt.ownedChars.push(i),nt.skins[i]=t.skins[0].id,nt.ownedSkins.push(i+":"+t.skins[0].id),me(),!0)}function rr(i){return $n(i)?(nt.char=i,me(),!0):!1}function Ui(i,t){return Ie(i).skins[0].id===t||nt.ownedSkins.includes(i+":"+t)}function hl(i,t){let e=Ie(i).skins.find(n=>n.id===t);return!e||Ui(i,t)||!$n(i)||!en(e.cost)?!1:(nt.ownedSkins.push(i+":"+t),nt.skins[i]=t,me(),!0)}function oa(i,t){return Ui(i,t)?(nt.skins[i]=t,me(),!0):!1}function ss(i=nt.char){let t=Ie(i);return t.skins.find(e=>e.id===nt.skins[i])||t.skins[0]}function Nf(){return Math.random().toString(36).slice(2,10)}function ar(i,t=!1){return nt.vaults.length>=er?!1:(nt.vaults.push({id:Nf(),type:i,unlockAt:null}),t||me(),!0)}function la(){return er-nt.vaults.length}function ul(i){let t=nt.vaults.find(e=>e.id===i);return!t||t.unlockAt||nt.vaults.some(e=>e.unlockAt&&e.unlockAt>Date.now())?!1:(t.unlockAt=Date.now()+Se[t.type].unlockH*nr,me(),!0)}function rs(i){return i.type!=="steel"||i.unlockAt&&i.unlockAt<=Date.now()}function or(i){if(rs(i))return 0;let t=i.unlockAt?i.unlockAt-Date.now():Se.steel.unlockH*nr;return Math.max(1,Math.ceil(t/(30*60*1e3)))}function ca(i,t=!1){let e=nt.vaults.findIndex(r=>r.id===i);if(e<0)return null;let n=nt.vaults[e];if(!rs(n)&&(!t||!en({batteries:or(n)})))return null;nt.vaults.splice(e,1);let s=ha(n.type);return{type:n.type,items:Be(s)}}function as(){return Date.now()>=nt.woodNext}function dl(){return as()?(nt.woodNext=Date.now()+Se.wood.freeEveryH*nr,{type:"wood",items:Be(ha("wood"))}):null}function fl(){return la()<=0||!en({gold:Se.steel.goldPrice})?!1:ar("steel")}function pl(i){let t=i?{gems:Se.diamond.gemPrice}:{batteries:Se.diamond.batteryPrice};return en(t)?{type:"diamond",items:Be(ha("diamond"))}:null}function Tu(i){let t=i.reduce((n,s)=>n+s.w,0),e=Math.random()*t;for(let n of i)if(e-=n.w,e<=0)return n;return i[i.length-1]}function Of(i,t){return i+Math.floor(Math.random()*(t-i+1))}function ha(i){let t=Se[i],e={};for(let n=0;n<t.rolls;n++){let s=t.guaranteeGems&&n===0?t.table.find(r=>r.k==="gems"):Tu(t.table);e[s.k]=(e[s.k]||0)+Of(s.min,s.max)}return Object.keys(e).map(n=>({k:n,n:e[n]}))}function ml(i){let t=Se[i].table,e=t.reduce((n,s)=>n+s.w,0);return t.map(n=>({k:n.k,min:n.min,max:n.max,pct:n.w/e*100}))}function lr(){return Date.now()>=nt.wheelNext}function gl(i){if(i){if(!en({gems:an.spinGemCost}))return null}else{if(!lr())return null;nt.wheelNext=Date.now()+an.freeEveryH*nr}let t=an.segments.indexOf(Tu(an.segments)),e=an.segments[t],n=Be([{k:e.k,n:e.n}]);return{index:t,items:n}}function xl(){let i=an.segments.reduce((t,e)=>t+e.w,0);return an.segments.map(t=>({...t,pct:t.w/i*100}))}function os(){return Date.now()>=nt.giftNext}function _l(){return os()?(nt.giftNext=Date.now()+nl.everyH*nr,Be([{k:"gold",n:nl.gold}])):null}function cr(i=new Date){return i.getFullYear()+"-"+(i.getMonth()+1)+"-"+i.getDate()}function ls(){return nt.daily.last!==cr()}function ua(){if(!ls())return(nt.daily.day+6)%7;let i=new Date;return i.setDate(i.getDate()-1),nt.daily.last&&nt.daily.last!==cr(i)?0:nt.daily.day%7}function vl(){if(!ls())return null;let i=ua();return nt.daily.day=(i+1)%7,nt.daily.last=cr(),Be(ea[i])}function Au(i){let t=na.filter(n=>!i.includes(n.id)),e=t[Math.floor(Math.random()*t.length)];return{id:e.id,base:nt.missionTotals[e.stat]||0,best:0,done:!1}}function yl(){for(nt.missions=(nt.missions||[]).filter(i=>na.some(t=>t.id===i.id));nt.missions.length<3;)nt.missions.push(Au(nt.missions.map(i=>i.id)))}function Wn(i){return na.find(t=>t.id===i)}function cs(i,t){let e=Wn(i.id);if(i.done)return e.n;let n=t&&t[e.stat]||0;return e.scope==="run"?Math.min(e.n,Math.max(i.best,n)):Math.min(e.n,(nt.missionTotals[e.stat]||0)-i.base+n)}function bl(i){let t=[];for(let e of nt.missions)e.done||e.notified||cs(e,i)>=Wn(e.id).n&&(e.notified=!0,t.push(e));return t}function da(i){for(let t of nt.missions){let e=Wn(t.id);e.scope==="run"&&(t.best=Math.max(t.best,i[e.stat]||0))}for(let t in i)nt.missionTotals[t]=(nt.missionTotals[t]||0)+i[t];for(let t of nt.missions)!t.done&&cs(t,null)>=Wn(t.id).n&&(t.done=!0),delete t.notified;me()}function Ml(i){let t=nt.missions[i];if(!t||!t.done)return null;let e=Be([Wn(t.id).reward],{silent:!0});return nt.missions[i]=Au(nt.missions.map(n=>n.id)),me(),e}function Ru(){return nt.missions.filter(i=>i.done).length}function hs(){return nt.iap.clubUntil>Date.now()}function Sl(){return hs()&&nt.iap.clubClaim!==cr()}function wl(){return Sl()?(nt.iap.clubClaim=cr(),Be(ia)):null}function fa({score:i,dist:t,gold:e}){let n=nt;n.stats.runs++,n.stats.dist+=Math.floor(t),n.stats.gold+=e;let s=i>n.best;return n.best=Math.max(n.best,Math.floor(i)),n.bestDist=Math.max(n.bestDist,Math.floor(t)),n.records.push({score:Math.floor(i),dist:Math.floor(t),char:n.char,world:n.world,at:Date.now()}),n.records.sort((r,a)=>a.score-r.score),n.records=n.records.slice(0,10),me(),s}function El(){return{daily:ls(),missions:Ru(),wheel:lr(),gift:os(),vaults:as()||nt.vaults.some(i=>i.type!=="steel"||rs(i))||nt.vaults.some(i=>i.type==="steel"&&!i.unlockAt)&&!nt.vaults.some(i=>i.unlockAt&&i.unlockAt>Date.now()),club:Sl(),build:!!hi(nt.world)&&ir(hi(nt.world))}}var Lh="170";var Ff=0,Cu=1,Bf=2;var zd=1,Dh=2,jn=3,Mi=0,$e=1,pn=2,vi=0,Ls=1,Ns=2,Pu=3,Iu=4,zf=5,Gi=100,Hf=101,Vf=102,Gf=103,Wf=104,$f=200,Xf=201,qf=202,Yf=203,rc=204,ac=205,Zf=206,Jf=207,jf=208,Kf=209,Qf=210,tp=211,ep=212,np=213,ip=214,oc=0,lc=1,cc=2,Os=3,hc=4,uc=5,dc=6,fc=7,kh=0,sp=1,rp=2,yi=0,ap=1,op=2,lp=3,cp=4,hp=5,up=6,dp=7;var Hd=300,Fs=301,Bs=302,pc=303,mc=304,Io=306,Tr=1e3,$i=1001,gc=1002,cn=1003,fp=1004;var ma=1005;var Nn=1006,Tl=1007;var Xi=1008;var ei=1009,Vd=1010,Gd=1011,Ar=1012,Uh=1013,qi=1014,On=1015,Vr=1016,Nh=1017,Oh=1018,zs=1020,Wd=35902,$d=1021,Xd=1022,In=1023,qd=1024,Yd=1025,Ds=1026,Hs=1027,Fh=1028,Bh=1029,Zd=1030,zh=1031;var Hh=1033,Xa=33776,qa=33777,Ya=33778,Za=33779,xc=35840,_c=35841,vc=35842,yc=35843,bc=36196,Mc=37492,Sc=37496,wc=37808,Ec=37809,Tc=37810,Ac=37811,Rc=37812,Cc=37813,Pc=37814,Ic=37815,Lc=37816,Dc=37817,kc=37818,Uc=37819,Nc=37820,Oc=37821,Ja=36492,Fc=36494,Bc=36495,Jd=36283,zc=36284,Hc=36285,Vc=36286;var ja=2300,Gc=2301,Al=2302,Lu=2400,Du=2401,ku=2402;var pp=3200,mp=3201;var jd=0,gp=1,xi="",nn="srgb",qs="srgb-linear",Lo="linear",pe="srgb";var us=7680;var Uu=519,xp=512,_p=513,vp=514,Kd=515,yp=516,bp=517,Mp=518,Sp=519,Wc=35044,Qd=35048;var Nu="300 es",Qn=2e3,Ka=2001,Si=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},Ge=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ou=1234567,br=Math.PI/180,Rr=180/Math.PI;function Fn(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ge[i&255]+Ge[i>>8&255]+Ge[i>>16&255]+Ge[i>>24&255]+"-"+Ge[t&255]+Ge[t>>8&255]+"-"+Ge[t>>16&15|64]+Ge[t>>24&255]+"-"+Ge[e&63|128]+Ge[e>>8&255]+"-"+Ge[e>>16&255]+Ge[e>>24&255]+Ge[n&255]+Ge[n>>8&255]+Ge[n>>16&255]+Ge[n>>24&255]).toLowerCase()}function Ue(i,t,e){return Math.max(t,Math.min(e,i))}function Vh(i,t){return(i%t+t)%t}function wp(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Ep(i,t,e){return i!==t?(e-i)/(t-i):0}function Mr(i,t,e){return(1-e)*i+e*t}function Tp(i,t,e,n){return Mr(i,t,1-Math.exp(-e*n))}function Ap(i,t=1){return t-Math.abs(Vh(i,t*2)-t)}function Rp(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Cp(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Pp(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Ip(i,t){return i+Math.random()*(t-i)}function Lp(i){return i*(.5-Math.random())}function Dp(i){i!==void 0&&(Ou=i);let t=Ou+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function kp(i){return i*br}function Up(i){return i*Rr}function Np(i){return(i&i-1)===0&&i!==0}function Op(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Fp(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Bp(i,t,e,n,s){let r=Math.cos,a=Math.sin,o=r(e/2),l=a(e/2),c=r((t+n)/2),h=a((t+n)/2),u=r((t-n)/2),d=a((t-n)/2),f=r((n-t)/2),g=a((n-t)/2);switch(s){case"XYX":i.set(o*h,l*u,l*d,o*c);break;case"YZY":i.set(l*d,o*h,l*u,o*c);break;case"ZXZ":i.set(l*u,l*d,o*h,o*c);break;case"XZX":i.set(o*h,l*g,l*f,o*c);break;case"YXY":i.set(l*f,o*h,l*g,o*c);break;case"ZYZ":i.set(l*g,l*f,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Pn(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function he(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var tf={DEG2RAD:br,RAD2DEG:Rr,generateUUID:Fn,clamp:Ue,euclideanModulo:Vh,mapLinear:wp,inverseLerp:Ep,lerp:Mr,damp:Tp,pingpong:Ap,smoothstep:Rp,smootherstep:Cp,randInt:Pp,randFloat:Ip,randFloatSpread:Lp,seededRandom:Dp,degToRad:kp,radToDeg:Up,isPowerOfTwo:Np,ceilPowerOfTwo:Op,floorPowerOfTwo:Fp,setQuaternionFromProperEuler:Bp,normalize:he,denormalize:Pn},st=class i{constructor(t=0,e=0){i.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ue(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*s+t.x,this.y=r*s+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Zt=class i{constructor(t,e,n,s,r,a,o,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c)}set(t,e,n,s,r,a,o,l,c){let h=this.elements;return h[0]=t,h[1]=s,h[2]=o,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],v=s[1],y=s[4],x=s[7],D=s[2],T=s[5],R=s[8];return r[0]=a*_+o*v+l*D,r[3]=a*m+o*y+l*T,r[6]=a*p+o*x+l*R,r[1]=c*_+h*v+u*D,r[4]=c*m+h*y+u*T,r[7]=c*p+h*x+u*R,r[2]=d*_+f*v+g*D,r[5]=d*m+f*y+g*T,r[8]=d*p+f*x+g*R,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*r*h+n*o*l+s*r*c-s*a*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,d=o*l-h*r,f=c*r-a*l,g=e*u+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let _=1/g;return t[0]=u*_,t[1]=(s*c-h*n)*_,t[2]=(o*n-s*a)*_,t[3]=d*_,t[4]=(h*e-s*l)*_,t[5]=(s*r-o*e)*_,t[6]=f*_,t[7]=(n*l-c*e)*_,t[8]=(a*e-n*r)*_,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-s*c,s*l,-s*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(Rl.makeScale(t,e)),this}rotate(t){return this.premultiply(Rl.makeRotation(-t)),this}translate(t,e){return this.premultiply(Rl.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Rl=new Zt;function ef(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function Qa(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function zp(){let i=Qa("canvas");return i.style.display="block",i}var Fu={};function vr(i){i in Fu||(Fu[i]=!0,console.warn(i))}function Hp(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function Vp(i){let t=i.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function Gp(i){let t=i.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var ne={enabled:!0,workingColorSpace:qs,spaces:{},convert:function(i,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===pe&&(i.r=ti(i.r),i.g=ti(i.g),i.b=ti(i.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(i.applyMatrix3(this.spaces[t].toXYZ),i.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===pe&&(i.r=ks(i.r),i.g=ks(i.g),i.b=ks(i.b))),i},fromWorkingColorSpace:function(i,t){return this.convert(i,this.workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===xi?Lo:this.spaces[i].transfer},getLuminanceCoefficients:function(i,t=this.workingColorSpace){return i.fromArray(this.spaces[t].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,t,e){return i.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function ti(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ks(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var Bu=[.64,.33,.3,.6,.15,.06],zu=[.2126,.7152,.0722],Hu=[.3127,.329],Vu=new Zt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Gu=new Zt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);ne.define({[qs]:{primaries:Bu,whitePoint:Hu,transfer:Lo,toXYZ:Vu,fromXYZ:Gu,luminanceCoefficients:zu,workingColorSpaceConfig:{unpackColorSpace:nn},outputColorSpaceConfig:{drawingBufferColorSpace:nn}},[nn]:{primaries:Bu,whitePoint:Hu,transfer:pe,toXYZ:Vu,fromXYZ:Gu,luminanceCoefficients:zu,outputColorSpaceConfig:{drawingBufferColorSpace:nn}}});var ds,$c=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{ds===void 0&&(ds=Qa("canvas")),ds.width=t.width,ds.height=t.height;let n=ds.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=ds}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Qa("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=ti(r[a]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(ti(e[n]/255)*255):e[n]=ti(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Wp=0,to=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wp++}),this.uuid=Fn(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Cl(s[a].image)):r.push(Cl(s[a]))}else r=Cl(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function Cl(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?$c.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var $p=0,sn=class i extends Si{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=$i,s=$i,r=Nn,a=Xi,o=In,l=ei,c=i.DEFAULT_ANISOTROPY,h=xi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:$p++}),this.uuid=Fn(),this.name="",this.source=new to(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new st(0,0),this.repeat=new st(1,1),this.center=new st(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Zt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Hd)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Tr:t.x=t.x-Math.floor(t.x);break;case $i:t.x=t.x<0?0:1;break;case gc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Tr:t.y=t.y-Math.floor(t.y);break;case $i:t.y=t.y<0?0:1;break;case gc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};sn.DEFAULT_IMAGE=null;sn.DEFAULT_MAPPING=Hd;sn.DEFAULT_ANISOTROPY=1;var Te=class i{constructor(t=0,e=0,n=0,s=1){i.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*s+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(c+1)/2,x=(f+1)/2,D=(p+1)/2,T=(h+d)/4,R=(u+_)/4,L=(g+m)/4;return y>x&&y>D?y<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(y),s=T/n,r=R/n):x>D?x<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(x),n=T/s,r=L/s):D<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(D),n=R/r,s=L/r),this.set(n,s,r,e),this}let v=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(v)<.001&&(v=1),this.x=(m-g)/v,this.y=(u-_)/v,this.z=(d-h)/v,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Xc=class extends Si{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Te(0,0,t,e),this.scissorTest=!1,this.viewport=new Te(0,0,t,e);let s={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Nn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);let r=new sn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];let a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,s=t.textures.length;n<s;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new to(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},ni=class extends Xc{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},eo=class extends sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=cn,this.minFilter=cn,this.wrapR=$i,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var qc=class extends sn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=cn,this.minFilter=cn,this.wrapR=$i,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Bn=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,a,o){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[a+0],f=r[a+1],g=r[a+2],_=r[a+3];if(o===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=d,t[e+1]=f,t[e+2]=g,t[e+3]=_;return}if(u!==_||l!==d||c!==f||h!==g){let m=1-o,p=l*d+c*f+h*g+u*_,v=p>=0?1:-1,y=1-p*p;if(y>Number.EPSILON){let D=Math.sqrt(y),T=Math.atan2(D,p*v);m=Math.sin(m*T)/D,o=Math.sin(o*T)/D}let x=o*v;if(l=l*m+d*x,c=c*m+f*x,h=h*m+g*x,u=u*m+_*x,m===1-o){let D=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=D,c*=D,h*=D,u*=D}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,s,r,a){let o=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[a],d=r[a+1],f=r[a+2],g=r[a+3];return t[e]=o*g+h*u+l*f-c*d,t[e+1]=l*g+h*d+c*u-o*f,t[e+2]=c*g+h*f+o*d-l*u,t[e+3]=h*g-o*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(s/2),u=o(r/2),d=l(n/2),f=l(s/2),g=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+o+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(a-s)*f}else if(n>o&&n>u){let f=2*Math.sqrt(1+n-o-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+a)/f,this._z=(r+c)/f}else if(o>u){let f=2*Math.sqrt(1+o-n-u);this._w=(r-c)/f,this._x=(s+a)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-o);this._w=(a-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ue(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+s*c-r*l,this._y=s*h+a*l+r*o-n*c,this._z=r*h+a*c+n*l-s*o,this._w=a*h-n*o-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,s=this._y,r=this._z,a=this._w,o=a*t._w+n*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=s,this._z=r,this;let l=1-o*o;if(l<=Number.EPSILON){let f=1-e;return this._w=f*a+e*this._w,this._x=f*n+e*this._x,this._y=f*s+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},P=class i{constructor(t=0,e=0,n=0){i.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Wu.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Wu.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*s-o*n),h=2*(o*e-r*s),u=2*(r*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-r*u,this.z=s+l*u+r*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=s*l-r*o,this.y=r*a-n*l,this.z=n*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Pl.copy(this).projectOnVector(t),this.sub(Pl)}reflect(t){return this.sub(Pl.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ue(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Pl=new P,Wu=new Bn,ii=class{constructor(t=new P(1/0,1/0,1/0),e=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(An.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(An.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=An.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,An):An.fromBufferAttribute(r,a),An.applyMatrix4(t.matrixWorld),this.expandByPoint(An);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ga.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ga.copy(n.boundingBox)),ga.applyMatrix4(t.matrixWorld),this.union(ga)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,An),An.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(hr),xa.subVectors(this.max,hr),fs.subVectors(t.a,hr),ps.subVectors(t.b,hr),ms.subVectors(t.c,hr),ui.subVectors(ps,fs),di.subVectors(ms,ps),Ni.subVectors(fs,ms);let e=[0,-ui.z,ui.y,0,-di.z,di.y,0,-Ni.z,Ni.y,ui.z,0,-ui.x,di.z,0,-di.x,Ni.z,0,-Ni.x,-ui.y,ui.x,0,-di.y,di.x,0,-Ni.y,Ni.x,0];return!Il(e,fs,ps,ms,xa)||(e=[1,0,0,0,1,0,0,0,1],!Il(e,fs,ps,ms,xa))?!1:(_a.crossVectors(ui,di),e=[_a.x,_a.y,_a.z],Il(e,fs,ps,ms,xa))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,An).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(An).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Xn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Xn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Xn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Xn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Xn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Xn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Xn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Xn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Xn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},Xn=[new P,new P,new P,new P,new P,new P,new P,new P],An=new P,ga=new ii,fs=new P,ps=new P,ms=new P,ui=new P,di=new P,Ni=new P,hr=new P,xa=new P,_a=new P,Oi=new P;function Il(i,t,e,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Oi.fromArray(i,r);let o=s.x*Math.abs(Oi.x)+s.y*Math.abs(Oi.y)+s.z*Math.abs(Oi.z),l=t.dot(Oi),c=e.dot(Oi),h=n.dot(Oi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var Xp=new ii,ur=new P,Ll=new P,wi=class{constructor(t=new P,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Xp.setFromPoints(t).getCenter(n);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ur.subVectors(t,this.center);let e=ur.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(ur,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Ll.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ur.copy(t.center).add(Ll)),this.expandByPoint(ur.copy(t.center).sub(Ll))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},qn=new P,Dl=new P,va=new P,fi=new P,kl=new P,ya=new P,Ul=new P,no=class{constructor(t=new P,e=new P(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,qn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=qn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(qn.copy(this.origin).addScaledVector(this.direction,e),qn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Dl.copy(t).add(e).multiplyScalar(.5),va.copy(e).sub(t).normalize(),fi.copy(this.origin).sub(Dl);let r=t.distanceTo(e)*.5,a=-this.direction.dot(va),o=fi.dot(this.direction),l=-fi.dot(va),c=fi.lengthSq(),h=Math.abs(1-a*a),u,d,f,g;if(h>0)if(u=a*l-o,d=a*o-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let _=1/h;u*=_,d*=_,f=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Dl).addScaledVector(va,d),f}intersectSphere(t,e){qn.subVectors(t.center,this.origin);let n=qn.dot(this.direction),s=qn.dot(qn)-n*n,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,s=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,s=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,a=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,a=(t.min.y-d.y)*h),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),u>=0?(o=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(o=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,qn)!==null}intersectTriangle(t,e,n,s,r){kl.subVectors(e,t),ya.subVectors(n,t),Ul.crossVectors(kl,ya);let a=this.direction.dot(Ul),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;fi.subVectors(this.origin,t);let l=o*this.direction.dot(ya.crossVectors(fi,ya));if(l<0)return null;let c=o*this.direction.dot(kl.cross(fi));if(c<0||l+c>a)return null;let h=-o*fi.dot(Ul);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ue=class i{constructor(t,e,n,s,r,a,o,l,c,h,u,d,f,g,_,m){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c,h,u,d,f,g,_,m)}set(t,e,n,s,r,a,o,l,c,h,u,d,f,g,_,m){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=s,p[1]=r,p[5]=a,p[9]=o,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,s=1/gs.setFromMatrixColumn(t,0).length(),r=1/gs.setFromMatrixColumn(t,1).length(),a=1/gs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=a*h,f=a*u,g=o*h,_=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+g*c,e[5]=d-_*c,e[9]=-o*l,e[2]=_-d*c,e[6]=g+f*c,e[10]=a*l}else if(t.order==="YXZ"){let d=l*h,f=l*u,g=c*h,_=c*u;e[0]=d+_*o,e[4]=g*o-f,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=f*o-g,e[6]=_+d*o,e[10]=a*l}else if(t.order==="ZXY"){let d=l*h,f=l*u,g=c*h,_=c*u;e[0]=d-_*o,e[4]=-a*u,e[8]=g+f*o,e[1]=f+g*o,e[5]=a*h,e[9]=_-d*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){let d=a*h,f=a*u,g=o*h,_=o*u;e[0]=l*h,e[4]=g*c-f,e[8]=d*c+_,e[1]=l*u,e[5]=_*c+d,e[9]=f*c-g,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){let d=a*l,f=a*c,g=o*l,_=o*c;e[0]=l*h,e[4]=_-d*u,e[8]=g*u+f,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=f*u+g,e[10]=d-_*u}else if(t.order==="XZY"){let d=a*l,f=a*c,g=o*l,_=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+_,e[5]=a*h,e[9]=f*u-g,e[2]=g*u-f,e[6]=o*h,e[10]=_*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(qp,t,Yp)}lookAt(t,e,n){let s=this.elements;return on.subVectors(t,e),on.lengthSq()===0&&(on.z=1),on.normalize(),pi.crossVectors(n,on),pi.lengthSq()===0&&(Math.abs(n.z)===1?on.x+=1e-4:on.z+=1e-4,on.normalize(),pi.crossVectors(n,on)),pi.normalize(),ba.crossVectors(on,pi),s[0]=pi.x,s[4]=ba.x,s[8]=on.x,s[1]=pi.y,s[5]=ba.y,s[9]=on.y,s[2]=pi.z,s[6]=ba.z,s[10]=on.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],v=n[3],y=n[7],x=n[11],D=n[15],T=s[0],R=s[4],L=s[8],w=s[12],M=s[1],I=s[5],G=s[9],z=s[13],W=s[2],K=s[6],$=s[10],at=s[14],X=s[3],ft=s[7],yt=s[11],At=s[15];return r[0]=a*T+o*M+l*W+c*X,r[4]=a*R+o*I+l*K+c*ft,r[8]=a*L+o*G+l*$+c*yt,r[12]=a*w+o*z+l*at+c*At,r[1]=h*T+u*M+d*W+f*X,r[5]=h*R+u*I+d*K+f*ft,r[9]=h*L+u*G+d*$+f*yt,r[13]=h*w+u*z+d*at+f*At,r[2]=g*T+_*M+m*W+p*X,r[6]=g*R+_*I+m*K+p*ft,r[10]=g*L+_*G+m*$+p*yt,r[14]=g*w+_*z+m*at+p*At,r[3]=v*T+y*M+x*W+D*X,r[7]=v*R+y*I+x*K+D*ft,r[11]=v*L+y*G+x*$+D*yt,r[15]=v*w+y*z+x*at+D*At,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],g=t[3],_=t[7],m=t[11],p=t[15];return g*(+r*l*u-s*c*u-r*o*d+n*c*d+s*o*f-n*l*f)+_*(+e*l*f-e*c*d+r*a*d-s*a*f+s*c*h-r*l*h)+m*(+e*c*u-e*o*f-r*a*u+n*a*f+r*o*h-n*c*h)+p*(-s*o*h-e*l*u+e*o*d+s*a*u-n*a*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],g=t[12],_=t[13],m=t[14],p=t[15],v=u*m*c-_*d*c+_*l*f-o*m*f-u*l*p+o*d*p,y=g*d*c-h*m*c-g*l*f+a*m*f+h*l*p-a*d*p,x=h*_*c-g*u*c+g*o*f-a*_*f-h*o*p+a*u*p,D=g*u*l-h*_*l-g*o*d+a*_*d+h*o*m-a*u*m,T=e*v+n*y+s*x+r*D;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/T;return t[0]=v*R,t[1]=(_*d*r-u*m*r-_*s*f+n*m*f+u*s*p-n*d*p)*R,t[2]=(o*m*r-_*l*r+_*s*c-n*m*c-o*s*p+n*l*p)*R,t[3]=(u*l*r-o*d*r-u*s*c+n*d*c+o*s*f-n*l*f)*R,t[4]=y*R,t[5]=(h*m*r-g*d*r+g*s*f-e*m*f-h*s*p+e*d*p)*R,t[6]=(g*l*r-a*m*r-g*s*c+e*m*c+a*s*p-e*l*p)*R,t[7]=(a*d*r-h*l*r+h*s*c-e*d*c-a*s*f+e*l*f)*R,t[8]=x*R,t[9]=(g*u*r-h*_*r-g*n*f+e*_*f+h*n*p-e*u*p)*R,t[10]=(a*_*r-g*o*r+g*n*c-e*_*c-a*n*p+e*o*p)*R,t[11]=(h*o*r-a*u*r-h*n*c+e*u*c+a*n*f-e*o*f)*R,t[12]=D*R,t[13]=(h*_*s-g*u*s+g*n*d-e*_*d-h*n*m+e*u*m)*R,t[14]=(g*o*s-a*_*s-g*n*l+e*_*l+a*n*m-e*o*m)*R,t[15]=(a*u*s-h*o*s+h*n*l-e*u*l-a*n*d+e*o*d)*R,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,h=r*o;return this.set(c*a+n,c*o-s*l,c*l+s*o,0,c*o+s*l,h*o+n,h*l-s*a,0,c*l-s*o,h*l+s*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,a){return this.set(1,n,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,h=a+a,u=o+o,d=r*c,f=r*h,g=r*u,_=a*h,m=a*u,p=o*u,v=l*c,y=l*h,x=l*u,D=n.x,T=n.y,R=n.z;return s[0]=(1-(_+p))*D,s[1]=(f+x)*D,s[2]=(g-y)*D,s[3]=0,s[4]=(f-x)*T,s[5]=(1-(d+p))*T,s[6]=(m+v)*T,s[7]=0,s[8]=(g+y)*R,s[9]=(m-v)*R,s[10]=(1-(d+_))*R,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements,r=gs.set(s[0],s[1],s[2]).length(),a=gs.set(s[4],s[5],s[6]).length(),o=gs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Rn.copy(this);let c=1/r,h=1/a,u=1/o;return Rn.elements[0]*=c,Rn.elements[1]*=c,Rn.elements[2]*=c,Rn.elements[4]*=h,Rn.elements[5]*=h,Rn.elements[6]*=h,Rn.elements[8]*=u,Rn.elements[9]*=u,Rn.elements[10]*=u,e.setFromRotationMatrix(Rn),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,s,r,a,o=Qn){let l=this.elements,c=2*r/(e-t),h=2*r/(n-s),u=(e+t)/(e-t),d=(n+s)/(n-s),f,g;if(o===Qn)f=-(a+r)/(a-r),g=-2*a*r/(a-r);else if(o===Ka)f=-a/(a-r),g=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,a,o=Qn){let l=this.elements,c=1/(e-t),h=1/(n-s),u=1/(a-r),d=(e+t)*c,f=(n+s)*h,g,_;if(o===Qn)g=(a+r)*u,_=-2*u;else if(o===Ka)g=r*u,_=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=_,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},gs=new P,Rn=new ue,qp=new P(0,0,0),Yp=new P(1,1,1),pi=new P,ba=new P,on=new P,$u=new ue,Xu=new Bn,mn=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(e){case"XYZ":this._y=Math.asin(Ue(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ue(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ue(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Ue(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Ue(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Ue(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return $u.makeRotationFromQuaternion(t),this.setFromRotationMatrix($u,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Xu.setFromEuler(this),this.setFromQuaternion(Xu,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};mn.DEFAULT_ORDER="XYZ";var io=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Zp=0,qu=new P,xs=new Bn,Yn=new ue,Ma=new P,dr=new P,Jp=new P,jp=new Bn,Yu=new P(1,0,0),Zu=new P(0,1,0),Ju=new P(0,0,1),ju={type:"added"},Kp={type:"removed"},_s={type:"childadded",child:null},Nl={type:"childremoved",child:null},ze=class i extends Si{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zp++}),this.uuid=Fn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new P,e=new mn,n=new Bn,s=new P(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ue},normalMatrix:{value:new Zt}}),this.matrix=new ue,this.matrixWorld=new ue,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new io,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return xs.setFromAxisAngle(t,e),this.quaternion.multiply(xs),this}rotateOnWorldAxis(t,e){return xs.setFromAxisAngle(t,e),this.quaternion.premultiply(xs),this}rotateX(t){return this.rotateOnAxis(Yu,t)}rotateY(t){return this.rotateOnAxis(Zu,t)}rotateZ(t){return this.rotateOnAxis(Ju,t)}translateOnAxis(t,e){return qu.copy(t).applyQuaternion(this.quaternion),this.position.add(qu.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Yu,t)}translateY(t){return this.translateOnAxis(Zu,t)}translateZ(t){return this.translateOnAxis(Ju,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Yn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Ma.copy(t):Ma.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),dr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Yn.lookAt(dr,Ma,this.up):Yn.lookAt(Ma,dr,this.up),this.quaternion.setFromRotationMatrix(Yn),s&&(Yn.extractRotation(s.matrixWorld),xs.setFromRotationMatrix(Yn),this.quaternion.premultiply(xs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(ju),_s.child=t,this.dispatchEvent(_s),_s.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Kp),Nl.child=t,this.dispatchEvent(Nl),Nl.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Yn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Yn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Yn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(ju),_s.child=t,this.dispatchEvent(_s),_s.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(dr,t,Jp),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(dr,jp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];s.animations.push(r(t.animations,l))}}if(e){let o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),d=a(t.skeletons),f=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}};ze.DEFAULT_UP=new P(0,1,0);ze.DEFAULT_MATRIX_AUTO_UPDATE=!0;ze.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Cn=new P,Zn=new P,Ol=new P,Jn=new P,vs=new P,ys=new P,Ku=new P,Fl=new P,Bl=new P,zl=new P,Hl=new Te,Vl=new Te,Gl=new Te,_i=class i{constructor(t=new P,e=new P,n=new P){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),Cn.subVectors(t,e),s.cross(Cn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){Cn.subVectors(s,e),Zn.subVectors(n,e),Ol.subVectors(t,e);let a=Cn.dot(Cn),o=Cn.dot(Zn),l=Cn.dot(Ol),c=Zn.dot(Zn),h=Zn.dot(Ol),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-o*h)*d,g=(a*h-o*l)*d;return r.set(1-f-g,g,f)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,Jn)===null?!1:Jn.x>=0&&Jn.y>=0&&Jn.x+Jn.y<=1}static getInterpolation(t,e,n,s,r,a,o,l){return this.getBarycoord(t,e,n,s,Jn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Jn.x),l.addScaledVector(a,Jn.y),l.addScaledVector(o,Jn.z),l)}static getInterpolatedAttribute(t,e,n,s,r,a){return Hl.setScalar(0),Vl.setScalar(0),Gl.setScalar(0),Hl.fromBufferAttribute(t,e),Vl.fromBufferAttribute(t,n),Gl.fromBufferAttribute(t,s),a.setScalar(0),a.addScaledVector(Hl,r.x),a.addScaledVector(Vl,r.y),a.addScaledVector(Gl,r.z),a}static isFrontFacing(t,e,n,s){return Cn.subVectors(n,e),Zn.subVectors(t,e),Cn.cross(Zn).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Cn.subVectors(this.c,this.b),Zn.subVectors(this.a,this.b),Cn.cross(Zn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,a,o;vs.subVectors(s,n),ys.subVectors(r,n),Fl.subVectors(t,n);let l=vs.dot(Fl),c=ys.dot(Fl);if(l<=0&&c<=0)return e.copy(n);Bl.subVectors(t,s);let h=vs.dot(Bl),u=ys.dot(Bl);if(h>=0&&u<=h)return e.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(vs,a);zl.subVectors(t,r);let f=vs.dot(zl),g=ys.dot(zl);if(g>=0&&f<=g)return e.copy(r);let _=f*c-l*g;if(_<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(ys,o);let m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return Ku.subVectors(r,s),o=(u-h)/(u-h+(f-g)),e.copy(s).addScaledVector(Ku,o);let p=1/(m+_+d);return a=_*p,o=d*p,e.copy(n).addScaledVector(vs,a).addScaledVector(ys,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},nf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},mi={h:0,s:0,l:0},Sa={h:0,s:0,l:0};function Wl(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var Wt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=nn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,ne.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=ne.workingColorSpace){return this.r=t,this.g=e,this.b=n,ne.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=ne.workingColorSpace){if(t=Vh(t,1),e=Ue(e,0,1),n=Ue(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Wl(a,r,t+1/3),this.g=Wl(a,r,t),this.b=Wl(a,r,t-1/3)}return ne.toWorkingColorSpace(this,s),this}setStyle(t,e=nn){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=nn){let n=nf[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=ti(t.r),this.g=ti(t.g),this.b=ti(t.b),this}copyLinearToSRGB(t){return this.r=ks(t.r),this.g=ks(t.g),this.b=ks(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=nn){return ne.fromWorkingColorSpace(We.copy(this),t),Math.round(Ue(We.r*255,0,255))*65536+Math.round(Ue(We.g*255,0,255))*256+Math.round(Ue(We.b*255,0,255))}getHexString(t=nn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=ne.workingColorSpace){ne.fromWorkingColorSpace(We.copy(this),e);let n=We.r,s=We.g,r=We.b,a=Math.max(n,s,r),o=Math.min(n,s,r),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=ne.workingColorSpace){return ne.fromWorkingColorSpace(We.copy(this),e),t.r=We.r,t.g=We.g,t.b=We.b,t}getStyle(t=nn){ne.fromWorkingColorSpace(We.copy(this),t);let e=We.r,n=We.g,s=We.b;return t!==nn?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(mi),this.setHSL(mi.h+t,mi.s+e,mi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(mi),t.getHSL(Sa);let n=Mr(mi.h,Sa.h,e),s=Mr(mi.s,Sa.s,e),r=Mr(mi.l,Sa.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},We=new Wt;Wt.NAMES=nf;var Qp=0,si=class extends Si{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Qp++}),this.uuid=Fn(),this.name="",this.blending=Ls,this.side=Mi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=rc,this.blendDst=ac,this.blendEquation=Gi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Wt(0,0,0),this.blendAlpha=0,this.depthFunc=Os,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Uu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=us,this.stencilZFail=us,this.stencilZPass=us,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ls&&(n.blending=this.blending),this.side!==Mi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==rc&&(n.blendSrc=this.blendSrc),this.blendDst!==ac&&(n.blendDst=this.blendDst),this.blendEquation!==Gi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Os&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Uu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==us&&(n.stencilFail=this.stencilFail),this.stencilZFail!==us&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==us&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},Vs=class extends si{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new Wt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new mn,this.combine=kh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Pe=new P,wa=new st,Ne=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Wc,this.updateRanges=[],this.gpuType=On,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)wa.fromBufferAttribute(this,e),wa.applyMatrix3(t),this.setXY(e,wa.x,wa.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Pe.fromBufferAttribute(this,e),Pe.applyMatrix3(t),this.setXYZ(e,Pe.x,Pe.y,Pe.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Pe.fromBufferAttribute(this,e),Pe.applyMatrix4(t),this.setXYZ(e,Pe.x,Pe.y,Pe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Pe.fromBufferAttribute(this,e),Pe.applyNormalMatrix(t),this.setXYZ(e,Pe.x,Pe.y,Pe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Pe.fromBufferAttribute(this,e),Pe.transformDirection(t),this.setXYZ(e,Pe.x,Pe.y,Pe.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Pn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=he(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Pn(e,this.array)),e}setX(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Pn(e,this.array)),e}setY(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Pn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Pn(e,this.array)),e}setW(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array),s=he(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array),s=he(s,this.array),r=he(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Wc&&(t.usage=this.usage),t}};var so=class extends Ne{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var ro=class extends Ne{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var re=class extends Ne{constructor(t,e,n){super(new Float32Array(t),e,n)}},tm=0,fn=new ue,$l=new ze,bs=new P,ln=new ii,fr=new ii,ke=new P,Re=class i extends Si{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:tm++}),this.uuid=Fn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(ef(t)?ro:so)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Zt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return fn.makeRotationFromQuaternion(t),this.applyMatrix4(fn),this}rotateX(t){return fn.makeRotationX(t),this.applyMatrix4(fn),this}rotateY(t){return fn.makeRotationY(t),this.applyMatrix4(fn),this}rotateZ(t){return fn.makeRotationZ(t),this.applyMatrix4(fn),this}translate(t,e,n){return fn.makeTranslation(t,e,n),this.applyMatrix4(fn),this}scale(t,e,n){return fn.makeScale(t,e,n),this.applyMatrix4(fn),this}lookAt(t){return $l.lookAt(t),$l.updateMatrix(),this.applyMatrix4($l.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(bs).negate(),this.translate(bs.x,bs.y,bs.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let s=0,r=t.length;s<r;s++){let a=t[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new re(n,3))}else{for(let n=0,s=e.count;n<s;n++){let r=t[n];e.setXYZ(n,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ii);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];ln.setFromBufferAttribute(r),this.morphTargetsRelative?(ke.addVectors(this.boundingBox.min,ln.min),this.boundingBox.expandByPoint(ke),ke.addVectors(this.boundingBox.max,ln.max),this.boundingBox.expandByPoint(ke)):(this.boundingBox.expandByPoint(ln.min),this.boundingBox.expandByPoint(ln.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new wi);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(t){let n=this.boundingSphere.center;if(ln.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];fr.setFromBufferAttribute(o),this.morphTargetsRelative?(ke.addVectors(ln.min,fr.min),ln.expandByPoint(ke),ke.addVectors(ln.max,fr.max),ln.expandByPoint(ke)):(ln.expandByPoint(fr.min),ln.expandByPoint(fr.max))}ln.getCenter(n);let s=0;for(let r=0,a=t.count;r<a;r++)ke.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(ke));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)ke.fromBufferAttribute(o,c),l&&(bs.fromBufferAttribute(t,c),ke.add(bs)),s=Math.max(s,n.distanceToSquared(ke))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ne(new Float32Array(4*n.count),4));let a=this.getAttribute("tangent"),o=[],l=[];for(let L=0;L<n.count;L++)o[L]=new P,l[L]=new P;let c=new P,h=new P,u=new P,d=new st,f=new st,g=new st,_=new P,m=new P;function p(L,w,M){c.fromBufferAttribute(n,L),h.fromBufferAttribute(n,w),u.fromBufferAttribute(n,M),d.fromBufferAttribute(r,L),f.fromBufferAttribute(r,w),g.fromBufferAttribute(r,M),h.sub(c),u.sub(c),f.sub(d),g.sub(d);let I=1/(f.x*g.y-g.x*f.y);isFinite(I)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(I),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(I),o[L].add(_),o[w].add(_),o[M].add(_),l[L].add(m),l[w].add(m),l[M].add(m))}let v=this.groups;v.length===0&&(v=[{start:0,count:t.count}]);for(let L=0,w=v.length;L<w;++L){let M=v[L],I=M.start,G=M.count;for(let z=I,W=I+G;z<W;z+=3)p(t.getX(z+0),t.getX(z+1),t.getX(z+2))}let y=new P,x=new P,D=new P,T=new P;function R(L){D.fromBufferAttribute(s,L),T.copy(D);let w=o[L];y.copy(w),y.sub(D.multiplyScalar(D.dot(w))).normalize(),x.crossVectors(T,w);let I=x.dot(l[L])<0?-1:1;a.setXYZW(L,y.x,y.y,y.z,I)}for(let L=0,w=v.length;L<w;++L){let M=v[L],I=M.start,G=M.count;for(let z=I,W=I+G;z<W;z+=3)R(t.getX(z+0)),R(t.getX(z+1)),R(t.getX(z+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Ne(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new P,r=new P,a=new P,o=new P,l=new P,c=new P,h=new P,u=new P;if(t)for(let d=0,f=t.count;d<f;d+=3){let g=t.getX(d+0),_=t.getX(d+1),m=t.getX(d+2);s.fromBufferAttribute(e,g),r.fromBufferAttribute(e,_),a.fromBufferAttribute(e,m),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,m),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)s.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),h.subVectors(a,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)ke.fromBufferAttribute(t,e),ke.normalize(),t.setXYZ(e,ke.x,ke.y,ke.z)}toNonIndexed(){function t(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),f=0,g=0;for(let _=0,m=l.length;_<m;_++){o.isInterleavedBufferAttribute?f=l[_]*o.data.stride+o.offset:f=l[_]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new Ne(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let o in s){let l=s[o],c=t(l,n);e.setAttribute(o,c)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(s[l]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let s=t.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Qu=new ue,Fi=new no,Ea=new wi,td=new P,Ta=new P,Aa=new P,Ra=new P,Xl=new P,Ca=new P,ed=new P,Pa=new P,Me=class extends ze{constructor(t=new Re,e=new Vs){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){Ca.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=o[l],u=r[l];h!==0&&(Xl.fromBufferAttribute(u,t),a?Ca.addScaledVector(Xl,h):Ca.addScaledVector(Xl.sub(e),h))}e.add(Ca)}return e}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Ea.copy(n.boundingSphere),Ea.applyMatrix4(r),Fi.copy(t.ray).recast(t.near),!(Ea.containsPoint(Fi.origin)===!1&&(Fi.intersectSphere(Ea,td)===null||Fi.origin.distanceToSquared(td)>(t.far-t.near)**2))&&(Qu.copy(r).invert(),Fi.copy(t.ray).applyMatrix4(Qu),!(n.boundingBox!==null&&Fi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Fi)))}_computeIntersections(t,e,n){let s,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=a[m.materialIndex],v=Math.max(m.start,f.start),y=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let x=v,D=y;x<D;x+=3){let T=o.getX(x),R=o.getX(x+1),L=o.getX(x+2);s=Ia(this,p,t,n,c,h,u,T,R,L),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(o.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let v=o.getX(m),y=o.getX(m+1),x=o.getX(m+2);s=Ia(this,a,t,n,c,h,u,v,y,x),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=a[m.materialIndex],v=Math.max(m.start,f.start),y=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let x=v,D=y;x<D;x+=3){let T=x,R=x+1,L=x+2;s=Ia(this,p,t,n,c,h,u,T,R,L),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let v=m,y=m+1,x=m+2;s=Ia(this,a,t,n,c,h,u,v,y,x),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}};function em(i,t,e,n,s,r,a,o){let l;if(t.side===$e?l=n.intersectTriangle(a,r,s,!0,o):l=n.intersectTriangle(s,r,a,t.side===Mi,o),l===null)return null;Pa.copy(o),Pa.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(Pa);return c<e.near||c>e.far?null:{distance:c,point:Pa.clone(),object:i}}function Ia(i,t,e,n,s,r,a,o,l,c){i.getVertexPosition(o,Ta),i.getVertexPosition(l,Aa),i.getVertexPosition(c,Ra);let h=em(i,t,e,n,Ta,Aa,Ra,ed);if(h){let u=new P;_i.getBarycoord(ed,Ta,Aa,Ra,u),s&&(h.uv=_i.getInterpolatedAttribute(s,o,l,c,u,new st)),r&&(h.uv1=_i.getInterpolatedAttribute(r,o,l,c,u,new st)),a&&(h.normal=_i.getInterpolatedAttribute(a,o,l,c,u,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a:o,b:l,c,normal:new P,materialIndex:0};_i.getNormal(Ta,Aa,Ra,d.normal),h.face=d,h.barycoord=u}return h}var ri=class i extends Re{constructor(t=1,e=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,f=0;g("z","y","x",-1,-1,n,e,t,a,r,0),g("z","y","x",1,-1,n,e,-t,a,r,1),g("x","z","y",1,1,t,n,e,s,a,2),g("x","z","y",1,-1,t,n,-e,s,a,3),g("x","y","z",1,-1,t,e,n,s,r,4),g("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new re(c,3)),this.setAttribute("normal",new re(h,3)),this.setAttribute("uv",new re(u,2));function g(_,m,p,v,y,x,D,T,R,L,w){let M=x/R,I=D/L,G=x/2,z=D/2,W=T/2,K=R+1,$=L+1,at=0,X=0,ft=new P;for(let yt=0;yt<$;yt++){let At=yt*I-z;for(let Gt=0;Gt<K;Gt++){let ae=Gt*M-G;ft[_]=ae*v,ft[m]=At*y,ft[p]=W,c.push(ft.x,ft.y,ft.z),ft[_]=0,ft[m]=0,ft[p]=T>0?1:-1,h.push(ft.x,ft.y,ft.z),u.push(Gt/R),u.push(1-yt/L),at+=1}}for(let yt=0;yt<L;yt++)for(let At=0;At<R;At++){let Gt=d+At+K*yt,ae=d+At+K*(yt+1),J=d+(At+1)+K*(yt+1),lt=d+(At+1)+K*yt;l.push(Gt,ae,lt),l.push(ae,J,lt),X+=6}o.addGroup(f,X,w),f+=X,d+=at}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Gs(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function Ye(i){let t={};for(let e=0;e<i.length;e++){let n=Gs(i[e]);for(let s in n)t[s]=n[s]}return t}function nm(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function sf(i){let t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:ne.workingColorSpace}var im={clone:Gs,merge:Ye},sm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,rm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,gn=class extends si{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=sm,this.fragmentShader=rm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Gs(t.uniforms),this.uniformsGroups=nm(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},ao=class extends ze{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ue,this.projectionMatrix=new ue,this.projectionMatrixInverse=new ue,this.coordinateSystem=Qn}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},gi=new P,nd=new st,id=new st,Ze=class extends ao{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=Rr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(br*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Rr*2*Math.atan(Math.tan(br*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){gi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(gi.x,gi.y).multiplyScalar(-t/gi.z),gi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(gi.x,gi.y).multiplyScalar(-t/gi.z)}getViewSize(t,e){return this.getViewBounds(t,nd,id),e.subVectors(id,nd)}setViewOffset(t,e,n,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(br*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*s/l,e-=a.offsetY*n/c,s*=a.width/l,n*=a.height/c}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Ms=-90,Ss=1,Yc=class extends ze{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Ze(Ms,Ss,t,e);s.layers=this.layers,this.add(s);let r=new Ze(Ms,Ss,t,e);r.layers=this.layers,this.add(r);let a=new Ze(Ms,Ss,t,e);a.layers=this.layers,this.add(a);let o=new Ze(Ms,Ss,t,e);o.layers=this.layers,this.add(o);let l=new Ze(Ms,Ss,t,e);l.layers=this.layers,this.add(l);let c=new Ze(Ms,Ss,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,a,o,l]=e;for(let c of e)this.remove(c);if(t===Qn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Ka)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;let _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,a),t.setRenderTarget(n,2,s),t.render(e,o),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,c),n.texture.generateMipmaps=_,t.setRenderTarget(n,5,s),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},oo=class extends sn{constructor(t,e,n,s,r,a,o,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:Fs,super(t,e,n,s,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Zc=class extends ni{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new oo(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Nn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ri(5,5,5),r=new gn({name:"CubemapFromEquirect",uniforms:Gs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:$e,blending:vi});r.uniforms.tEquirect.value=e;let a=new Me(s,r),o=e.minFilter;return e.minFilter===Xi&&(e.minFilter=Nn),new Yc(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,s){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,s);t.setRenderTarget(r)}},ql=new P,am=new P,om=new Zt,Kn=class{constructor(t=new P(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=ql.subVectors(n,e).cross(am.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(ql),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||om.getNormalMatrix(t),s=this.coplanarPoint(ql).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},Bi=new wi,La=new P,Cr=class{constructor(t=new Kn,e=new Kn,n=new Kn,s=new Kn,r=new Kn,a=new Kn){this.planes=[t,e,n,s,r,a]}set(t,e,n,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Qn){let n=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],g=s[9],_=s[10],m=s[11],p=s[12],v=s[13],y=s[14],x=s[15];if(n[0].setComponents(l-r,d-c,m-f,x-p).normalize(),n[1].setComponents(l+r,d+c,m+f,x+p).normalize(),n[2].setComponents(l+a,d+h,m+g,x+v).normalize(),n[3].setComponents(l-a,d-h,m-g,x-v).normalize(),n[4].setComponents(l-o,d-u,m-_,x-y).normalize(),e===Qn)n[5].setComponents(l+o,d+u,m+_,x+y).normalize();else if(e===Ka)n[5].setComponents(o,u,_,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Bi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Bi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Bi)}intersectsSprite(t){return Bi.center.set(0,0,0),Bi.radius=.7071067811865476,Bi.applyMatrix4(t.matrixWorld),this.intersectsSphere(Bi)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(La.x=s.normal.x>0?t.max.x:t.min.x,La.y=s.normal.y>0?t.max.y:t.min.y,La.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(La)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function rf(){let i=null,t=!1,e=null,n=null;function s(r,a){e(r,a),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function lm(i){let t=new WeakMap;function e(o,l){let c=o.array,h=o.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),o.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){let h=l.array,u=l.updateRanges;if(i.bindBuffer(c,o),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){let g=u[d],_=u[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++d,u[d]=_)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){let _=u[f];i.bufferSubData(c,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);let l=t.get(o);l&&(i.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){let h=t.get(o);(!h||h.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}let c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:r,update:a}}var ai=class i extends Re{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(s),c=o+1,h=l+1,u=t/o,d=e/l,f=[],g=[],_=[],m=[];for(let p=0;p<h;p++){let v=p*d-a;for(let y=0;y<c;y++){let x=y*u-r;g.push(x,-v,0),_.push(0,0,1),m.push(y/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let v=0;v<o;v++){let y=v+c*p,x=v+c*(p+1),D=v+1+c*(p+1),T=v+1+c*p;f.push(y,x,T),f.push(x,D,T)}this.setIndex(f),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(_,3)),this.setAttribute("uv",new re(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},cm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,hm=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,um=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,dm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,fm=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,pm=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,mm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,gm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,xm=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,_m=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,vm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,ym=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bm=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Mm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Sm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,wm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Em=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Tm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Am=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Rm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Cm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Pm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Im=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Lm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Dm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,km=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Um=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Nm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Om=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Fm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Bm="gl_FragColor = linearToOutputTexel( gl_FragColor );",zm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Hm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Gm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Wm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,$m=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Xm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,qm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Ym=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Zm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Jm=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,jm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Km=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Qm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,t0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,e0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,n0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,i0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,s0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,r0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,a0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,o0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,l0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,c0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,h0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,u0=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,d0=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,f0=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,p0=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,m0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,g0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,x0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,_0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,v0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,y0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,b0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,M0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,S0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,w0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,E0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,T0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,A0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,R0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,C0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,P0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,I0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,L0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,D0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,k0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,U0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,N0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,O0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,F0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,B0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,z0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,H0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,V0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,G0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,W0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,$0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,X0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,q0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Y0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Z0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,J0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,j0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,K0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Q0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,eg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ng=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,ig=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,sg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,rg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ag=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,og=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,lg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ug=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,xg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,_g=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,yg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Mg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Sg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Eg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Ag=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Cg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Pg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ig=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Dg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ug=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ng=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Og=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Fg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,zg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Hg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,jt={alphahash_fragment:cm,alphahash_pars_fragment:hm,alphamap_fragment:um,alphamap_pars_fragment:dm,alphatest_fragment:fm,alphatest_pars_fragment:pm,aomap_fragment:mm,aomap_pars_fragment:gm,batching_pars_vertex:xm,batching_vertex:_m,begin_vertex:vm,beginnormal_vertex:ym,bsdfs:bm,iridescence_fragment:Mm,bumpmap_pars_fragment:Sm,clipping_planes_fragment:wm,clipping_planes_pars_fragment:Em,clipping_planes_pars_vertex:Tm,clipping_planes_vertex:Am,color_fragment:Rm,color_pars_fragment:Cm,color_pars_vertex:Pm,color_vertex:Im,common:Lm,cube_uv_reflection_fragment:Dm,defaultnormal_vertex:km,displacementmap_pars_vertex:Um,displacementmap_vertex:Nm,emissivemap_fragment:Om,emissivemap_pars_fragment:Fm,colorspace_fragment:Bm,colorspace_pars_fragment:zm,envmap_fragment:Hm,envmap_common_pars_fragment:Vm,envmap_pars_fragment:Gm,envmap_pars_vertex:Wm,envmap_physical_pars_fragment:e0,envmap_vertex:$m,fog_vertex:Xm,fog_pars_vertex:qm,fog_fragment:Ym,fog_pars_fragment:Zm,gradientmap_pars_fragment:Jm,lightmap_pars_fragment:jm,lights_lambert_fragment:Km,lights_lambert_pars_fragment:Qm,lights_pars_begin:t0,lights_toon_fragment:n0,lights_toon_pars_fragment:i0,lights_phong_fragment:s0,lights_phong_pars_fragment:r0,lights_physical_fragment:a0,lights_physical_pars_fragment:o0,lights_fragment_begin:l0,lights_fragment_maps:c0,lights_fragment_end:h0,logdepthbuf_fragment:u0,logdepthbuf_pars_fragment:d0,logdepthbuf_pars_vertex:f0,logdepthbuf_vertex:p0,map_fragment:m0,map_pars_fragment:g0,map_particle_fragment:x0,map_particle_pars_fragment:_0,metalnessmap_fragment:v0,metalnessmap_pars_fragment:y0,morphinstance_vertex:b0,morphcolor_vertex:M0,morphnormal_vertex:S0,morphtarget_pars_vertex:w0,morphtarget_vertex:E0,normal_fragment_begin:T0,normal_fragment_maps:A0,normal_pars_fragment:R0,normal_pars_vertex:C0,normal_vertex:P0,normalmap_pars_fragment:I0,clearcoat_normal_fragment_begin:L0,clearcoat_normal_fragment_maps:D0,clearcoat_pars_fragment:k0,iridescence_pars_fragment:U0,opaque_fragment:N0,packing:O0,premultiplied_alpha_fragment:F0,project_vertex:B0,dithering_fragment:z0,dithering_pars_fragment:H0,roughnessmap_fragment:V0,roughnessmap_pars_fragment:G0,shadowmap_pars_fragment:W0,shadowmap_pars_vertex:$0,shadowmap_vertex:X0,shadowmask_pars_fragment:q0,skinbase_vertex:Y0,skinning_pars_vertex:Z0,skinning_vertex:J0,skinnormal_vertex:j0,specularmap_fragment:K0,specularmap_pars_fragment:Q0,tonemapping_fragment:tg,tonemapping_pars_fragment:eg,transmission_fragment:ng,transmission_pars_fragment:ig,uv_pars_fragment:sg,uv_pars_vertex:rg,uv_vertex:ag,worldpos_vertex:og,background_vert:lg,background_frag:cg,backgroundCube_vert:hg,backgroundCube_frag:ug,cube_vert:dg,cube_frag:fg,depth_vert:pg,depth_frag:mg,distanceRGBA_vert:gg,distanceRGBA_frag:xg,equirect_vert:_g,equirect_frag:vg,linedashed_vert:yg,linedashed_frag:bg,meshbasic_vert:Mg,meshbasic_frag:Sg,meshlambert_vert:wg,meshlambert_frag:Eg,meshmatcap_vert:Tg,meshmatcap_frag:Ag,meshnormal_vert:Rg,meshnormal_frag:Cg,meshphong_vert:Pg,meshphong_frag:Ig,meshphysical_vert:Lg,meshphysical_frag:Dg,meshtoon_vert:kg,meshtoon_frag:Ug,points_vert:Ng,points_frag:Og,shadow_vert:Fg,shadow_frag:Bg,sprite_vert:zg,sprite_frag:Hg},pt={common:{diffuse:{value:new Wt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Zt},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Zt}},envmap:{envMap:{value:null},envMapRotation:{value:new Zt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Zt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Zt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Zt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Zt},normalScale:{value:new st(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Zt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Zt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Zt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Zt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Wt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Wt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0},uvTransform:{value:new Zt}},sprite:{diffuse:{value:new Wt(16777215)},opacity:{value:1},center:{value:new st(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Zt},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0}}},Un={basic:{uniforms:Ye([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.fog]),vertexShader:jt.meshbasic_vert,fragmentShader:jt.meshbasic_frag},lambert:{uniforms:Ye([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Wt(0)}}]),vertexShader:jt.meshlambert_vert,fragmentShader:jt.meshlambert_frag},phong:{uniforms:Ye([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Wt(0)},specular:{value:new Wt(1118481)},shininess:{value:30}}]),vertexShader:jt.meshphong_vert,fragmentShader:jt.meshphong_frag},standard:{uniforms:Ye([pt.common,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.roughnessmap,pt.metalnessmap,pt.fog,pt.lights,{emissive:{value:new Wt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag},toon:{uniforms:Ye([pt.common,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.gradientmap,pt.fog,pt.lights,{emissive:{value:new Wt(0)}}]),vertexShader:jt.meshtoon_vert,fragmentShader:jt.meshtoon_frag},matcap:{uniforms:Ye([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,{matcap:{value:null}}]),vertexShader:jt.meshmatcap_vert,fragmentShader:jt.meshmatcap_frag},points:{uniforms:Ye([pt.points,pt.fog]),vertexShader:jt.points_vert,fragmentShader:jt.points_frag},dashed:{uniforms:Ye([pt.common,pt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:jt.linedashed_vert,fragmentShader:jt.linedashed_frag},depth:{uniforms:Ye([pt.common,pt.displacementmap]),vertexShader:jt.depth_vert,fragmentShader:jt.depth_frag},normal:{uniforms:Ye([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,{opacity:{value:1}}]),vertexShader:jt.meshnormal_vert,fragmentShader:jt.meshnormal_frag},sprite:{uniforms:Ye([pt.sprite,pt.fog]),vertexShader:jt.sprite_vert,fragmentShader:jt.sprite_frag},background:{uniforms:{uvTransform:{value:new Zt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:jt.background_vert,fragmentShader:jt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Zt}},vertexShader:jt.backgroundCube_vert,fragmentShader:jt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:jt.cube_vert,fragmentShader:jt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:jt.equirect_vert,fragmentShader:jt.equirect_frag},distanceRGBA:{uniforms:Ye([pt.common,pt.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:jt.distanceRGBA_vert,fragmentShader:jt.distanceRGBA_frag},shadow:{uniforms:Ye([pt.lights,pt.fog,{color:{value:new Wt(0)},opacity:{value:1}}]),vertexShader:jt.shadow_vert,fragmentShader:jt.shadow_frag}};Un.physical={uniforms:Ye([Un.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Zt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Zt},clearcoatNormalScale:{value:new st(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Zt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Zt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Zt},sheen:{value:0},sheenColor:{value:new Wt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Zt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Zt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Zt},transmissionSamplerSize:{value:new st},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Zt},attenuationDistance:{value:0},attenuationColor:{value:new Wt(0)},specularColor:{value:new Wt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Zt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Zt},anisotropyVector:{value:new st},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Zt}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag};var Da={r:0,b:0,g:0},zi=new mn,Vg=new ue;function Gg(i,t,e,n,s,r,a){let o=new Wt(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(v){let y=v.isScene===!0?v.background:null;return y&&y.isTexture&&(y=(v.backgroundBlurriness>0?e:t).get(y)),y}function _(v){let y=!1,x=g(v);x===null?p(o,l):x&&x.isColor&&(p(x,1),y=!0);let D=i.xr.getEnvironmentBlendMode();D==="additive"?n.buffers.color.setClear(0,0,0,1,a):D==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||y)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(v,y){let x=g(y);x&&(x.isCubeTexture||x.mapping===Io)?(h===void 0&&(h=new Me(new ri(1,1,1),new gn({name:"BackgroundCubeMaterial",uniforms:Gs(Un.backgroundCube.uniforms),vertexShader:Un.backgroundCube.vertexShader,fragmentShader:Un.backgroundCube.fragmentShader,side:$e,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(D,T,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),zi.copy(y.backgroundRotation),zi.x*=-1,zi.y*=-1,zi.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(zi.y*=-1,zi.z*=-1),h.material.uniforms.envMap.value=x,h.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=y.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Vg.makeRotationFromEuler(zi)),h.material.toneMapped=ne.getTransfer(x.colorSpace)!==pe,(u!==x||d!==x.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=x,d=x.version,f=i.toneMapping),h.layers.enableAll(),v.unshift(h,h.geometry,h.material,0,0,null)):x&&x.isTexture&&(c===void 0&&(c=new Me(new ai(2,2),new gn({name:"BackgroundMaterial",uniforms:Gs(Un.background.uniforms),vertexShader:Un.background.vertexShader,fragmentShader:Un.background.fragmentShader,side:Mi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=x,c.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,c.material.toneMapped=ne.getTransfer(x.colorSpace)!==pe,x.matrixAutoUpdate===!0&&x.updateMatrix(),c.material.uniforms.uvTransform.value.copy(x.matrix),(u!==x||d!==x.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=x,d=x.version,f=i.toneMapping),c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null))}function p(v,y){v.getRGB(Da,sf(i)),n.buffers.color.setClear(Da.r,Da.g,Da.b,y,a)}return{getClearColor:function(){return o},setClearColor:function(v,y=1){o.set(v),l=y,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(v){l=v,p(o,l)},render:_,addToRenderList:m}}function Wg(i,t){let e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null),r=s,a=!1;function o(M,I,G,z,W){let K=!1,$=u(z,G,I);r!==$&&(r=$,c(r.object)),K=f(M,z,G,W),K&&g(M,z,G,W),W!==null&&t.update(W,i.ELEMENT_ARRAY_BUFFER),(K||a)&&(a=!1,x(M,I,G,z),W!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(W).buffer))}function l(){return i.createVertexArray()}function c(M){return i.bindVertexArray(M)}function h(M){return i.deleteVertexArray(M)}function u(M,I,G){let z=G.wireframe===!0,W=n[M.id];W===void 0&&(W={},n[M.id]=W);let K=W[I.id];K===void 0&&(K={},W[I.id]=K);let $=K[z];return $===void 0&&($=d(l()),K[z]=$),$}function d(M){let I=[],G=[],z=[];for(let W=0;W<e;W++)I[W]=0,G[W]=0,z[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:G,attributeDivisors:z,object:M,attributes:{},index:null}}function f(M,I,G,z){let W=r.attributes,K=I.attributes,$=0,at=G.getAttributes();for(let X in at)if(at[X].location>=0){let yt=W[X],At=K[X];if(At===void 0&&(X==="instanceMatrix"&&M.instanceMatrix&&(At=M.instanceMatrix),X==="instanceColor"&&M.instanceColor&&(At=M.instanceColor)),yt===void 0||yt.attribute!==At||At&&yt.data!==At.data)return!0;$++}return r.attributesNum!==$||r.index!==z}function g(M,I,G,z){let W={},K=I.attributes,$=0,at=G.getAttributes();for(let X in at)if(at[X].location>=0){let yt=K[X];yt===void 0&&(X==="instanceMatrix"&&M.instanceMatrix&&(yt=M.instanceMatrix),X==="instanceColor"&&M.instanceColor&&(yt=M.instanceColor));let At={};At.attribute=yt,yt&&yt.data&&(At.data=yt.data),W[X]=At,$++}r.attributes=W,r.attributesNum=$,r.index=z}function _(){let M=r.newAttributes;for(let I=0,G=M.length;I<G;I++)M[I]=0}function m(M){p(M,0)}function p(M,I){let G=r.newAttributes,z=r.enabledAttributes,W=r.attributeDivisors;G[M]=1,z[M]===0&&(i.enableVertexAttribArray(M),z[M]=1),W[M]!==I&&(i.vertexAttribDivisor(M,I),W[M]=I)}function v(){let M=r.newAttributes,I=r.enabledAttributes;for(let G=0,z=I.length;G<z;G++)I[G]!==M[G]&&(i.disableVertexAttribArray(G),I[G]=0)}function y(M,I,G,z,W,K,$){$===!0?i.vertexAttribIPointer(M,I,G,W,K):i.vertexAttribPointer(M,I,G,z,W,K)}function x(M,I,G,z){_();let W=z.attributes,K=G.getAttributes(),$=I.defaultAttributeValues;for(let at in K){let X=K[at];if(X.location>=0){let ft=W[at];if(ft===void 0&&(at==="instanceMatrix"&&M.instanceMatrix&&(ft=M.instanceMatrix),at==="instanceColor"&&M.instanceColor&&(ft=M.instanceColor)),ft!==void 0){let yt=ft.normalized,At=ft.itemSize,Gt=t.get(ft);if(Gt===void 0)continue;let ae=Gt.buffer,J=Gt.type,lt=Gt.bytesPerElement,Rt=J===i.INT||J===i.UNSIGNED_INT||ft.gpuType===Uh;if(ft.isInterleavedBufferAttribute){let ut=ft.data,Ut=ut.stride,zt=ft.offset;if(ut.isInstancedInterleavedBuffer){for(let Ft=0;Ft<X.locationSize;Ft++)p(X.location+Ft,ut.meshPerAttribute);M.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=ut.meshPerAttribute*ut.count)}else for(let Ft=0;Ft<X.locationSize;Ft++)m(X.location+Ft);i.bindBuffer(i.ARRAY_BUFFER,ae);for(let Ft=0;Ft<X.locationSize;Ft++)y(X.location+Ft,At/X.locationSize,J,yt,Ut*lt,(zt+At/X.locationSize*Ft)*lt,Rt)}else{if(ft.isInstancedBufferAttribute){for(let ut=0;ut<X.locationSize;ut++)p(X.location+ut,ft.meshPerAttribute);M.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=ft.meshPerAttribute*ft.count)}else for(let ut=0;ut<X.locationSize;ut++)m(X.location+ut);i.bindBuffer(i.ARRAY_BUFFER,ae);for(let ut=0;ut<X.locationSize;ut++)y(X.location+ut,At/X.locationSize,J,yt,At*lt,At/X.locationSize*ut*lt,Rt)}}else if($!==void 0){let yt=$[at];if(yt!==void 0)switch(yt.length){case 2:i.vertexAttrib2fv(X.location,yt);break;case 3:i.vertexAttrib3fv(X.location,yt);break;case 4:i.vertexAttrib4fv(X.location,yt);break;default:i.vertexAttrib1fv(X.location,yt)}}}}v()}function D(){L();for(let M in n){let I=n[M];for(let G in I){let z=I[G];for(let W in z)h(z[W].object),delete z[W];delete I[G]}delete n[M]}}function T(M){if(n[M.id]===void 0)return;let I=n[M.id];for(let G in I){let z=I[G];for(let W in z)h(z[W].object),delete z[W];delete I[G]}delete n[M.id]}function R(M){for(let I in n){let G=n[I];if(G[M.id]===void 0)continue;let z=G[M.id];for(let W in z)h(z[W].object),delete z[W];delete G[M.id]}}function L(){w(),a=!0,r!==s&&(r=s,c(r.object))}function w(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:L,resetDefaultState:w,dispose:D,releaseStatesOfGeometry:T,releaseStatesOfProgram:R,initAttributes:_,enableAttribute:m,disableUnusedAttributes:v}}function $g(i,t,e){let n;function s(c){n=c}function r(c,h){i.drawArrays(n,c,h),e.update(h,n,1)}function a(c,h,u){u!==0&&(i.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function o(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];e.update(f,n,1)}function l(c,h,u,d){if(u===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<c.length;g++)a(c[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*d[_];e.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function Xg(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let R=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(R){return!(R!==In&&n.convert(R)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(R){let L=R===Vr&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(R!==ei&&n.convert(R)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&R!==On&&!L)}function l(R){if(R==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=e.logarithmicDepthBuffer===!0,d=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),v=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),y=i.getParameter(i.MAX_VARYING_VECTORS),x=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),D=g>0,T=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:x,vertexTextures:D,maxSamples:T}}function qg(i){let t=this,e=null,n=0,s=!1,r=!1,a=new Kn,o=new Zt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){let g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=i.get(u);if(!s||g===null||g.length===0||r&&!m)r?h(null):c();else{let v=r?0:n,y=v*4,x=p.clippingState||null;l.value=x,x=h(g,d,y,f);for(let D=0;D!==y;++D)x[D]=e[D];p.clippingState=x,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,g){let _=u!==null?u.length:0,m=null;if(_!==0){if(m=l.value,g!==!0||m===null){let p=f+_*4,v=d.matrixWorldInverse;o.getNormalMatrix(v),(m===null||m.length<p)&&(m=new Float32Array(p));for(let y=0,x=f;y!==_;++y,x+=4)a.copy(u[y]).applyMatrix4(v,o),a.normal.toArray(m,x),m[x+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=_,t.numIntersection=0,m}}function Yg(i){let t=new WeakMap;function e(a,o){return o===pc?a.mapping=Fs:o===mc&&(a.mapping=Bs),a}function n(a){if(a&&a.isTexture){let o=a.mapping;if(o===pc||o===mc)if(t.has(a)){let l=t.get(a).texture;return e(l,a.mapping)}else{let l=a.image;if(l&&l.height>0){let c=new Zc(l.height);return c.fromEquirectangularTexture(i,a),t.set(a,c),a.addEventListener("dispose",s),e(c.texture,a.mapping)}else return null}}return a}function s(a){let o=a.target;o.removeEventListener("dispose",s);let l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var lo=class extends ao{constructor(t=-1,e=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,a=n+t,o=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Ps=4,sd=[.125,.215,.35,.446,.526,.582],Wi=20,Yl=new lo,rd=new Wt,Zl=null,Jl=0,jl=0,Kl=!1,Vi=(1+Math.sqrt(5))/2,ws=1/Vi,ad=[new P(-Vi,ws,0),new P(Vi,ws,0),new P(-ws,0,Vi),new P(ws,0,Vi),new P(0,Vi,-ws),new P(0,Vi,ws),new P(-1,1,-1),new P(1,1,-1),new P(-1,1,1),new P(1,1,1)],co=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Zl=this._renderer.getRenderTarget(),Jl=this._renderer.getActiveCubeFace(),jl=this._renderer.getActiveMipmapLevel(),Kl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=cd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ld(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Zl,Jl,jl),this._renderer.xr.enabled=Kl,t.scissorTest=!1,ka(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Fs||t.mapping===Bs?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Zl=this._renderer.getRenderTarget(),Jl=this._renderer.getActiveCubeFace(),jl=this._renderer.getActiveMipmapLevel(),Kl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Nn,minFilter:Nn,generateMipmaps:!1,type:Vr,format:In,colorSpace:qs,depthBuffer:!1},s=od(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=od(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Zg(r)),this._blurMaterial=Jg(r,t,e)}return s}_compileMaterial(t){let e=new Me(this._lodPlanes[0],t);this._renderer.compile(e,Yl)}_sceneToCubeUV(t,e,n,s){let o=new Ze(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(rd),h.toneMapping=yi,h.autoClear=!1;let f=new Vs({name:"PMREM.Background",side:$e,depthWrite:!1,depthTest:!1}),g=new Me(new ri,f),_=!1,m=t.background;m?m.isColor&&(f.color.copy(m),t.background=null,_=!0):(f.color.copy(rd),_=!0);for(let p=0;p<6;p++){let v=p%3;v===0?(o.up.set(0,l[p],0),o.lookAt(c[p],0,0)):v===1?(o.up.set(0,0,l[p]),o.lookAt(0,c[p],0)):(o.up.set(0,l[p],0),o.lookAt(0,0,c[p]));let y=this._cubeSize;ka(s,v*y,p>2?y:0,y,y),h.setRenderTarget(s),_&&h.render(g,o),h.render(t,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=m}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===Fs||t.mapping===Bs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=cd()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ld());let r=s?this._cubemapMaterial:this._equirectMaterial,a=new Me(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let l=this._cubeSize;ka(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,Yl)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let s=this._lodPlanes.length;for(let r=1;r<s;r++){let a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=ad[(s-r-1)%ad.length];this._blur(t,r-1,r,a,o)}e.autoClear=n}_blur(t,e,n,s,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,s,"latitudinal",r),this._halfBlur(a,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new Me(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*Wi-1),_=r/g,m=isFinite(r)?1+Math.floor(h*_):Wi;m>Wi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Wi}`);let p=[],v=0;for(let R=0;R<Wi;++R){let L=R/_,w=Math.exp(-L*L/2);p.push(w),R===0?v+=w:R<m&&(v+=2*w)}for(let R=0;R<p.length;R++)p[R]=p[R]/v;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:y}=this;d.dTheta.value=g,d.mipInt.value=y-n;let x=this._sizeLods[s],D=3*x*(s>y-Ps?s-y+Ps:0),T=4*(this._cubeSize-x);ka(e,D,T,3*x,2*x),l.setRenderTarget(e),l.render(u,Yl)}};function Zg(i){let t=[],e=[],n=[],s=i,r=i-Ps+1+sd.length;for(let a=0;a<r;a++){let o=Math.pow(2,s);e.push(o);let l=1/o;a>i-Ps?l=sd[a-i+Ps-1]:a===0&&(l=0),n.push(l);let c=1/(o-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,_=3,m=2,p=1,v=new Float32Array(_*g*f),y=new Float32Array(m*g*f),x=new Float32Array(p*g*f);for(let T=0;T<f;T++){let R=T%3*2/3-1,L=T>2?0:-1,w=[R,L,0,R+2/3,L,0,R+2/3,L+1,0,R,L,0,R+2/3,L+1,0,R,L+1,0];v.set(w,_*g*T),y.set(d,m*g*T);let M=[T,T,T,T,T,T];x.set(M,p*g*T)}let D=new Re;D.setAttribute("position",new Ne(v,_)),D.setAttribute("uv",new Ne(y,m)),D.setAttribute("faceIndex",new Ne(x,p)),t.push(D),s>Ps&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function od(i,t,e){let n=new ni(i,t,e);return n.texture.mapping=Io,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ka(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function Jg(i,t,e){let n=new Float32Array(Wi),s=new P(0,1,0);return new gn({name:"SphericalGaussianBlur",defines:{n:Wi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Gh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:vi,depthTest:!1,depthWrite:!1})}function ld(){return new gn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Gh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:vi,depthTest:!1,depthWrite:!1})}function cd(){return new gn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Gh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:vi,depthTest:!1,depthWrite:!1})}function Gh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function jg(i){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){let l=o.mapping,c=l===pc||l===mc,h=l===Fs||l===Bs;if(c||h){let u=t.get(o),d=u!==void 0?u.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==d)return e===null&&(e=new co(i)),u=c?e.fromEquirectangular(o,u):e.fromCubemap(o,u),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),u.texture;if(u!==void 0)return u.texture;{let f=o.image;return c&&f&&f.height>0||h&&f&&s(f)?(e===null&&(e=new co(i)),u=c?e.fromEquirectangular(o):e.fromCubemap(o),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),o.addEventListener("dispose",r),u.texture):null}}}return o}function s(o){let l=0,c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function r(o){let l=o.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function Kg(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let s=e(n);return s===null&&vr("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Qg(i,t,e,n){let s={},r=new WeakMap;function a(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let g in d.attributes)t.remove(d.attributes[g]);for(let g in d.morphAttributes){let _=d.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)t.remove(_[m])}d.removeEventListener("dispose",a),delete s[d.id];let f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(u,d){return s[d.id]===!0||(d.addEventListener("dispose",a),s[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)t.update(d[g],i.ARRAY_BUFFER);let f=u.morphAttributes;for(let g in f){let _=f[g];for(let m=0,p=_.length;m<p;m++)t.update(_[m],i.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,g=u.attributes.position,_=0;if(f!==null){let v=f.array;_=f.version;for(let y=0,x=v.length;y<x;y+=3){let D=v[y+0],T=v[y+1],R=v[y+2];d.push(D,T,T,R,R,D)}}else if(g!==void 0){let v=g.array;_=g.version;for(let y=0,x=v.length/3-1;y<x;y+=3){let D=y+0,T=y+1,R=y+2;d.push(D,T,T,R,R,D)}}else return;let m=new(ef(d)?ro:so)(d,1);m.version=_;let p=r.get(u);p&&t.remove(p),r.set(u,m)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function tx(i,t,e){let n;function s(d){n=d}let r,a;function o(d){r=d.type,a=d.bytesPerElement}function l(d,f){i.drawElements(n,f,r,d*a),e.update(f,n,1)}function c(d,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,d*a,g),e.update(f,n,g))}function h(d,f,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];e.update(m,n,1)}function u(d,f,g,_){if(g===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)c(d[p]/a,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,_,0,g);let p=0;for(let v=0;v<g;v++)p+=f[v]*_[v];e.update(p,n,1)}}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function ex(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case i.TRIANGLES:e.triangles+=o*(r/3);break;case i.LINES:e.lines+=o*(r/2);break;case i.LINE_STRIP:e.lines+=o*(r-1);break;case i.LINE_LOOP:e.lines+=o*r;break;case i.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function nx(i,t,e){let n=new WeakMap,s=new Te;function r(a,o,l){let c=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(o);if(d===void 0||d.count!==u){let w=function(){R.dispose(),n.delete(o),o.removeEventListener("dispose",w)};d!==void 0&&d.texture.dispose();let f=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,_=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],p=o.morphAttributes.normal||[],v=o.morphAttributes.color||[],y=0;f===!0&&(y=1),g===!0&&(y=2),_===!0&&(y=3);let x=o.attributes.position.count*y,D=1;x>t.maxTextureSize&&(D=Math.ceil(x/t.maxTextureSize),x=t.maxTextureSize);let T=new Float32Array(x*D*4*u),R=new eo(T,x,D,u);R.type=On,R.needsUpdate=!0;let L=y*4;for(let M=0;M<u;M++){let I=m[M],G=p[M],z=v[M],W=x*D*4*M;for(let K=0;K<I.count;K++){let $=K*L;f===!0&&(s.fromBufferAttribute(I,K),T[W+$+0]=s.x,T[W+$+1]=s.y,T[W+$+2]=s.z,T[W+$+3]=0),g===!0&&(s.fromBufferAttribute(G,K),T[W+$+4]=s.x,T[W+$+5]=s.y,T[W+$+6]=s.z,T[W+$+7]=0),_===!0&&(s.fromBufferAttribute(z,K),T[W+$+8]=s.x,T[W+$+9]=s.y,T[W+$+10]=s.z,T[W+$+11]=z.itemSize===4?s.w:1)}}d={count:u,texture:R,size:new st(x,D)},n.set(o,d),o.addEventListener("dispose",w)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,e);else{let f=0;for(let _=0;_<c.length;_++)f+=c[_];let g=o.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function ix(i,t,e,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(s.get(u)!==c&&(t.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),s.get(l)!==c&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function a(){s=new WeakMap}function o(l){let c=l.target;c.removeEventListener("dispose",o),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:a}}var ho=class extends sn{constructor(t,e,n,s,r,a,o,l,c,h=Ds){if(h!==Ds&&h!==Hs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===Ds&&(n=qi),n===void 0&&h===Hs&&(n=zs),super(null,s,r,a,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:cn,this.minFilter=l!==void 0?l:cn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},af=new sn,hd=new ho(1,1),of=new eo,lf=new qc,cf=new oo,ud=[],dd=[],fd=new Float32Array(16),pd=new Float32Array(9),md=new Float32Array(4);function Ys(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=ud[s];if(r===void 0&&(r=new Float32Array(s),ud[s]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,i[a].toArray(r,o)}return r}function Le(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function De(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Do(i,t){let e=dd[t];e===void 0&&(e=new Int32Array(t),dd[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function sx(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function rx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Le(e,t))return;i.uniform2fv(this.addr,t),De(e,t)}}function ax(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Le(e,t))return;i.uniform3fv(this.addr,t),De(e,t)}}function ox(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Le(e,t))return;i.uniform4fv(this.addr,t),De(e,t)}}function lx(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Le(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),De(e,t)}else{if(Le(e,n))return;md.set(n),i.uniformMatrix2fv(this.addr,!1,md),De(e,n)}}function cx(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Le(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),De(e,t)}else{if(Le(e,n))return;pd.set(n),i.uniformMatrix3fv(this.addr,!1,pd),De(e,n)}}function hx(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Le(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),De(e,t)}else{if(Le(e,n))return;fd.set(n),i.uniformMatrix4fv(this.addr,!1,fd),De(e,n)}}function ux(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function dx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Le(e,t))return;i.uniform2iv(this.addr,t),De(e,t)}}function fx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Le(e,t))return;i.uniform3iv(this.addr,t),De(e,t)}}function px(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Le(e,t))return;i.uniform4iv(this.addr,t),De(e,t)}}function mx(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function gx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Le(e,t))return;i.uniform2uiv(this.addr,t),De(e,t)}}function xx(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Le(e,t))return;i.uniform3uiv(this.addr,t),De(e,t)}}function _x(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Le(e,t))return;i.uniform4uiv(this.addr,t),De(e,t)}}function vx(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(hd.compareFunction=Kd,r=hd):r=af,e.setTexture2D(t||r,s)}function yx(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||lf,s)}function bx(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||cf,s)}function Mx(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||of,s)}function Sx(i){switch(i){case 5126:return sx;case 35664:return rx;case 35665:return ax;case 35666:return ox;case 35674:return lx;case 35675:return cx;case 35676:return hx;case 5124:case 35670:return ux;case 35667:case 35671:return dx;case 35668:case 35672:return fx;case 35669:case 35673:return px;case 5125:return mx;case 36294:return gx;case 36295:return xx;case 36296:return _x;case 35678:case 36198:case 36298:case 36306:case 35682:return vx;case 35679:case 36299:case 36307:return yx;case 35680:case 36300:case 36308:case 36293:return bx;case 36289:case 36303:case 36311:case 36292:return Mx}}function wx(i,t){i.uniform1fv(this.addr,t)}function Ex(i,t){let e=Ys(t,this.size,2);i.uniform2fv(this.addr,e)}function Tx(i,t){let e=Ys(t,this.size,3);i.uniform3fv(this.addr,e)}function Ax(i,t){let e=Ys(t,this.size,4);i.uniform4fv(this.addr,e)}function Rx(i,t){let e=Ys(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Cx(i,t){let e=Ys(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Px(i,t){let e=Ys(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Ix(i,t){i.uniform1iv(this.addr,t)}function Lx(i,t){i.uniform2iv(this.addr,t)}function Dx(i,t){i.uniform3iv(this.addr,t)}function kx(i,t){i.uniform4iv(this.addr,t)}function Ux(i,t){i.uniform1uiv(this.addr,t)}function Nx(i,t){i.uniform2uiv(this.addr,t)}function Ox(i,t){i.uniform3uiv(this.addr,t)}function Fx(i,t){i.uniform4uiv(this.addr,t)}function Bx(i,t,e){let n=this.cache,s=t.length,r=Do(e,s);Le(n,r)||(i.uniform1iv(this.addr,r),De(n,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||af,r[a])}function zx(i,t,e){let n=this.cache,s=t.length,r=Do(e,s);Le(n,r)||(i.uniform1iv(this.addr,r),De(n,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||lf,r[a])}function Hx(i,t,e){let n=this.cache,s=t.length,r=Do(e,s);Le(n,r)||(i.uniform1iv(this.addr,r),De(n,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||cf,r[a])}function Vx(i,t,e){let n=this.cache,s=t.length,r=Do(e,s);Le(n,r)||(i.uniform1iv(this.addr,r),De(n,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||of,r[a])}function Gx(i){switch(i){case 5126:return wx;case 35664:return Ex;case 35665:return Tx;case 35666:return Ax;case 35674:return Rx;case 35675:return Cx;case 35676:return Px;case 5124:case 35670:return Ix;case 35667:case 35671:return Lx;case 35668:case 35672:return Dx;case 35669:case 35673:return kx;case 5125:return Ux;case 36294:return Nx;case 36295:return Ox;case 36296:return Fx;case 35678:case 36198:case 36298:case 36306:case 35682:return Bx;case 35679:case 36299:case 36307:return zx;case 35680:case 36300:case 36308:case 36293:return Hx;case 36289:case 36303:case 36311:case 36292:return Vx}}var Jc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Sx(e.type)}},jc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Gx(e.type)}},Kc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],n)}}},Ql=/(\w+)(\])?(\[|\.)?/g;function gd(i,t){i.seq.push(t),i.map[t.id]=t}function Wx(i,t,e){let n=i.name,s=n.length;for(Ql.lastIndex=0;;){let r=Ql.exec(n),a=Ql.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===s){gd(e,c===void 0?new Jc(o,i,t):new jc(o,i,t));break}else{let u=e.map[o];u===void 0&&(u=new Kc(o),gd(e,u)),e=u}}}var Us=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);Wx(r,a,this)}}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&n.push(a)}return n}};function xd(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var $x=37297,Xx=0;function qx(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}var _d=new Zt;function Yx(i){ne._getMatrix(_d,ne.workingColorSpace,i);let t=`mat3( ${_d.elements.map(e=>e.toFixed(4))} )`;switch(ne.getTransfer(i)){case Lo:return[t,"LinearTransferOETF"];case pe:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function vd(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+qx(i.getShaderSource(t),a)}else return s}function Zx(i,t){let e=Yx(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Jx(i,t){let e;switch(t){case ap:e="Linear";break;case op:e="Reinhard";break;case lp:e="Cineon";break;case cp:e="ACESFilmic";break;case up:e="AgX";break;case dp:e="Neutral";break;case hp:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var Ua=new P;function jx(){ne.getLuminanceCoefficients(Ua);let i=Ua.x.toFixed(4),t=Ua.y.toFixed(4),e=Ua.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Kx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(yr).join(`
`)}function Qx(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function t_(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),a=r.name,o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:i.getAttribLocation(t,a),locationSize:o}}return e}function yr(i){return i!==""}function yd(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function bd(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var e_=/^[ \t]*#include +<([\w\d./]+)>/gm;function Qc(i){return i.replace(e_,i_)}var n_=new Map;function i_(i,t){let e=jt[t];if(e===void 0){let n=n_.get(t);if(n!==void 0)e=jt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Qc(e)}var s_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Md(i){return i.replace(s_,r_)}function r_(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Sd(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function a_(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===zd?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Dh?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===jn&&(t="SHADOWMAP_TYPE_VSM"),t}function o_(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Fs:case Bs:t="ENVMAP_TYPE_CUBE";break;case Io:t="ENVMAP_TYPE_CUBE_UV";break}return t}function l_(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Bs:t="ENVMAP_MODE_REFRACTION";break}return t}function c_(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case kh:t="ENVMAP_BLENDING_MULTIPLY";break;case sp:t="ENVMAP_BLENDING_MIX";break;case rp:t="ENVMAP_BLENDING_ADD";break}return t}function h_(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function u_(i,t,e,n){let s=i.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,l=a_(e),c=o_(e),h=l_(e),u=c_(e),d=h_(e),f=Kx(e),g=Qx(r),_=s.createProgram(),m,p,v=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(yr).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(yr).join(`
`),p.length>0&&(p+=`
`)):(m=[Sd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(yr).join(`
`),p=[Sd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==yi?"#define TONE_MAPPING":"",e.toneMapping!==yi?jt.tonemapping_pars_fragment:"",e.toneMapping!==yi?Jx("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",jt.colorspace_pars_fragment,Zx("linearToOutputTexel",e.outputColorSpace),jx(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(yr).join(`
`)),a=Qc(a),a=yd(a,e),a=bd(a,e),o=Qc(o),o=yd(o,e),o=bd(o,e),a=Md(a),o=Md(o),e.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",e.glslVersion===Nu?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Nu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let y=v+m+a,x=v+p+o,D=xd(s,s.VERTEX_SHADER,y),T=xd(s,s.FRAGMENT_SHADER,x);s.attachShader(_,D),s.attachShader(_,T),e.index0AttributeName!==void 0?s.bindAttribLocation(_,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function R(I){if(i.debug.checkShaderErrors){let G=s.getProgramInfoLog(_).trim(),z=s.getShaderInfoLog(D).trim(),W=s.getShaderInfoLog(T).trim(),K=!0,$=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(K=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,D,T);else{let at=vd(s,D,"vertex"),X=vd(s,T,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+I.name+`
Material Type: `+I.type+`

Program Info Log: `+G+`
`+at+`
`+X)}else G!==""?console.warn("THREE.WebGLProgram: Program Info Log:",G):(z===""||W==="")&&($=!1);$&&(I.diagnostics={runnable:K,programLog:G,vertexShader:{log:z,prefix:m},fragmentShader:{log:W,prefix:p}})}s.deleteShader(D),s.deleteShader(T),L=new Us(s,_),w=t_(s,_)}let L;this.getUniforms=function(){return L===void 0&&R(this),L};let w;this.getAttributes=function(){return w===void 0&&R(this),w};let M=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=s.getProgramParameter(_,$x)),M},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Xx++,this.cacheKey=t,this.usedTimes=1,this.program=_,this.vertexShader=D,this.fragmentShader=T,this}var d_=0,th=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new eh(t),e.set(t,n)),n}},eh=class{constructor(t){this.id=d_++,this.code=t,this.usedTimes=0}};function f_(i,t,e,n,s,r,a){let o=new io,l=new th,c=new Set,h=[],u=s.logarithmicDepthBuffer,d=s.vertexTextures,f=s.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(w){return c.add(w),w===0?"uv":`uv${w}`}function m(w,M,I,G,z){let W=G.fog,K=z.geometry,$=w.isMeshStandardMaterial?G.environment:null,at=(w.isMeshStandardMaterial?e:t).get(w.envMap||$),X=at&&at.mapping===Io?at.image.height:null,ft=g[w.type];w.precision!==null&&(f=s.getMaxPrecision(w.precision),f!==w.precision&&console.warn("THREE.WebGLProgram.getParameters:",w.precision,"not supported, using",f,"instead."));let yt=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,At=yt!==void 0?yt.length:0,Gt=0;K.morphAttributes.position!==void 0&&(Gt=1),K.morphAttributes.normal!==void 0&&(Gt=2),K.morphAttributes.color!==void 0&&(Gt=3);let ae,J,lt,Rt;if(ft){let ce=Un[ft];ae=ce.vertexShader,J=ce.fragmentShader}else ae=w.vertexShader,J=w.fragmentShader,l.update(w),lt=l.getVertexShaderID(w),Rt=l.getFragmentShaderID(w);let ut=i.getRenderTarget(),Ut=i.state.buffers.depth.getReversed(),zt=z.isInstancedMesh===!0,Ft=z.isBatchedMesh===!0,ee=!!w.map,tt=!!w.matcap,ot=!!at,C=!!w.aoMap,Dt=!!w.lightMap,it=!!w.bumpMap,St=!!w.normalMap,dt=!!w.displacementMap,Nt=!!w.emissiveMap,bt=!!w.metalnessMap,E=!!w.roughnessMap,b=w.anisotropy>0,B=w.clearcoat>0,Y=w.dispersion>0,et=w.iridescence>0,Z=w.sheen>0,Ct=w.transmission>0,mt=b&&!!w.anisotropyMap,Mt=B&&!!w.clearcoatMap,Kt=B&&!!w.clearcoatNormalMap,rt=B&&!!w.clearcoatRoughnessMap,Et=et&&!!w.iridescenceMap,Ot=et&&!!w.iridescenceThicknessMap,Bt=Z&&!!w.sheenColorMap,Tt=Z&&!!w.sheenRoughnessMap,te=!!w.specularMap,Jt=!!w.specularColorMap,ge=!!w.specularIntensityMap,N=Ct&&!!w.transmissionMap,gt=Ct&&!!w.thicknessMap,q=!!w.gradientMap,Q=!!w.alphaMap,vt=w.alphaTest>0,xt=!!w.alphaHash,Xt=!!w.extensions,Ee=yi;w.toneMapped&&(ut===null||ut.isXRRenderTarget===!0)&&(Ee=i.toneMapping);let Ve={shaderID:ft,shaderType:w.type,shaderName:w.name,vertexShader:ae,fragmentShader:J,defines:w.defines,customVertexShaderID:lt,customFragmentShaderID:Rt,isRawShaderMaterial:w.isRawShaderMaterial===!0,glslVersion:w.glslVersion,precision:f,batching:Ft,batchingColor:Ft&&z._colorsTexture!==null,instancing:zt,instancingColor:zt&&z.instanceColor!==null,instancingMorph:zt&&z.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:ut===null?i.outputColorSpace:ut.isXRRenderTarget===!0?ut.texture.colorSpace:qs,alphaToCoverage:!!w.alphaToCoverage,map:ee,matcap:tt,envMap:ot,envMapMode:ot&&at.mapping,envMapCubeUVHeight:X,aoMap:C,lightMap:Dt,bumpMap:it,normalMap:St,displacementMap:d&&dt,emissiveMap:Nt,normalMapObjectSpace:St&&w.normalMapType===gp,normalMapTangentSpace:St&&w.normalMapType===jd,metalnessMap:bt,roughnessMap:E,anisotropy:b,anisotropyMap:mt,clearcoat:B,clearcoatMap:Mt,clearcoatNormalMap:Kt,clearcoatRoughnessMap:rt,dispersion:Y,iridescence:et,iridescenceMap:Et,iridescenceThicknessMap:Ot,sheen:Z,sheenColorMap:Bt,sheenRoughnessMap:Tt,specularMap:te,specularColorMap:Jt,specularIntensityMap:ge,transmission:Ct,transmissionMap:N,thicknessMap:gt,gradientMap:q,opaque:w.transparent===!1&&w.blending===Ls&&w.alphaToCoverage===!1,alphaMap:Q,alphaTest:vt,alphaHash:xt,combine:w.combine,mapUv:ee&&_(w.map.channel),aoMapUv:C&&_(w.aoMap.channel),lightMapUv:Dt&&_(w.lightMap.channel),bumpMapUv:it&&_(w.bumpMap.channel),normalMapUv:St&&_(w.normalMap.channel),displacementMapUv:dt&&_(w.displacementMap.channel),emissiveMapUv:Nt&&_(w.emissiveMap.channel),metalnessMapUv:bt&&_(w.metalnessMap.channel),roughnessMapUv:E&&_(w.roughnessMap.channel),anisotropyMapUv:mt&&_(w.anisotropyMap.channel),clearcoatMapUv:Mt&&_(w.clearcoatMap.channel),clearcoatNormalMapUv:Kt&&_(w.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:rt&&_(w.clearcoatRoughnessMap.channel),iridescenceMapUv:Et&&_(w.iridescenceMap.channel),iridescenceThicknessMapUv:Ot&&_(w.iridescenceThicknessMap.channel),sheenColorMapUv:Bt&&_(w.sheenColorMap.channel),sheenRoughnessMapUv:Tt&&_(w.sheenRoughnessMap.channel),specularMapUv:te&&_(w.specularMap.channel),specularColorMapUv:Jt&&_(w.specularColorMap.channel),specularIntensityMapUv:ge&&_(w.specularIntensityMap.channel),transmissionMapUv:N&&_(w.transmissionMap.channel),thicknessMapUv:gt&&_(w.thicknessMap.channel),alphaMapUv:Q&&_(w.alphaMap.channel),vertexTangents:!!K.attributes.tangent&&(St||b),vertexColors:w.vertexColors,vertexAlphas:w.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,pointsUvs:z.isPoints===!0&&!!K.attributes.uv&&(ee||Q),fog:!!W,useFog:w.fog===!0,fogExp2:!!W&&W.isFogExp2,flatShading:w.flatShading===!0,sizeAttenuation:w.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:Ut,skinning:z.isSkinnedMesh===!0,morphTargets:K.morphAttributes.position!==void 0,morphNormals:K.morphAttributes.normal!==void 0,morphColors:K.morphAttributes.color!==void 0,morphTargetsCount:At,morphTextureStride:Gt,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:w.dithering,shadowMapEnabled:i.shadowMap.enabled&&I.length>0,shadowMapType:i.shadowMap.type,toneMapping:Ee,decodeVideoTexture:ee&&w.map.isVideoTexture===!0&&ne.getTransfer(w.map.colorSpace)===pe,decodeVideoTextureEmissive:Nt&&w.emissiveMap.isVideoTexture===!0&&ne.getTransfer(w.emissiveMap.colorSpace)===pe,premultipliedAlpha:w.premultipliedAlpha,doubleSided:w.side===pn,flipSided:w.side===$e,useDepthPacking:w.depthPacking>=0,depthPacking:w.depthPacking||0,index0AttributeName:w.index0AttributeName,extensionClipCullDistance:Xt&&w.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Xt&&w.extensions.multiDraw===!0||Ft)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:w.customProgramCacheKey()};return Ve.vertexUv1s=c.has(1),Ve.vertexUv2s=c.has(2),Ve.vertexUv3s=c.has(3),c.clear(),Ve}function p(w){let M=[];if(w.shaderID?M.push(w.shaderID):(M.push(w.customVertexShaderID),M.push(w.customFragmentShaderID)),w.defines!==void 0)for(let I in w.defines)M.push(I),M.push(w.defines[I]);return w.isRawShaderMaterial===!1&&(v(M,w),y(M,w),M.push(i.outputColorSpace)),M.push(w.customProgramCacheKey),M.join()}function v(w,M){w.push(M.precision),w.push(M.outputColorSpace),w.push(M.envMapMode),w.push(M.envMapCubeUVHeight),w.push(M.mapUv),w.push(M.alphaMapUv),w.push(M.lightMapUv),w.push(M.aoMapUv),w.push(M.bumpMapUv),w.push(M.normalMapUv),w.push(M.displacementMapUv),w.push(M.emissiveMapUv),w.push(M.metalnessMapUv),w.push(M.roughnessMapUv),w.push(M.anisotropyMapUv),w.push(M.clearcoatMapUv),w.push(M.clearcoatNormalMapUv),w.push(M.clearcoatRoughnessMapUv),w.push(M.iridescenceMapUv),w.push(M.iridescenceThicknessMapUv),w.push(M.sheenColorMapUv),w.push(M.sheenRoughnessMapUv),w.push(M.specularMapUv),w.push(M.specularColorMapUv),w.push(M.specularIntensityMapUv),w.push(M.transmissionMapUv),w.push(M.thicknessMapUv),w.push(M.combine),w.push(M.fogExp2),w.push(M.sizeAttenuation),w.push(M.morphTargetsCount),w.push(M.morphAttributeCount),w.push(M.numDirLights),w.push(M.numPointLights),w.push(M.numSpotLights),w.push(M.numSpotLightMaps),w.push(M.numHemiLights),w.push(M.numRectAreaLights),w.push(M.numDirLightShadows),w.push(M.numPointLightShadows),w.push(M.numSpotLightShadows),w.push(M.numSpotLightShadowsWithMaps),w.push(M.numLightProbes),w.push(M.shadowMapType),w.push(M.toneMapping),w.push(M.numClippingPlanes),w.push(M.numClipIntersection),w.push(M.depthPacking)}function y(w,M){o.disableAll(),M.supportsVertexTextures&&o.enable(0),M.instancing&&o.enable(1),M.instancingColor&&o.enable(2),M.instancingMorph&&o.enable(3),M.matcap&&o.enable(4),M.envMap&&o.enable(5),M.normalMapObjectSpace&&o.enable(6),M.normalMapTangentSpace&&o.enable(7),M.clearcoat&&o.enable(8),M.iridescence&&o.enable(9),M.alphaTest&&o.enable(10),M.vertexColors&&o.enable(11),M.vertexAlphas&&o.enable(12),M.vertexUv1s&&o.enable(13),M.vertexUv2s&&o.enable(14),M.vertexUv3s&&o.enable(15),M.vertexTangents&&o.enable(16),M.anisotropy&&o.enable(17),M.alphaHash&&o.enable(18),M.batching&&o.enable(19),M.dispersion&&o.enable(20),M.batchingColor&&o.enable(21),w.push(o.mask),o.disableAll(),M.fog&&o.enable(0),M.useFog&&o.enable(1),M.flatShading&&o.enable(2),M.logarithmicDepthBuffer&&o.enable(3),M.reverseDepthBuffer&&o.enable(4),M.skinning&&o.enable(5),M.morphTargets&&o.enable(6),M.morphNormals&&o.enable(7),M.morphColors&&o.enable(8),M.premultipliedAlpha&&o.enable(9),M.shadowMapEnabled&&o.enable(10),M.doubleSided&&o.enable(11),M.flipSided&&o.enable(12),M.useDepthPacking&&o.enable(13),M.dithering&&o.enable(14),M.transmission&&o.enable(15),M.sheen&&o.enable(16),M.opaque&&o.enable(17),M.pointsUvs&&o.enable(18),M.decodeVideoTexture&&o.enable(19),M.decodeVideoTextureEmissive&&o.enable(20),M.alphaToCoverage&&o.enable(21),w.push(o.mask)}function x(w){let M=g[w.type],I;if(M){let G=Un[M];I=im.clone(G.uniforms)}else I=w.uniforms;return I}function D(w,M){let I;for(let G=0,z=h.length;G<z;G++){let W=h[G];if(W.cacheKey===M){I=W,++I.usedTimes;break}}return I===void 0&&(I=new u_(i,M,w,r),h.push(I)),I}function T(w){if(--w.usedTimes===0){let M=h.indexOf(w);h[M]=h[h.length-1],h.pop(),w.destroy()}}function R(w){l.remove(w)}function L(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:x,acquireProgram:D,releaseProgram:T,releaseShaderCache:R,programs:h,dispose:L}}function p_(){let i=new WeakMap;function t(a){return i.has(a)}function e(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,l){i.get(a)[o]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function m_(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function wd(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Ed(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function a(u,d,f,g,_,m){let p=i[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},i[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),t++,p}function o(u,d,f,g,_,m){let p=a(u,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):e.push(p)}function l(u,d,f,g,_,m){let p=a(u,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):e.unshift(p)}function c(u,d){e.length>1&&e.sort(u||m_),n.length>1&&n.sort(d||wd),s.length>1&&s.sort(d||wd)}function h(){for(let u=t,d=i.length;u<d;u++){let f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:o,unshift:l,finish:h,sort:c}}function g_(){let i=new WeakMap;function t(n,s){let r=i.get(n),a;return r===void 0?(a=new Ed,i.set(n,[a])):s>=r.length?(a=new Ed,r.push(a)):a=r[s],a}function e(){i=new WeakMap}return{get:t,dispose:e}}function x_(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new P,color:new Wt};break;case"SpotLight":e={position:new P,direction:new P,color:new Wt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new P,color:new Wt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new P,skyColor:new Wt,groundColor:new Wt};break;case"RectAreaLight":e={color:new Wt,position:new P,halfWidth:new P,halfHeight:new P};break}return i[t.id]=e,e}}}function __(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new st};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new st};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new st,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var v_=0;function y_(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function b_(i){let t=new x_,e=__(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new P);let s=new P,r=new ue,a=new ue;function o(c){let h=0,u=0,d=0;for(let w=0;w<9;w++)n.probe[w].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,v=0,y=0,x=0,D=0,T=0,R=0;c.sort(y_);for(let w=0,M=c.length;w<M;w++){let I=c[w],G=I.color,z=I.intensity,W=I.distance,K=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)h+=G.r*z,u+=G.g*z,d+=G.b*z;else if(I.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(I.sh.coefficients[$],z);R++}else if(I.isDirectionalLight){let $=t.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),I.castShadow){let at=I.shadow,X=e.get(I);X.shadowIntensity=at.intensity,X.shadowBias=at.bias,X.shadowNormalBias=at.normalBias,X.shadowRadius=at.radius,X.shadowMapSize=at.mapSize,n.directionalShadow[f]=X,n.directionalShadowMap[f]=K,n.directionalShadowMatrix[f]=I.shadow.matrix,v++}n.directional[f]=$,f++}else if(I.isSpotLight){let $=t.get(I);$.position.setFromMatrixPosition(I.matrixWorld),$.color.copy(G).multiplyScalar(z),$.distance=W,$.coneCos=Math.cos(I.angle),$.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),$.decay=I.decay,n.spot[_]=$;let at=I.shadow;if(I.map&&(n.spotLightMap[D]=I.map,D++,at.updateMatrices(I),I.castShadow&&T++),n.spotLightMatrix[_]=at.matrix,I.castShadow){let X=e.get(I);X.shadowIntensity=at.intensity,X.shadowBias=at.bias,X.shadowNormalBias=at.normalBias,X.shadowRadius=at.radius,X.shadowMapSize=at.mapSize,n.spotShadow[_]=X,n.spotShadowMap[_]=K,x++}_++}else if(I.isRectAreaLight){let $=t.get(I);$.color.copy(G).multiplyScalar(z),$.halfWidth.set(I.width*.5,0,0),$.halfHeight.set(0,I.height*.5,0),n.rectArea[m]=$,m++}else if(I.isPointLight){let $=t.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),$.distance=I.distance,$.decay=I.decay,I.castShadow){let at=I.shadow,X=e.get(I);X.shadowIntensity=at.intensity,X.shadowBias=at.bias,X.shadowNormalBias=at.normalBias,X.shadowRadius=at.radius,X.shadowMapSize=at.mapSize,X.shadowCameraNear=at.camera.near,X.shadowCameraFar=at.camera.far,n.pointShadow[g]=X,n.pointShadowMap[g]=K,n.pointShadowMatrix[g]=I.shadow.matrix,y++}n.point[g]=$,g++}else if(I.isHemisphereLight){let $=t.get(I);$.skyColor.copy(I.color).multiplyScalar(z),$.groundColor.copy(I.groundColor).multiplyScalar(z),n.hemi[p]=$,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=pt.LTC_FLOAT_1,n.rectAreaLTC2=pt.LTC_FLOAT_2):(n.rectAreaLTC1=pt.LTC_HALF_1,n.rectAreaLTC2=pt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let L=n.hash;(L.directionalLength!==f||L.pointLength!==g||L.spotLength!==_||L.rectAreaLength!==m||L.hemiLength!==p||L.numDirectionalShadows!==v||L.numPointShadows!==y||L.numSpotShadows!==x||L.numSpotMaps!==D||L.numLightProbes!==R)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=y,n.pointShadowMap.length=y,n.spotShadow.length=x,n.spotShadowMap.length=x,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=y,n.spotLightMatrix.length=x+D-T,n.spotLightMap.length=D,n.numSpotLightShadowsWithMaps=T,n.numLightProbes=R,L.directionalLength=f,L.pointLength=g,L.spotLength=_,L.rectAreaLength=m,L.hemiLength=p,L.numDirectionalShadows=v,L.numPointShadows=y,L.numSpotShadows=x,L.numSpotMaps=D,L.numLightProbes=R,n.version=v_++)}function l(c,h){let u=0,d=0,f=0,g=0,_=0,m=h.matrixWorldInverse;for(let p=0,v=c.length;p<v;p++){let y=c[p];if(y.isDirectionalLight){let x=n.directional[u];x.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(m),u++}else if(y.isSpotLight){let x=n.spot[f];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(m),x.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(m),f++}else if(y.isRectAreaLight){let x=n.rectArea[g];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(m),a.identity(),r.copy(y.matrixWorld),r.premultiply(m),a.extractRotation(r),x.halfWidth.set(y.width*.5,0,0),x.halfHeight.set(0,y.height*.5,0),x.halfWidth.applyMatrix4(a),x.halfHeight.applyMatrix4(a),g++}else if(y.isPointLight){let x=n.point[d];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(m),d++}else if(y.isHemisphereLight){let x=n.hemi[_];x.direction.setFromMatrixPosition(y.matrixWorld),x.direction.transformDirection(m),_++}}}return{setup:o,setupView:l,state:n}}function Td(i){let t=new b_(i),e=[],n=[];function s(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function a(h){n.push(h)}function o(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:o,setupLightsView:l,pushLight:r,pushShadow:a}}function M_(i){let t=new WeakMap;function e(s,r=0){let a=t.get(s),o;return a===void 0?(o=new Td(i),t.set(s,[o])):r>=a.length?(o=new Td(i),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}var nh=class extends si{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=pp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},ih=class extends si{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},S_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,w_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function E_(i,t,e){let n=new Cr,s=new st,r=new st,a=new Te,o=new nh({depthPacking:mp}),l=new ih,c={},h=e.maxTextureSize,u={[Mi]:$e,[$e]:Mi,[pn]:pn},d=new gn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new st},radius:{value:4}},vertexShader:S_,fragmentShader:w_}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let g=new Re;g.setAttribute("position",new Ne(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let _=new Me(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=zd;let p=this.type;this.render=function(T,R,L){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;let w=i.getRenderTarget(),M=i.getActiveCubeFace(),I=i.getActiveMipmapLevel(),G=i.state;G.setBlending(vi),G.buffers.color.setClear(1,1,1,1),G.buffers.depth.setTest(!0),G.setScissorTest(!1);let z=p!==jn&&this.type===jn,W=p===jn&&this.type!==jn;for(let K=0,$=T.length;K<$;K++){let at=T[K],X=at.shadow;if(X===void 0){console.warn("THREE.WebGLShadowMap:",at,"has no shadow.");continue}if(X.autoUpdate===!1&&X.needsUpdate===!1)continue;s.copy(X.mapSize);let ft=X.getFrameExtents();if(s.multiply(ft),r.copy(X.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/ft.x),s.x=r.x*ft.x,X.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/ft.y),s.y=r.y*ft.y,X.mapSize.y=r.y)),X.map===null||z===!0||W===!0){let At=this.type!==jn?{minFilter:cn,magFilter:cn}:{};X.map!==null&&X.map.dispose(),X.map=new ni(s.x,s.y,At),X.map.texture.name=at.name+".shadowMap",X.camera.updateProjectionMatrix()}i.setRenderTarget(X.map),i.clear();let yt=X.getViewportCount();for(let At=0;At<yt;At++){let Gt=X.getViewport(At);a.set(r.x*Gt.x,r.y*Gt.y,r.x*Gt.z,r.y*Gt.w),G.viewport(a),X.updateMatrices(at,At),n=X.getFrustum(),x(R,L,X.camera,at,this.type)}X.isPointLightShadow!==!0&&this.type===jn&&v(X,L),X.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(w,M,I)};function v(T,R){let L=t.update(_);d.defines.VSM_SAMPLES!==T.blurSamples&&(d.defines.VSM_SAMPLES=T.blurSamples,f.defines.VSM_SAMPLES=T.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new ni(s.x,s.y)),d.uniforms.shadow_pass.value=T.map.texture,d.uniforms.resolution.value=T.mapSize,d.uniforms.radius.value=T.radius,i.setRenderTarget(T.mapPass),i.clear(),i.renderBufferDirect(R,null,L,d,_,null),f.uniforms.shadow_pass.value=T.mapPass.texture,f.uniforms.resolution.value=T.mapSize,f.uniforms.radius.value=T.radius,i.setRenderTarget(T.map),i.clear(),i.renderBufferDirect(R,null,L,f,_,null)}function y(T,R,L,w){let M=null,I=L.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(I!==void 0)M=I;else if(M=L.isPointLight===!0?l:o,i.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let G=M.uuid,z=R.uuid,W=c[G];W===void 0&&(W={},c[G]=W);let K=W[z];K===void 0&&(K=M.clone(),W[z]=K,R.addEventListener("dispose",D)),M=K}if(M.visible=R.visible,M.wireframe=R.wireframe,w===jn?M.side=R.shadowSide!==null?R.shadowSide:R.side:M.side=R.shadowSide!==null?R.shadowSide:u[R.side],M.alphaMap=R.alphaMap,M.alphaTest=R.alphaTest,M.map=R.map,M.clipShadows=R.clipShadows,M.clippingPlanes=R.clippingPlanes,M.clipIntersection=R.clipIntersection,M.displacementMap=R.displacementMap,M.displacementScale=R.displacementScale,M.displacementBias=R.displacementBias,M.wireframeLinewidth=R.wireframeLinewidth,M.linewidth=R.linewidth,L.isPointLight===!0&&M.isMeshDistanceMaterial===!0){let G=i.properties.get(M);G.light=L}return M}function x(T,R,L,w,M){if(T.visible===!1)return;if(T.layers.test(R.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&M===jn)&&(!T.frustumCulled||n.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(L.matrixWorldInverse,T.matrixWorld);let z=t.update(T),W=T.material;if(Array.isArray(W)){let K=z.groups;for(let $=0,at=K.length;$<at;$++){let X=K[$],ft=W[X.materialIndex];if(ft&&ft.visible){let yt=y(T,ft,w,M);T.onBeforeShadow(i,T,R,L,z,yt,X),i.renderBufferDirect(L,null,z,yt,T,X),T.onAfterShadow(i,T,R,L,z,yt,X)}}}else if(W.visible){let K=y(T,W,w,M);T.onBeforeShadow(i,T,R,L,z,K,null),i.renderBufferDirect(L,null,z,K,T,null),T.onAfterShadow(i,T,R,L,z,K,null)}}let G=T.children;for(let z=0,W=G.length;z<W;z++)x(G[z],R,L,w,M)}function D(T){T.target.removeEventListener("dispose",D);for(let L in c){let w=c[L],M=T.target.uuid;M in w&&(w[M].dispose(),delete w[M])}}}var T_={[oc]:lc,[cc]:dc,[hc]:fc,[Os]:uc,[lc]:oc,[dc]:cc,[fc]:hc,[uc]:Os};function A_(i,t){function e(){let N=!1,gt=new Te,q=null,Q=new Te(0,0,0,0);return{setMask:function(vt){q!==vt&&!N&&(i.colorMask(vt,vt,vt,vt),q=vt)},setLocked:function(vt){N=vt},setClear:function(vt,xt,Xt,Ee,Ve){Ve===!0&&(vt*=Ee,xt*=Ee,Xt*=Ee),gt.set(vt,xt,Xt,Ee),Q.equals(gt)===!1&&(i.clearColor(vt,xt,Xt,Ee),Q.copy(gt))},reset:function(){N=!1,q=null,Q.set(-1,0,0,0)}}}function n(){let N=!1,gt=!1,q=null,Q=null,vt=null;return{setReversed:function(xt){if(gt!==xt){let Xt=t.get("EXT_clip_control");gt?Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.ZERO_TO_ONE_EXT):Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.NEGATIVE_ONE_TO_ONE_EXT);let Ee=vt;vt=null,this.setClear(Ee)}gt=xt},getReversed:function(){return gt},setTest:function(xt){xt?ut(i.DEPTH_TEST):Ut(i.DEPTH_TEST)},setMask:function(xt){q!==xt&&!N&&(i.depthMask(xt),q=xt)},setFunc:function(xt){if(gt&&(xt=T_[xt]),Q!==xt){switch(xt){case oc:i.depthFunc(i.NEVER);break;case lc:i.depthFunc(i.ALWAYS);break;case cc:i.depthFunc(i.LESS);break;case Os:i.depthFunc(i.LEQUAL);break;case hc:i.depthFunc(i.EQUAL);break;case uc:i.depthFunc(i.GEQUAL);break;case dc:i.depthFunc(i.GREATER);break;case fc:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Q=xt}},setLocked:function(xt){N=xt},setClear:function(xt){vt!==xt&&(gt&&(xt=1-xt),i.clearDepth(xt),vt=xt)},reset:function(){N=!1,q=null,Q=null,vt=null,gt=!1}}}function s(){let N=!1,gt=null,q=null,Q=null,vt=null,xt=null,Xt=null,Ee=null,Ve=null;return{setTest:function(ce){N||(ce?ut(i.STENCIL_TEST):Ut(i.STENCIL_TEST))},setMask:function(ce){gt!==ce&&!N&&(i.stencilMask(ce),gt=ce)},setFunc:function(ce,Mn,zn){(q!==ce||Q!==Mn||vt!==zn)&&(i.stencilFunc(ce,Mn,zn),q=ce,Q=Mn,vt=zn)},setOp:function(ce,Mn,zn){(xt!==ce||Xt!==Mn||Ee!==zn)&&(i.stencilOp(ce,Mn,zn),xt=ce,Xt=Mn,Ee=zn)},setLocked:function(ce){N=ce},setClear:function(ce){Ve!==ce&&(i.clearStencil(ce),Ve=ce)},reset:function(){N=!1,gt=null,q=null,Q=null,vt=null,xt=null,Xt=null,Ee=null,Ve=null}}}let r=new e,a=new n,o=new s,l=new WeakMap,c=new WeakMap,h={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,v=null,y=null,x=null,D=null,T=null,R=new Wt(0,0,0),L=0,w=!1,M=null,I=null,G=null,z=null,W=null,K=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),$=!1,at=0,X=i.getParameter(i.VERSION);X.indexOf("WebGL")!==-1?(at=parseFloat(/^WebGL (\d)/.exec(X)[1]),$=at>=1):X.indexOf("OpenGL ES")!==-1&&(at=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),$=at>=2);let ft=null,yt={},At=i.getParameter(i.SCISSOR_BOX),Gt=i.getParameter(i.VIEWPORT),ae=new Te().fromArray(At),J=new Te().fromArray(Gt);function lt(N,gt,q,Q){let vt=new Uint8Array(4),xt=i.createTexture();i.bindTexture(N,xt),i.texParameteri(N,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(N,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Xt=0;Xt<q;Xt++)N===i.TEXTURE_3D||N===i.TEXTURE_2D_ARRAY?i.texImage3D(gt,0,i.RGBA,1,1,Q,0,i.RGBA,i.UNSIGNED_BYTE,vt):i.texImage2D(gt+Xt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,vt);return xt}let Rt={};Rt[i.TEXTURE_2D]=lt(i.TEXTURE_2D,i.TEXTURE_2D,1),Rt[i.TEXTURE_CUBE_MAP]=lt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Rt[i.TEXTURE_2D_ARRAY]=lt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Rt[i.TEXTURE_3D]=lt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),ut(i.DEPTH_TEST),a.setFunc(Os),it(!1),St(Cu),ut(i.CULL_FACE),C(vi);function ut(N){h[N]!==!0&&(i.enable(N),h[N]=!0)}function Ut(N){h[N]!==!1&&(i.disable(N),h[N]=!1)}function zt(N,gt){return u[N]!==gt?(i.bindFramebuffer(N,gt),u[N]=gt,N===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=gt),N===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=gt),!0):!1}function Ft(N,gt){let q=f,Q=!1;if(N){q=d.get(gt),q===void 0&&(q=[],d.set(gt,q));let vt=N.textures;if(q.length!==vt.length||q[0]!==i.COLOR_ATTACHMENT0){for(let xt=0,Xt=vt.length;xt<Xt;xt++)q[xt]=i.COLOR_ATTACHMENT0+xt;q.length=vt.length,Q=!0}}else q[0]!==i.BACK&&(q[0]=i.BACK,Q=!0);Q&&i.drawBuffers(q)}function ee(N){return g!==N?(i.useProgram(N),g=N,!0):!1}let tt={[Gi]:i.FUNC_ADD,[Hf]:i.FUNC_SUBTRACT,[Vf]:i.FUNC_REVERSE_SUBTRACT};tt[Gf]=i.MIN,tt[Wf]=i.MAX;let ot={[$f]:i.ZERO,[Xf]:i.ONE,[qf]:i.SRC_COLOR,[rc]:i.SRC_ALPHA,[Qf]:i.SRC_ALPHA_SATURATE,[jf]:i.DST_COLOR,[Zf]:i.DST_ALPHA,[Yf]:i.ONE_MINUS_SRC_COLOR,[ac]:i.ONE_MINUS_SRC_ALPHA,[Kf]:i.ONE_MINUS_DST_COLOR,[Jf]:i.ONE_MINUS_DST_ALPHA,[tp]:i.CONSTANT_COLOR,[ep]:i.ONE_MINUS_CONSTANT_COLOR,[np]:i.CONSTANT_ALPHA,[ip]:i.ONE_MINUS_CONSTANT_ALPHA};function C(N,gt,q,Q,vt,xt,Xt,Ee,Ve,ce){if(N===vi){_===!0&&(Ut(i.BLEND),_=!1);return}if(_===!1&&(ut(i.BLEND),_=!0),N!==zf){if(N!==m||ce!==w){if((p!==Gi||x!==Gi)&&(i.blendEquation(i.FUNC_ADD),p=Gi,x=Gi),ce)switch(N){case Ls:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ns:i.blendFunc(i.ONE,i.ONE);break;case Pu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Iu:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case Ls:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Ns:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Pu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Iu:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}v=null,y=null,D=null,T=null,R.set(0,0,0),L=0,m=N,w=ce}return}vt=vt||gt,xt=xt||q,Xt=Xt||Q,(gt!==p||vt!==x)&&(i.blendEquationSeparate(tt[gt],tt[vt]),p=gt,x=vt),(q!==v||Q!==y||xt!==D||Xt!==T)&&(i.blendFuncSeparate(ot[q],ot[Q],ot[xt],ot[Xt]),v=q,y=Q,D=xt,T=Xt),(Ee.equals(R)===!1||Ve!==L)&&(i.blendColor(Ee.r,Ee.g,Ee.b,Ve),R.copy(Ee),L=Ve),m=N,w=!1}function Dt(N,gt){N.side===pn?Ut(i.CULL_FACE):ut(i.CULL_FACE);let q=N.side===$e;gt&&(q=!q),it(q),N.blending===Ls&&N.transparent===!1?C(vi):C(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),a.setFunc(N.depthFunc),a.setTest(N.depthTest),a.setMask(N.depthWrite),r.setMask(N.colorWrite);let Q=N.stencilWrite;o.setTest(Q),Q&&(o.setMask(N.stencilWriteMask),o.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),o.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),Nt(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?ut(i.SAMPLE_ALPHA_TO_COVERAGE):Ut(i.SAMPLE_ALPHA_TO_COVERAGE)}function it(N){M!==N&&(N?i.frontFace(i.CW):i.frontFace(i.CCW),M=N)}function St(N){N!==Ff?(ut(i.CULL_FACE),N!==I&&(N===Cu?i.cullFace(i.BACK):N===Bf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ut(i.CULL_FACE),I=N}function dt(N){N!==G&&($&&i.lineWidth(N),G=N)}function Nt(N,gt,q){N?(ut(i.POLYGON_OFFSET_FILL),(z!==gt||W!==q)&&(i.polygonOffset(gt,q),z=gt,W=q)):Ut(i.POLYGON_OFFSET_FILL)}function bt(N){N?ut(i.SCISSOR_TEST):Ut(i.SCISSOR_TEST)}function E(N){N===void 0&&(N=i.TEXTURE0+K-1),ft!==N&&(i.activeTexture(N),ft=N)}function b(N,gt,q){q===void 0&&(ft===null?q=i.TEXTURE0+K-1:q=ft);let Q=yt[q];Q===void 0&&(Q={type:void 0,texture:void 0},yt[q]=Q),(Q.type!==N||Q.texture!==gt)&&(ft!==q&&(i.activeTexture(q),ft=q),i.bindTexture(N,gt||Rt[N]),Q.type=N,Q.texture=gt)}function B(){let N=yt[ft];N!==void 0&&N.type!==void 0&&(i.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function Y(){try{i.compressedTexImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function et(){try{i.compressedTexImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Z(){try{i.texSubImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ct(){try{i.texSubImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function mt(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Mt(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Kt(){try{i.texStorage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function rt(){try{i.texStorage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Et(){try{i.texImage2D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ot(){try{i.texImage3D.apply(i,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Bt(N){ae.equals(N)===!1&&(i.scissor(N.x,N.y,N.z,N.w),ae.copy(N))}function Tt(N){J.equals(N)===!1&&(i.viewport(N.x,N.y,N.z,N.w),J.copy(N))}function te(N,gt){let q=c.get(gt);q===void 0&&(q=new WeakMap,c.set(gt,q));let Q=q.get(N);Q===void 0&&(Q=i.getUniformBlockIndex(gt,N.name),q.set(N,Q))}function Jt(N,gt){let Q=c.get(gt).get(N);l.get(gt)!==Q&&(i.uniformBlockBinding(gt,Q,N.__bindingPointIndex),l.set(gt,Q))}function ge(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},ft=null,yt={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,v=null,y=null,x=null,D=null,T=null,R=new Wt(0,0,0),L=0,w=!1,M=null,I=null,G=null,z=null,W=null,ae.set(0,0,i.canvas.width,i.canvas.height),J.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:ut,disable:Ut,bindFramebuffer:zt,drawBuffers:Ft,useProgram:ee,setBlending:C,setMaterial:Dt,setFlipSided:it,setCullFace:St,setLineWidth:dt,setPolygonOffset:Nt,setScissorTest:bt,activeTexture:E,bindTexture:b,unbindTexture:B,compressedTexImage2D:Y,compressedTexImage3D:et,texImage2D:Et,texImage3D:Ot,updateUBOMapping:te,uniformBlockBinding:Jt,texStorage2D:Kt,texStorage3D:rt,texSubImage2D:Z,texSubImage3D:Ct,compressedTexSubImage2D:mt,compressedTexSubImage3D:Mt,scissor:Bt,viewport:Tt,reset:ge}}function Ad(i,t,e,n){let s=R_(n);switch(e){case $d:return i*t;case qd:return i*t;case Yd:return i*t*2;case Fh:return i*t/s.components*s.byteLength;case Bh:return i*t/s.components*s.byteLength;case Zd:return i*t*2/s.components*s.byteLength;case zh:return i*t*2/s.components*s.byteLength;case Xd:return i*t*3/s.components*s.byteLength;case In:return i*t*4/s.components*s.byteLength;case Hh:return i*t*4/s.components*s.byteLength;case Xa:case qa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Ya:case Za:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case _c:case yc:return Math.max(i,16)*Math.max(t,8)/4;case xc:case vc:return Math.max(i,8)*Math.max(t,8)/2;case bc:case Mc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Sc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case wc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Ec:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case Tc:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case Ac:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case Rc:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case Cc:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case Pc:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case Ic:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case Lc:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case Dc:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case kc:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case Uc:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case Nc:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case Oc:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Ja:case Fc:case Bc:return Math.ceil(i/4)*Math.ceil(t/4)*16;case Jd:case zc:return Math.ceil(i/4)*Math.ceil(t/4)*8;case Hc:case Vc:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function R_(i){switch(i){case ei:case Vd:return{byteLength:1,components:1};case Ar:case Gd:case Vr:return{byteLength:2,components:1};case Nh:case Oh:return{byteLength:2,components:4};case qi:case Uh:case On:return{byteLength:4,components:1};case Wd:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function C_(i,t,e,n,s,r,a){let o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new st,h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(E,b){return f?new OffscreenCanvas(E,b):Qa("canvas")}function _(E,b,B){let Y=1,et=bt(E);if((et.width>B||et.height>B)&&(Y=B/Math.max(et.width,et.height)),Y<1)if(typeof HTMLImageElement<"u"&&E instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&E instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&E instanceof ImageBitmap||typeof VideoFrame<"u"&&E instanceof VideoFrame){let Z=Math.floor(Y*et.width),Ct=Math.floor(Y*et.height);u===void 0&&(u=g(Z,Ct));let mt=b?g(Z,Ct):u;return mt.width=Z,mt.height=Ct,mt.getContext("2d").drawImage(E,0,0,Z,Ct),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+et.width+"x"+et.height+") to ("+Z+"x"+Ct+")."),mt}else return"data"in E&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+et.width+"x"+et.height+")."),E;return E}function m(E){return E.generateMipmaps}function p(E){i.generateMipmap(E)}function v(E){return E.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:E.isWebGL3DRenderTarget?i.TEXTURE_3D:E.isWebGLArrayRenderTarget||E.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function y(E,b,B,Y,et=!1){if(E!==null){if(i[E]!==void 0)return i[E];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+E+"'")}let Z=b;if(b===i.RED&&(B===i.FLOAT&&(Z=i.R32F),B===i.HALF_FLOAT&&(Z=i.R16F),B===i.UNSIGNED_BYTE&&(Z=i.R8)),b===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(Z=i.R8UI),B===i.UNSIGNED_SHORT&&(Z=i.R16UI),B===i.UNSIGNED_INT&&(Z=i.R32UI),B===i.BYTE&&(Z=i.R8I),B===i.SHORT&&(Z=i.R16I),B===i.INT&&(Z=i.R32I)),b===i.RG&&(B===i.FLOAT&&(Z=i.RG32F),B===i.HALF_FLOAT&&(Z=i.RG16F),B===i.UNSIGNED_BYTE&&(Z=i.RG8)),b===i.RG_INTEGER&&(B===i.UNSIGNED_BYTE&&(Z=i.RG8UI),B===i.UNSIGNED_SHORT&&(Z=i.RG16UI),B===i.UNSIGNED_INT&&(Z=i.RG32UI),B===i.BYTE&&(Z=i.RG8I),B===i.SHORT&&(Z=i.RG16I),B===i.INT&&(Z=i.RG32I)),b===i.RGB_INTEGER&&(B===i.UNSIGNED_BYTE&&(Z=i.RGB8UI),B===i.UNSIGNED_SHORT&&(Z=i.RGB16UI),B===i.UNSIGNED_INT&&(Z=i.RGB32UI),B===i.BYTE&&(Z=i.RGB8I),B===i.SHORT&&(Z=i.RGB16I),B===i.INT&&(Z=i.RGB32I)),b===i.RGBA_INTEGER&&(B===i.UNSIGNED_BYTE&&(Z=i.RGBA8UI),B===i.UNSIGNED_SHORT&&(Z=i.RGBA16UI),B===i.UNSIGNED_INT&&(Z=i.RGBA32UI),B===i.BYTE&&(Z=i.RGBA8I),B===i.SHORT&&(Z=i.RGBA16I),B===i.INT&&(Z=i.RGBA32I)),b===i.RGB&&B===i.UNSIGNED_INT_5_9_9_9_REV&&(Z=i.RGB9_E5),b===i.RGBA){let Ct=et?Lo:ne.getTransfer(Y);B===i.FLOAT&&(Z=i.RGBA32F),B===i.HALF_FLOAT&&(Z=i.RGBA16F),B===i.UNSIGNED_BYTE&&(Z=Ct===pe?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT_4_4_4_4&&(Z=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(Z=i.RGB5_A1)}return(Z===i.R16F||Z===i.R32F||Z===i.RG16F||Z===i.RG32F||Z===i.RGBA16F||Z===i.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function x(E,b){let B;return E?b===null||b===qi||b===zs?B=i.DEPTH24_STENCIL8:b===On?B=i.DEPTH32F_STENCIL8:b===Ar&&(B=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):b===null||b===qi||b===zs?B=i.DEPTH_COMPONENT24:b===On?B=i.DEPTH_COMPONENT32F:b===Ar&&(B=i.DEPTH_COMPONENT16),B}function D(E,b){return m(E)===!0||E.isFramebufferTexture&&E.minFilter!==cn&&E.minFilter!==Nn?Math.log2(Math.max(b.width,b.height))+1:E.mipmaps!==void 0&&E.mipmaps.length>0?E.mipmaps.length:E.isCompressedTexture&&Array.isArray(E.image)?b.mipmaps.length:1}function T(E){let b=E.target;b.removeEventListener("dispose",T),L(b),b.isVideoTexture&&h.delete(b)}function R(E){let b=E.target;b.removeEventListener("dispose",R),M(b)}function L(E){let b=n.get(E);if(b.__webglInit===void 0)return;let B=E.source,Y=d.get(B);if(Y){let et=Y[b.__cacheKey];et.usedTimes--,et.usedTimes===0&&w(E),Object.keys(Y).length===0&&d.delete(B)}n.remove(E)}function w(E){let b=n.get(E);i.deleteTexture(b.__webglTexture);let B=E.source,Y=d.get(B);delete Y[b.__cacheKey],a.memory.textures--}function M(E){let b=n.get(E);if(E.depthTexture&&(E.depthTexture.dispose(),n.remove(E.depthTexture)),E.isWebGLCubeRenderTarget)for(let Y=0;Y<6;Y++){if(Array.isArray(b.__webglFramebuffer[Y]))for(let et=0;et<b.__webglFramebuffer[Y].length;et++)i.deleteFramebuffer(b.__webglFramebuffer[Y][et]);else i.deleteFramebuffer(b.__webglFramebuffer[Y]);b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer[Y])}else{if(Array.isArray(b.__webglFramebuffer))for(let Y=0;Y<b.__webglFramebuffer.length;Y++)i.deleteFramebuffer(b.__webglFramebuffer[Y]);else i.deleteFramebuffer(b.__webglFramebuffer);if(b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer),b.__webglMultisampledFramebuffer&&i.deleteFramebuffer(b.__webglMultisampledFramebuffer),b.__webglColorRenderbuffer)for(let Y=0;Y<b.__webglColorRenderbuffer.length;Y++)b.__webglColorRenderbuffer[Y]&&i.deleteRenderbuffer(b.__webglColorRenderbuffer[Y]);b.__webglDepthRenderbuffer&&i.deleteRenderbuffer(b.__webglDepthRenderbuffer)}let B=E.textures;for(let Y=0,et=B.length;Y<et;Y++){let Z=n.get(B[Y]);Z.__webglTexture&&(i.deleteTexture(Z.__webglTexture),a.memory.textures--),n.remove(B[Y])}n.remove(E)}let I=0;function G(){I=0}function z(){let E=I;return E>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+E+" texture units while this GPU supports only "+s.maxTextures),I+=1,E}function W(E){let b=[];return b.push(E.wrapS),b.push(E.wrapT),b.push(E.wrapR||0),b.push(E.magFilter),b.push(E.minFilter),b.push(E.anisotropy),b.push(E.internalFormat),b.push(E.format),b.push(E.type),b.push(E.generateMipmaps),b.push(E.premultiplyAlpha),b.push(E.flipY),b.push(E.unpackAlignment),b.push(E.colorSpace),b.join()}function K(E,b){let B=n.get(E);if(E.isVideoTexture&&dt(E),E.isRenderTargetTexture===!1&&E.version>0&&B.__version!==E.version){let Y=E.image;if(Y===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Y.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{J(B,E,b);return}}e.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+b)}function $(E,b){let B=n.get(E);if(E.version>0&&B.__version!==E.version){J(B,E,b);return}e.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+b)}function at(E,b){let B=n.get(E);if(E.version>0&&B.__version!==E.version){J(B,E,b);return}e.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+b)}function X(E,b){let B=n.get(E);if(E.version>0&&B.__version!==E.version){lt(B,E,b);return}e.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+b)}let ft={[Tr]:i.REPEAT,[$i]:i.CLAMP_TO_EDGE,[gc]:i.MIRRORED_REPEAT},yt={[cn]:i.NEAREST,[fp]:i.NEAREST_MIPMAP_NEAREST,[ma]:i.NEAREST_MIPMAP_LINEAR,[Nn]:i.LINEAR,[Tl]:i.LINEAR_MIPMAP_NEAREST,[Xi]:i.LINEAR_MIPMAP_LINEAR},At={[xp]:i.NEVER,[Sp]:i.ALWAYS,[_p]:i.LESS,[Kd]:i.LEQUAL,[vp]:i.EQUAL,[Mp]:i.GEQUAL,[yp]:i.GREATER,[bp]:i.NOTEQUAL};function Gt(E,b){if(b.type===On&&t.has("OES_texture_float_linear")===!1&&(b.magFilter===Nn||b.magFilter===Tl||b.magFilter===ma||b.magFilter===Xi||b.minFilter===Nn||b.minFilter===Tl||b.minFilter===ma||b.minFilter===Xi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(E,i.TEXTURE_WRAP_S,ft[b.wrapS]),i.texParameteri(E,i.TEXTURE_WRAP_T,ft[b.wrapT]),(E===i.TEXTURE_3D||E===i.TEXTURE_2D_ARRAY)&&i.texParameteri(E,i.TEXTURE_WRAP_R,ft[b.wrapR]),i.texParameteri(E,i.TEXTURE_MAG_FILTER,yt[b.magFilter]),i.texParameteri(E,i.TEXTURE_MIN_FILTER,yt[b.minFilter]),b.compareFunction&&(i.texParameteri(E,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(E,i.TEXTURE_COMPARE_FUNC,At[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(b.magFilter===cn||b.minFilter!==ma&&b.minFilter!==Xi||b.type===On&&t.has("OES_texture_float_linear")===!1)return;if(b.anisotropy>1||n.get(b).__currentAnisotropy){let B=t.get("EXT_texture_filter_anisotropic");i.texParameterf(E,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,s.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy}}}function ae(E,b){let B=!1;E.__webglInit===void 0&&(E.__webglInit=!0,b.addEventListener("dispose",T));let Y=b.source,et=d.get(Y);et===void 0&&(et={},d.set(Y,et));let Z=W(b);if(Z!==E.__cacheKey){et[Z]===void 0&&(et[Z]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,B=!0),et[Z].usedTimes++;let Ct=et[E.__cacheKey];Ct!==void 0&&(et[E.__cacheKey].usedTimes--,Ct.usedTimes===0&&w(b)),E.__cacheKey=Z,E.__webglTexture=et[Z].texture}return B}function J(E,b,B){let Y=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(Y=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(Y=i.TEXTURE_3D);let et=ae(E,b),Z=b.source;e.bindTexture(Y,E.__webglTexture,i.TEXTURE0+B);let Ct=n.get(Z);if(Z.version!==Ct.__version||et===!0){e.activeTexture(i.TEXTURE0+B);let mt=ne.getPrimaries(ne.workingColorSpace),Mt=b.colorSpace===xi?null:ne.getPrimaries(b.colorSpace),Kt=b.colorSpace===xi||mt===Mt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Kt);let rt=_(b.image,!1,s.maxTextureSize);rt=Nt(b,rt);let Et=r.convert(b.format,b.colorSpace),Ot=r.convert(b.type),Bt=y(b.internalFormat,Et,Ot,b.colorSpace,b.isVideoTexture);Gt(Y,b);let Tt,te=b.mipmaps,Jt=b.isVideoTexture!==!0,ge=Ct.__version===void 0||et===!0,N=Z.dataReady,gt=D(b,rt);if(b.isDepthTexture)Bt=x(b.format===Hs,b.type),ge&&(Jt?e.texStorage2D(i.TEXTURE_2D,1,Bt,rt.width,rt.height):e.texImage2D(i.TEXTURE_2D,0,Bt,rt.width,rt.height,0,Et,Ot,null));else if(b.isDataTexture)if(te.length>0){Jt&&ge&&e.texStorage2D(i.TEXTURE_2D,gt,Bt,te[0].width,te[0].height);for(let q=0,Q=te.length;q<Q;q++)Tt=te[q],Jt?N&&e.texSubImage2D(i.TEXTURE_2D,q,0,0,Tt.width,Tt.height,Et,Ot,Tt.data):e.texImage2D(i.TEXTURE_2D,q,Bt,Tt.width,Tt.height,0,Et,Ot,Tt.data);b.generateMipmaps=!1}else Jt?(ge&&e.texStorage2D(i.TEXTURE_2D,gt,Bt,rt.width,rt.height),N&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,rt.width,rt.height,Et,Ot,rt.data)):e.texImage2D(i.TEXTURE_2D,0,Bt,rt.width,rt.height,0,Et,Ot,rt.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){Jt&&ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,gt,Bt,te[0].width,te[0].height,rt.depth);for(let q=0,Q=te.length;q<Q;q++)if(Tt=te[q],b.format!==In)if(Et!==null)if(Jt){if(N)if(b.layerUpdates.size>0){let vt=Ad(Tt.width,Tt.height,b.format,b.type);for(let xt of b.layerUpdates){let Xt=Tt.data.subarray(xt*vt/Tt.data.BYTES_PER_ELEMENT,(xt+1)*vt/Tt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,q,0,0,xt,Tt.width,Tt.height,1,Et,Xt)}b.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,q,0,0,0,Tt.width,Tt.height,rt.depth,Et,Tt.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,q,Bt,Tt.width,Tt.height,rt.depth,0,Tt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Jt?N&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,q,0,0,0,Tt.width,Tt.height,rt.depth,Et,Ot,Tt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,q,Bt,Tt.width,Tt.height,rt.depth,0,Et,Ot,Tt.data)}else{Jt&&ge&&e.texStorage2D(i.TEXTURE_2D,gt,Bt,te[0].width,te[0].height);for(let q=0,Q=te.length;q<Q;q++)Tt=te[q],b.format!==In?Et!==null?Jt?N&&e.compressedTexSubImage2D(i.TEXTURE_2D,q,0,0,Tt.width,Tt.height,Et,Tt.data):e.compressedTexImage2D(i.TEXTURE_2D,q,Bt,Tt.width,Tt.height,0,Tt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Jt?N&&e.texSubImage2D(i.TEXTURE_2D,q,0,0,Tt.width,Tt.height,Et,Ot,Tt.data):e.texImage2D(i.TEXTURE_2D,q,Bt,Tt.width,Tt.height,0,Et,Ot,Tt.data)}else if(b.isDataArrayTexture)if(Jt){if(ge&&e.texStorage3D(i.TEXTURE_2D_ARRAY,gt,Bt,rt.width,rt.height,rt.depth),N)if(b.layerUpdates.size>0){let q=Ad(rt.width,rt.height,b.format,b.type);for(let Q of b.layerUpdates){let vt=rt.data.subarray(Q*q/rt.data.BYTES_PER_ELEMENT,(Q+1)*q/rt.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Q,rt.width,rt.height,1,Et,Ot,vt)}b.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,rt.width,rt.height,rt.depth,Et,Ot,rt.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,Bt,rt.width,rt.height,rt.depth,0,Et,Ot,rt.data);else if(b.isData3DTexture)Jt?(ge&&e.texStorage3D(i.TEXTURE_3D,gt,Bt,rt.width,rt.height,rt.depth),N&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,rt.width,rt.height,rt.depth,Et,Ot,rt.data)):e.texImage3D(i.TEXTURE_3D,0,Bt,rt.width,rt.height,rt.depth,0,Et,Ot,rt.data);else if(b.isFramebufferTexture){if(ge)if(Jt)e.texStorage2D(i.TEXTURE_2D,gt,Bt,rt.width,rt.height);else{let q=rt.width,Q=rt.height;for(let vt=0;vt<gt;vt++)e.texImage2D(i.TEXTURE_2D,vt,Bt,q,Q,0,Et,Ot,null),q>>=1,Q>>=1}}else if(te.length>0){if(Jt&&ge){let q=bt(te[0]);e.texStorage2D(i.TEXTURE_2D,gt,Bt,q.width,q.height)}for(let q=0,Q=te.length;q<Q;q++)Tt=te[q],Jt?N&&e.texSubImage2D(i.TEXTURE_2D,q,0,0,Et,Ot,Tt):e.texImage2D(i.TEXTURE_2D,q,Bt,Et,Ot,Tt);b.generateMipmaps=!1}else if(Jt){if(ge){let q=bt(rt);e.texStorage2D(i.TEXTURE_2D,gt,Bt,q.width,q.height)}N&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,Et,Ot,rt)}else e.texImage2D(i.TEXTURE_2D,0,Bt,Et,Ot,rt);m(b)&&p(Y),Ct.__version=Z.version,b.onUpdate&&b.onUpdate(b)}E.__version=b.version}function lt(E,b,B){if(b.image.length!==6)return;let Y=ae(E,b),et=b.source;e.bindTexture(i.TEXTURE_CUBE_MAP,E.__webglTexture,i.TEXTURE0+B);let Z=n.get(et);if(et.version!==Z.__version||Y===!0){e.activeTexture(i.TEXTURE0+B);let Ct=ne.getPrimaries(ne.workingColorSpace),mt=b.colorSpace===xi?null:ne.getPrimaries(b.colorSpace),Mt=b.colorSpace===xi||Ct===mt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt);let Kt=b.isCompressedTexture||b.image[0].isCompressedTexture,rt=b.image[0]&&b.image[0].isDataTexture,Et=[];for(let Q=0;Q<6;Q++)!Kt&&!rt?Et[Q]=_(b.image[Q],!0,s.maxCubemapSize):Et[Q]=rt?b.image[Q].image:b.image[Q],Et[Q]=Nt(b,Et[Q]);let Ot=Et[0],Bt=r.convert(b.format,b.colorSpace),Tt=r.convert(b.type),te=y(b.internalFormat,Bt,Tt,b.colorSpace),Jt=b.isVideoTexture!==!0,ge=Z.__version===void 0||Y===!0,N=et.dataReady,gt=D(b,Ot);Gt(i.TEXTURE_CUBE_MAP,b);let q;if(Kt){Jt&&ge&&e.texStorage2D(i.TEXTURE_CUBE_MAP,gt,te,Ot.width,Ot.height);for(let Q=0;Q<6;Q++){q=Et[Q].mipmaps;for(let vt=0;vt<q.length;vt++){let xt=q[vt];b.format!==In?Bt!==null?Jt?N&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,0,0,xt.width,xt.height,Bt,xt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,te,xt.width,xt.height,0,xt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Jt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,0,0,xt.width,xt.height,Bt,Tt,xt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,te,xt.width,xt.height,0,Bt,Tt,xt.data)}}}else{if(q=b.mipmaps,Jt&&ge){q.length>0&&gt++;let Q=bt(Et[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,gt,te,Q.width,Q.height)}for(let Q=0;Q<6;Q++)if(rt){Jt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,Et[Q].width,Et[Q].height,Bt,Tt,Et[Q].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,te,Et[Q].width,Et[Q].height,0,Bt,Tt,Et[Q].data);for(let vt=0;vt<q.length;vt++){let Xt=q[vt].image[Q].image;Jt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,0,0,Xt.width,Xt.height,Bt,Tt,Xt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,te,Xt.width,Xt.height,0,Bt,Tt,Xt.data)}}else{Jt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,Bt,Tt,Et[Q]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,te,Bt,Tt,Et[Q]);for(let vt=0;vt<q.length;vt++){let xt=q[vt];Jt?N&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,0,0,Bt,Tt,xt.image[Q]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,te,Bt,Tt,xt.image[Q])}}}m(b)&&p(i.TEXTURE_CUBE_MAP),Z.__version=et.version,b.onUpdate&&b.onUpdate(b)}E.__version=b.version}function Rt(E,b,B,Y,et,Z){let Ct=r.convert(B.format,B.colorSpace),mt=r.convert(B.type),Mt=y(B.internalFormat,Ct,mt,B.colorSpace),Kt=n.get(b),rt=n.get(B);if(rt.__renderTarget=b,!Kt.__hasExternalTextures){let Et=Math.max(1,b.width>>Z),Ot=Math.max(1,b.height>>Z);et===i.TEXTURE_3D||et===i.TEXTURE_2D_ARRAY?e.texImage3D(et,Z,Mt,Et,Ot,b.depth,0,Ct,mt,null):e.texImage2D(et,Z,Mt,Et,Ot,0,Ct,mt,null)}e.bindFramebuffer(i.FRAMEBUFFER,E),St(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Y,et,rt.__webglTexture,0,it(b)):(et===i.TEXTURE_2D||et>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&et<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Y,et,rt.__webglTexture,Z),e.bindFramebuffer(i.FRAMEBUFFER,null)}function ut(E,b,B){if(i.bindRenderbuffer(i.RENDERBUFFER,E),b.depthBuffer){let Y=b.depthTexture,et=Y&&Y.isDepthTexture?Y.type:null,Z=x(b.stencilBuffer,et),Ct=b.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,mt=it(b);St(b)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,mt,Z,b.width,b.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,mt,Z,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,Z,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ct,i.RENDERBUFFER,E)}else{let Y=b.textures;for(let et=0;et<Y.length;et++){let Z=Y[et],Ct=r.convert(Z.format,Z.colorSpace),mt=r.convert(Z.type),Mt=y(Z.internalFormat,Ct,mt,Z.colorSpace),Kt=it(b);B&&St(b)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Kt,Mt,b.width,b.height):St(b)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Kt,Mt,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,Mt,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ut(E,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,E),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let Y=n.get(b.depthTexture);Y.__renderTarget=b,(!Y.__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),K(b.depthTexture,0);let et=Y.__webglTexture,Z=it(b);if(b.depthTexture.format===Ds)St(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,et,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,et,0);else if(b.depthTexture.format===Hs)St(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,et,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,et,0);else throw new Error("Unknown depthTexture format")}function zt(E){let b=n.get(E),B=E.isWebGLCubeRenderTarget===!0;if(b.__boundDepthTexture!==E.depthTexture){let Y=E.depthTexture;if(b.__depthDisposeCallback&&b.__depthDisposeCallback(),Y){let et=()=>{delete b.__boundDepthTexture,delete b.__depthDisposeCallback,Y.removeEventListener("dispose",et)};Y.addEventListener("dispose",et),b.__depthDisposeCallback=et}b.__boundDepthTexture=Y}if(E.depthTexture&&!b.__autoAllocateDepthBuffer){if(B)throw new Error("target.depthTexture not supported in Cube render targets");Ut(b.__webglFramebuffer,E)}else if(B){b.__webglDepthbuffer=[];for(let Y=0;Y<6;Y++)if(e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[Y]),b.__webglDepthbuffer[Y]===void 0)b.__webglDepthbuffer[Y]=i.createRenderbuffer(),ut(b.__webglDepthbuffer[Y],E,!1);else{let et=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Z=b.__webglDepthbuffer[Y];i.bindRenderbuffer(i.RENDERBUFFER,Z),i.framebufferRenderbuffer(i.FRAMEBUFFER,et,i.RENDERBUFFER,Z)}}else if(e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer===void 0)b.__webglDepthbuffer=i.createRenderbuffer(),ut(b.__webglDepthbuffer,E,!1);else{let Y=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,et=b.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,et),i.framebufferRenderbuffer(i.FRAMEBUFFER,Y,i.RENDERBUFFER,et)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Ft(E,b,B){let Y=n.get(E);b!==void 0&&Rt(Y.__webglFramebuffer,E,E.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&zt(E)}function ee(E){let b=E.texture,B=n.get(E),Y=n.get(b);E.addEventListener("dispose",R);let et=E.textures,Z=E.isWebGLCubeRenderTarget===!0,Ct=et.length>1;if(Ct||(Y.__webglTexture===void 0&&(Y.__webglTexture=i.createTexture()),Y.__version=b.version,a.memory.textures++),Z){B.__webglFramebuffer=[];for(let mt=0;mt<6;mt++)if(b.mipmaps&&b.mipmaps.length>0){B.__webglFramebuffer[mt]=[];for(let Mt=0;Mt<b.mipmaps.length;Mt++)B.__webglFramebuffer[mt][Mt]=i.createFramebuffer()}else B.__webglFramebuffer[mt]=i.createFramebuffer()}else{if(b.mipmaps&&b.mipmaps.length>0){B.__webglFramebuffer=[];for(let mt=0;mt<b.mipmaps.length;mt++)B.__webglFramebuffer[mt]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(Ct)for(let mt=0,Mt=et.length;mt<Mt;mt++){let Kt=n.get(et[mt]);Kt.__webglTexture===void 0&&(Kt.__webglTexture=i.createTexture(),a.memory.textures++)}if(E.samples>0&&St(E)===!1){B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let mt=0;mt<et.length;mt++){let Mt=et[mt];B.__webglColorRenderbuffer[mt]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[mt]);let Kt=r.convert(Mt.format,Mt.colorSpace),rt=r.convert(Mt.type),Et=y(Mt.internalFormat,Kt,rt,Mt.colorSpace,E.isXRRenderTarget===!0),Ot=it(E);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ot,Et,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+mt,i.RENDERBUFFER,B.__webglColorRenderbuffer[mt])}i.bindRenderbuffer(i.RENDERBUFFER,null),E.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),ut(B.__webglDepthRenderbuffer,E,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Z){e.bindTexture(i.TEXTURE_CUBE_MAP,Y.__webglTexture),Gt(i.TEXTURE_CUBE_MAP,b);for(let mt=0;mt<6;mt++)if(b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)Rt(B.__webglFramebuffer[mt][Mt],E,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Mt);else Rt(B.__webglFramebuffer[mt],E,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0);m(b)&&p(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Ct){for(let mt=0,Mt=et.length;mt<Mt;mt++){let Kt=et[mt],rt=n.get(Kt);e.bindTexture(i.TEXTURE_2D,rt.__webglTexture),Gt(i.TEXTURE_2D,Kt),Rt(B.__webglFramebuffer,E,Kt,i.COLOR_ATTACHMENT0+mt,i.TEXTURE_2D,0),m(Kt)&&p(i.TEXTURE_2D)}e.unbindTexture()}else{let mt=i.TEXTURE_2D;if((E.isWebGL3DRenderTarget||E.isWebGLArrayRenderTarget)&&(mt=E.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(mt,Y.__webglTexture),Gt(mt,b),b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)Rt(B.__webglFramebuffer[Mt],E,b,i.COLOR_ATTACHMENT0,mt,Mt);else Rt(B.__webglFramebuffer,E,b,i.COLOR_ATTACHMENT0,mt,0);m(b)&&p(mt),e.unbindTexture()}E.depthBuffer&&zt(E)}function tt(E){let b=E.textures;for(let B=0,Y=b.length;B<Y;B++){let et=b[B];if(m(et)){let Z=v(E),Ct=n.get(et).__webglTexture;e.bindTexture(Z,Ct),p(Z),e.unbindTexture()}}}let ot=[],C=[];function Dt(E){if(E.samples>0){if(St(E)===!1){let b=E.textures,B=E.width,Y=E.height,et=i.COLOR_BUFFER_BIT,Z=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ct=n.get(E),mt=b.length>1;if(mt)for(let Mt=0;Mt<b.length;Mt++)e.bindFramebuffer(i.FRAMEBUFFER,Ct.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,Ct.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,Ct.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ct.__webglFramebuffer);for(let Mt=0;Mt<b.length;Mt++){if(E.resolveDepthBuffer&&(E.depthBuffer&&(et|=i.DEPTH_BUFFER_BIT),E.stencilBuffer&&E.resolveStencilBuffer&&(et|=i.STENCIL_BUFFER_BIT)),mt){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ct.__webglColorRenderbuffer[Mt]);let Kt=n.get(b[Mt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,Kt,0)}i.blitFramebuffer(0,0,B,Y,0,0,B,Y,et,i.NEAREST),l===!0&&(ot.length=0,C.length=0,ot.push(i.COLOR_ATTACHMENT0+Mt),E.depthBuffer&&E.resolveDepthBuffer===!1&&(ot.push(Z),C.push(Z),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,C)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,ot))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),mt)for(let Mt=0;Mt<b.length;Mt++){e.bindFramebuffer(i.FRAMEBUFFER,Ct.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.RENDERBUFFER,Ct.__webglColorRenderbuffer[Mt]);let Kt=n.get(b[Mt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,Ct.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.TEXTURE_2D,Kt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ct.__webglMultisampledFramebuffer)}else if(E.depthBuffer&&E.resolveDepthBuffer===!1&&l){let b=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[b])}}}function it(E){return Math.min(s.maxSamples,E.samples)}function St(E){let b=n.get(E);return E.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function dt(E){let b=a.render.frame;h.get(E)!==b&&(h.set(E,b),E.update())}function Nt(E,b){let B=E.colorSpace,Y=E.format,et=E.type;return E.isCompressedTexture===!0||E.isVideoTexture===!0||B!==qs&&B!==xi&&(ne.getTransfer(B)===pe?(Y!==In||et!==ei)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",B)),b}function bt(E){return typeof HTMLImageElement<"u"&&E instanceof HTMLImageElement?(c.width=E.naturalWidth||E.width,c.height=E.naturalHeight||E.height):typeof VideoFrame<"u"&&E instanceof VideoFrame?(c.width=E.displayWidth,c.height=E.displayHeight):(c.width=E.width,c.height=E.height),c}this.allocateTextureUnit=z,this.resetTextureUnits=G,this.setTexture2D=K,this.setTexture2DArray=$,this.setTexture3D=at,this.setTextureCube=X,this.rebindTextures=Ft,this.setupRenderTarget=ee,this.updateRenderTargetMipmap=tt,this.updateMultisampleRenderTarget=Dt,this.setupDepthRenderbuffer=zt,this.setupFrameBufferTexture=Rt,this.useMultisampledRTT=St}function P_(i,t){function e(n,s=xi){let r,a=ne.getTransfer(s);if(n===ei)return i.UNSIGNED_BYTE;if(n===Nh)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Oh)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Wd)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Vd)return i.BYTE;if(n===Gd)return i.SHORT;if(n===Ar)return i.UNSIGNED_SHORT;if(n===Uh)return i.INT;if(n===qi)return i.UNSIGNED_INT;if(n===On)return i.FLOAT;if(n===Vr)return i.HALF_FLOAT;if(n===$d)return i.ALPHA;if(n===Xd)return i.RGB;if(n===In)return i.RGBA;if(n===qd)return i.LUMINANCE;if(n===Yd)return i.LUMINANCE_ALPHA;if(n===Ds)return i.DEPTH_COMPONENT;if(n===Hs)return i.DEPTH_STENCIL;if(n===Fh)return i.RED;if(n===Bh)return i.RED_INTEGER;if(n===Zd)return i.RG;if(n===zh)return i.RG_INTEGER;if(n===Hh)return i.RGBA_INTEGER;if(n===Xa||n===qa||n===Ya||n===Za)if(a===pe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Xa)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===qa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Ya)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Za)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Xa)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===qa)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Ya)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Za)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===xc||n===_c||n===vc||n===yc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===xc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===_c)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===vc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===yc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===bc||n===Mc||n===Sc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===bc||n===Mc)return a===pe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Sc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===wc||n===Ec||n===Tc||n===Ac||n===Rc||n===Cc||n===Pc||n===Ic||n===Lc||n===Dc||n===kc||n===Uc||n===Nc||n===Oc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===wc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ec)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Tc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ac)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Rc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Cc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Pc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ic)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Lc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Dc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===kc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Uc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Nc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Oc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ja||n===Fc||n===Bc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ja)return a===pe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Fc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Bc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Jd||n===zc||n===Hc||n===Vc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Ja)return r.COMPRESSED_RED_RGTC1_EXT;if(n===zc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Hc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Vc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===zs?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}var sh=class extends Ze{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},Qt=class extends ze{constructor(){super(),this.isGroup=!0,this.type="Group"}},I_={type:"move"},Sr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Qt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Qt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Qt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(let _ of t.hand.values()){let m=e.getJointPose(_,n),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(I_)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Qt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},L_=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,D_=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,rh=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){let s=new sn,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new gn({vertexShader:L_,fragmentShader:D_,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new Me(new ai(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},ah=class extends Si{constructor(t,e){super();let n=this,s=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null,_=new rh,m=e.getContextAttributes(),p=null,v=null,y=[],x=[],D=new st,T=null,R=new Ze;R.viewport=new Te;let L=new Ze;L.viewport=new Te;let w=[R,L],M=new sh,I=null,G=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let lt=y[J];return lt===void 0&&(lt=new Sr,y[J]=lt),lt.getTargetRaySpace()},this.getControllerGrip=function(J){let lt=y[J];return lt===void 0&&(lt=new Sr,y[J]=lt),lt.getGripSpace()},this.getHand=function(J){let lt=y[J];return lt===void 0&&(lt=new Sr,y[J]=lt),lt.getHandSpace()};function z(J){let lt=x.indexOf(J.inputSource);if(lt===-1)return;let Rt=y[lt];Rt!==void 0&&(Rt.update(J.inputSource,J.frame,c||a),Rt.dispatchEvent({type:J.type,data:J.inputSource}))}function W(){s.removeEventListener("select",z),s.removeEventListener("selectstart",z),s.removeEventListener("selectend",z),s.removeEventListener("squeeze",z),s.removeEventListener("squeezestart",z),s.removeEventListener("squeezeend",z),s.removeEventListener("end",W),s.removeEventListener("inputsourceschange",K);for(let J=0;J<y.length;J++){let lt=x[J];lt!==null&&(x[J]=null,y[J].disconnect(lt))}I=null,G=null,_.reset(),t.setRenderTarget(p),f=null,d=null,u=null,s=null,v=null,ae.stop(),n.isPresenting=!1,t.setPixelRatio(T),t.setSize(D.width,D.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){r=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){o=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(J){c=J},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(J){if(s=J,s!==null){if(p=t.getRenderTarget(),s.addEventListener("select",z),s.addEventListener("selectstart",z),s.addEventListener("selectend",z),s.addEventListener("squeeze",z),s.addEventListener("squeezestart",z),s.addEventListener("squeezeend",z),s.addEventListener("end",W),s.addEventListener("inputsourceschange",K),m.xrCompatible!==!0&&await e.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(D),s.renderState.layers===void 0){let lt={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,e,lt),s.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),v=new ni(f.framebufferWidth,f.framebufferHeight,{format:In,type:ei,colorSpace:t.outputColorSpace,stencilBuffer:m.stencil})}else{let lt=null,Rt=null,ut=null;m.depth&&(ut=m.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,lt=m.stencil?Hs:Ds,Rt=m.stencil?zs:qi);let Ut={colorFormat:e.RGBA8,depthFormat:ut,scaleFactor:r};u=new XRWebGLBinding(s,e),d=u.createProjectionLayer(Ut),s.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),v=new ni(d.textureWidth,d.textureHeight,{format:In,type:ei,depthTexture:new ho(d.textureWidth,d.textureHeight,Rt,void 0,void 0,void 0,void 0,void 0,void 0,lt),stencilBuffer:m.stencil,colorSpace:t.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await s.requestReferenceSpace(o),ae.setContext(s),ae.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function K(J){for(let lt=0;lt<J.removed.length;lt++){let Rt=J.removed[lt],ut=x.indexOf(Rt);ut>=0&&(x[ut]=null,y[ut].disconnect(Rt))}for(let lt=0;lt<J.added.length;lt++){let Rt=J.added[lt],ut=x.indexOf(Rt);if(ut===-1){for(let zt=0;zt<y.length;zt++)if(zt>=x.length){x.push(Rt),ut=zt;break}else if(x[zt]===null){x[zt]=Rt,ut=zt;break}if(ut===-1)break}let Ut=y[ut];Ut&&Ut.connect(Rt)}}let $=new P,at=new P;function X(J,lt,Rt){$.setFromMatrixPosition(lt.matrixWorld),at.setFromMatrixPosition(Rt.matrixWorld);let ut=$.distanceTo(at),Ut=lt.projectionMatrix.elements,zt=Rt.projectionMatrix.elements,Ft=Ut[14]/(Ut[10]-1),ee=Ut[14]/(Ut[10]+1),tt=(Ut[9]+1)/Ut[5],ot=(Ut[9]-1)/Ut[5],C=(Ut[8]-1)/Ut[0],Dt=(zt[8]+1)/zt[0],it=Ft*C,St=Ft*Dt,dt=ut/(-C+Dt),Nt=dt*-C;if(lt.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(Nt),J.translateZ(dt),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert(),Ut[10]===-1)J.projectionMatrix.copy(lt.projectionMatrix),J.projectionMatrixInverse.copy(lt.projectionMatrixInverse);else{let bt=Ft+dt,E=ee+dt,b=it-Nt,B=St+(ut-Nt),Y=tt*ee/E*bt,et=ot*ee/E*bt;J.projectionMatrix.makePerspective(b,B,Y,et,bt,E),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}}function ft(J,lt){lt===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(lt.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(s===null)return;let lt=J.near,Rt=J.far;_.texture!==null&&(_.depthNear>0&&(lt=_.depthNear),_.depthFar>0&&(Rt=_.depthFar)),M.near=L.near=R.near=lt,M.far=L.far=R.far=Rt,(I!==M.near||G!==M.far)&&(s.updateRenderState({depthNear:M.near,depthFar:M.far}),I=M.near,G=M.far),R.layers.mask=J.layers.mask|2,L.layers.mask=J.layers.mask|4,M.layers.mask=R.layers.mask|L.layers.mask;let ut=J.parent,Ut=M.cameras;ft(M,ut);for(let zt=0;zt<Ut.length;zt++)ft(Ut[zt],ut);Ut.length===2?X(M,R,L):M.projectionMatrix.copy(R.projectionMatrix),yt(J,M,ut)};function yt(J,lt,Rt){Rt===null?J.matrix.copy(lt.matrixWorld):(J.matrix.copy(Rt.matrixWorld),J.matrix.invert(),J.matrix.multiply(lt.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(lt.projectionMatrix),J.projectionMatrixInverse.copy(lt.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=Rr*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(J){l=J,d!==null&&(d.fixedFoveation=J),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=J)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)};let At=null;function Gt(J,lt){if(h=lt.getViewerPose(c||a),g=lt,h!==null){let Rt=h.views;f!==null&&(t.setRenderTargetFramebuffer(v,f.framebuffer),t.setRenderTarget(v));let ut=!1;Rt.length!==M.cameras.length&&(M.cameras.length=0,ut=!0);for(let zt=0;zt<Rt.length;zt++){let Ft=Rt[zt],ee=null;if(f!==null)ee=f.getViewport(Ft);else{let ot=u.getViewSubImage(d,Ft);ee=ot.viewport,zt===0&&(t.setRenderTargetTextures(v,ot.colorTexture,d.ignoreDepthValues?void 0:ot.depthStencilTexture),t.setRenderTarget(v))}let tt=w[zt];tt===void 0&&(tt=new Ze,tt.layers.enable(zt),tt.viewport=new Te,w[zt]=tt),tt.matrix.fromArray(Ft.transform.matrix),tt.matrix.decompose(tt.position,tt.quaternion,tt.scale),tt.projectionMatrix.fromArray(Ft.projectionMatrix),tt.projectionMatrixInverse.copy(tt.projectionMatrix).invert(),tt.viewport.set(ee.x,ee.y,ee.width,ee.height),zt===0&&(M.matrix.copy(tt.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),ut===!0&&M.cameras.push(tt)}let Ut=s.enabledFeatures;if(Ut&&Ut.includes("depth-sensing")){let zt=u.getDepthInformation(Rt[0]);zt&&zt.isValid&&zt.texture&&_.init(t,zt,s.renderState)}}for(let Rt=0;Rt<y.length;Rt++){let ut=x[Rt],Ut=y[Rt];ut!==null&&Ut!==void 0&&Ut.update(ut,lt,c||a)}At&&At(J,lt),lt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:lt}),g=null}let ae=new rf;ae.setAnimationLoop(Gt),this.setAnimationLoop=function(J){At=J},this.dispose=function(){}}},Hi=new mn,k_=new ue;function U_(i,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,sf(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,v,y,x){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,x)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,v,y):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===$e&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===$e&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let v=t.get(p),y=v.envMap,x=v.envMapRotation;y&&(m.envMap.value=y,Hi.copy(x),Hi.x*=-1,Hi.y*=-1,Hi.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(Hi.y*=-1,Hi.z*=-1),m.envMapRotation.value.setFromMatrix4(k_.makeRotationFromEuler(Hi)),m.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,v,y){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*v,m.scale.value=y*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,v){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===$e&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=v.texture,m.transmissionSamplerSize.value.set(v.width,v.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){let v=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(v.matrixWorld),m.nearDistance.value=v.shadow.camera.near,m.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function N_(i,t,e,n){let s={},r={},a=[],o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(v,y){let x=y.program;n.uniformBlockBinding(v,x)}function c(v,y){let x=s[v.id];x===void 0&&(g(v),x=h(v),s[v.id]=x,v.addEventListener("dispose",m));let D=y.program;n.updateUBOMapping(v,D);let T=t.render.frame;r[v.id]!==T&&(d(v),r[v.id]=T)}function h(v){let y=u();v.__bindingPointIndex=y;let x=i.createBuffer(),D=v.__size,T=v.usage;return i.bindBuffer(i.UNIFORM_BUFFER,x),i.bufferData(i.UNIFORM_BUFFER,D,T),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,y,x),x}function u(){for(let v=0;v<o;v++)if(a.indexOf(v)===-1)return a.push(v),v;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(v){let y=s[v.id],x=v.uniforms,D=v.__cache;i.bindBuffer(i.UNIFORM_BUFFER,y);for(let T=0,R=x.length;T<R;T++){let L=Array.isArray(x[T])?x[T]:[x[T]];for(let w=0,M=L.length;w<M;w++){let I=L[w];if(f(I,T,w,D)===!0){let G=I.__offset,z=Array.isArray(I.value)?I.value:[I.value],W=0;for(let K=0;K<z.length;K++){let $=z[K],at=_($);typeof $=="number"||typeof $=="boolean"?(I.__data[0]=$,i.bufferSubData(i.UNIFORM_BUFFER,G+W,I.__data)):$.isMatrix3?(I.__data[0]=$.elements[0],I.__data[1]=$.elements[1],I.__data[2]=$.elements[2],I.__data[3]=0,I.__data[4]=$.elements[3],I.__data[5]=$.elements[4],I.__data[6]=$.elements[5],I.__data[7]=0,I.__data[8]=$.elements[6],I.__data[9]=$.elements[7],I.__data[10]=$.elements[8],I.__data[11]=0):($.toArray(I.__data,W),W+=at.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,G,I.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(v,y,x,D){let T=v.value,R=y+"_"+x;if(D[R]===void 0)return typeof T=="number"||typeof T=="boolean"?D[R]=T:D[R]=T.clone(),!0;{let L=D[R];if(typeof T=="number"||typeof T=="boolean"){if(L!==T)return D[R]=T,!0}else if(L.equals(T)===!1)return L.copy(T),!0}return!1}function g(v){let y=v.uniforms,x=0,D=16;for(let R=0,L=y.length;R<L;R++){let w=Array.isArray(y[R])?y[R]:[y[R]];for(let M=0,I=w.length;M<I;M++){let G=w[M],z=Array.isArray(G.value)?G.value:[G.value];for(let W=0,K=z.length;W<K;W++){let $=z[W],at=_($),X=x%D,ft=X%at.boundary,yt=X+ft;x+=ft,yt!==0&&D-yt<at.storage&&(x+=D-yt),G.__data=new Float32Array(at.storage/Float32Array.BYTES_PER_ELEMENT),G.__offset=x,x+=at.storage}}}let T=x%D;return T>0&&(x+=D-T),v.__size=x,v.__cache={},this}function _(v){let y={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(y.boundary=4,y.storage=4):v.isVector2?(y.boundary=8,y.storage=8):v.isVector3||v.isColor?(y.boundary=16,y.storage=12):v.isVector4?(y.boundary=16,y.storage=16):v.isMatrix3?(y.boundary=48,y.storage=48):v.isMatrix4?(y.boundary=64,y.storage=64):v.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",v),y}function m(v){let y=v.target;y.removeEventListener("dispose",m);let x=a.indexOf(y.__bindingPointIndex);a.splice(x,1),i.deleteBuffer(s[y.id]),delete s[y.id],delete r[y.id]}function p(){for(let v in s)i.deleteBuffer(s[v]);a=[],s={},r={}}return{bind:l,update:c,dispose:p}}var uo=class{constructor(t={}){let{canvas:e=zp(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=a;let g=new Uint32Array(4),_=new Int32Array(4),m=null,p=null,v=[],y=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=nn,this.toneMapping=yi,this.toneMappingExposure=1;let x=this,D=!1,T=0,R=0,L=null,w=-1,M=null,I=new Te,G=new Te,z=null,W=new Wt(0),K=0,$=e.width,at=e.height,X=1,ft=null,yt=null,At=new Te(0,0,$,at),Gt=new Te(0,0,$,at),ae=!1,J=new Cr,lt=!1,Rt=!1,ut=new ue,Ut=new ue,zt=new P,Ft=new Te,ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},tt=!1;function ot(){return L===null?X:1}let C=n;function Dt(S,O){return e.getContext(S,O)}try{let S={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Lh}`),e.addEventListener("webglcontextlost",Q,!1),e.addEventListener("webglcontextrestored",vt,!1),e.addEventListener("webglcontextcreationerror",xt,!1),C===null){let O="webgl2";if(C=Dt(O,S),C===null)throw Dt(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(S){throw console.error("THREE.WebGLRenderer: "+S.message),S}let it,St,dt,Nt,bt,E,b,B,Y,et,Z,Ct,mt,Mt,Kt,rt,Et,Ot,Bt,Tt,te,Jt,ge,N;function gt(){it=new Kg(C),it.init(),Jt=new P_(C,it),St=new Xg(C,it,t,Jt),dt=new A_(C,it),St.reverseDepthBuffer&&d&&dt.buffers.depth.setReversed(!0),Nt=new ex(C),bt=new p_,E=new C_(C,it,dt,bt,St,Jt,Nt),b=new Yg(x),B=new jg(x),Y=new lm(C),ge=new Wg(C,Y),et=new Qg(C,Y,Nt,ge),Z=new ix(C,et,Y,Nt),Bt=new nx(C,St,E),rt=new qg(bt),Ct=new f_(x,b,B,it,St,ge,rt),mt=new U_(x,bt),Mt=new g_,Kt=new M_(it),Ot=new Gg(x,b,B,dt,Z,f,l),Et=new E_(x,Z,St),N=new N_(C,Nt,St,dt),Tt=new $g(C,it,Nt),te=new tx(C,it,Nt),Nt.programs=Ct.programs,x.capabilities=St,x.extensions=it,x.properties=bt,x.renderLists=Mt,x.shadowMap=Et,x.state=dt,x.info=Nt}gt();let q=new ah(x,C);this.xr=q,this.getContext=function(){return C},this.getContextAttributes=function(){return C.getContextAttributes()},this.forceContextLoss=function(){let S=it.get("WEBGL_lose_context");S&&S.loseContext()},this.forceContextRestore=function(){let S=it.get("WEBGL_lose_context");S&&S.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(S){S!==void 0&&(X=S,this.setSize($,at,!1))},this.getSize=function(S){return S.set($,at)},this.setSize=function(S,O,H=!0){if(q.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}$=S,at=O,e.width=Math.floor(S*X),e.height=Math.floor(O*X),H===!0&&(e.style.width=S+"px",e.style.height=O+"px"),this.setViewport(0,0,S,O)},this.getDrawingBufferSize=function(S){return S.set($*X,at*X).floor()},this.setDrawingBufferSize=function(S,O,H){$=S,at=O,X=H,e.width=Math.floor(S*H),e.height=Math.floor(O*H),this.setViewport(0,0,S,O)},this.getCurrentViewport=function(S){return S.copy(I)},this.getViewport=function(S){return S.copy(At)},this.setViewport=function(S,O,H,V){S.isVector4?At.set(S.x,S.y,S.z,S.w):At.set(S,O,H,V),dt.viewport(I.copy(At).multiplyScalar(X).round())},this.getScissor=function(S){return S.copy(Gt)},this.setScissor=function(S,O,H,V){S.isVector4?Gt.set(S.x,S.y,S.z,S.w):Gt.set(S,O,H,V),dt.scissor(G.copy(Gt).multiplyScalar(X).round())},this.getScissorTest=function(){return ae},this.setScissorTest=function(S){dt.setScissorTest(ae=S)},this.setOpaqueSort=function(S){ft=S},this.setTransparentSort=function(S){yt=S},this.getClearColor=function(S){return S.copy(Ot.getClearColor())},this.setClearColor=function(){Ot.setClearColor.apply(Ot,arguments)},this.getClearAlpha=function(){return Ot.getClearAlpha()},this.setClearAlpha=function(){Ot.setClearAlpha.apply(Ot,arguments)},this.clear=function(S=!0,O=!0,H=!0){let V=0;if(S){let F=!1;if(L!==null){let ct=L.texture.format;F=ct===Hh||ct===zh||ct===Bh}if(F){let ct=L.texture.type,_t=ct===ei||ct===qi||ct===Ar||ct===zs||ct===Nh||ct===Oh,Pt=Ot.getClearColor(),It=Ot.getClearAlpha(),Ht=Pt.r,qt=Pt.g,Lt=Pt.b;_t?(g[0]=Ht,g[1]=qt,g[2]=Lt,g[3]=It,C.clearBufferuiv(C.COLOR,0,g)):(_[0]=Ht,_[1]=qt,_[2]=Lt,_[3]=It,C.clearBufferiv(C.COLOR,0,_))}else V|=C.COLOR_BUFFER_BIT}O&&(V|=C.DEPTH_BUFFER_BIT),H&&(V|=C.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),C.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Q,!1),e.removeEventListener("webglcontextrestored",vt,!1),e.removeEventListener("webglcontextcreationerror",xt,!1),Mt.dispose(),Kt.dispose(),bt.dispose(),b.dispose(),B.dispose(),Z.dispose(),ge.dispose(),N.dispose(),Ct.dispose(),q.dispose(),q.removeEventListener("sessionstart",ou),q.removeEventListener("sessionend",lu),Ci.stop()};function Q(S){S.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),D=!0}function vt(){console.log("THREE.WebGLRenderer: Context Restored."),D=!1;let S=Nt.autoReset,O=Et.enabled,H=Et.autoUpdate,V=Et.needsUpdate,F=Et.type;gt(),Nt.autoReset=S,Et.enabled=O,Et.autoUpdate=H,Et.needsUpdate=V,Et.type=F}function xt(S){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",S.statusMessage)}function Xt(S){let O=S.target;O.removeEventListener("dispose",Xt),Ee(O)}function Ee(S){Ve(S),bt.remove(S)}function Ve(S){let O=bt.get(S).programs;O!==void 0&&(O.forEach(function(H){Ct.releaseProgram(H)}),S.isShaderMaterial&&Ct.releaseShaderCache(S))}this.renderBufferDirect=function(S,O,H,V,F,ct){O===null&&(O=ee);let _t=F.isMesh&&F.matrixWorld.determinant()<0,Pt=Pf(S,O,H,V,F);dt.setMaterial(V,_t);let It=H.index,Ht=1;if(V.wireframe===!0){if(It=et.getWireframeAttribute(H),It===void 0)return;Ht=2}let qt=H.drawRange,Lt=H.attributes.position,se=qt.start*Ht,xe=(qt.start+qt.count)*Ht;ct!==null&&(se=Math.max(se,ct.start*Ht),xe=Math.min(xe,(ct.start+ct.count)*Ht)),It!==null?(se=Math.max(se,0),xe=Math.min(xe,It.count)):Lt!=null&&(se=Math.max(se,0),xe=Math.min(xe,Lt.count));let _e=xe-se;if(_e<0||_e===1/0)return;ge.setup(F,V,Pt,H,It);let je,oe=Tt;if(It!==null&&(je=Y.get(It),oe=te,oe.setIndex(je)),F.isMesh)V.wireframe===!0?(dt.setLineWidth(V.wireframeLinewidth*ot()),oe.setMode(C.LINES)):oe.setMode(C.TRIANGLES);else if(F.isLine){let kt=V.linewidth;kt===void 0&&(kt=1),dt.setLineWidth(kt*ot()),F.isLineSegments?oe.setMode(C.LINES):F.isLineLoop?oe.setMode(C.LINE_LOOP):oe.setMode(C.LINE_STRIP)}else F.isPoints?oe.setMode(C.POINTS):F.isSprite&&oe.setMode(C.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)oe.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(it.get("WEBGL_multi_draw"))oe.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{let kt=F._multiDrawStarts,Hn=F._multiDrawCounts,le=F._multiDrawCount,Sn=It?Y.get(It).bytesPerElement:1,ns=bt.get(V).currentProgram.getUniforms();for(let rn=0;rn<le;rn++)ns.setValue(C,"_gl_DrawID",rn),oe.render(kt[rn]/Sn,Hn[rn])}else if(F.isInstancedMesh)oe.renderInstances(se,_e,F.count);else if(H.isInstancedBufferGeometry){let kt=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,Hn=Math.min(H.instanceCount,kt);oe.renderInstances(se,_e,Hn)}else oe.render(se,_e)};function ce(S,O,H){S.transparent===!0&&S.side===pn&&S.forceSinglePass===!1?(S.side=$e,S.needsUpdate=!0,Zr(S,O,H),S.side=Mi,S.needsUpdate=!0,Zr(S,O,H),S.side=pn):Zr(S,O,H)}this.compile=function(S,O,H=null){H===null&&(H=S),p=Kt.get(H),p.init(O),y.push(p),H.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),S!==H&&S.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();let V=new Set;return S.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;let ct=F.material;if(ct)if(Array.isArray(ct))for(let _t=0;_t<ct.length;_t++){let Pt=ct[_t];ce(Pt,H,F),V.add(Pt)}else ce(ct,H,F),V.add(ct)}),y.pop(),p=null,V},this.compileAsync=function(S,O,H=null){let V=this.compile(S,O,H);return new Promise(F=>{function ct(){if(V.forEach(function(_t){bt.get(_t).currentProgram.isReady()&&V.delete(_t)}),V.size===0){F(S);return}setTimeout(ct,10)}it.get("KHR_parallel_shader_compile")!==null?ct():setTimeout(ct,10)})};let Mn=null;function zn(S){Mn&&Mn(S)}function ou(){Ci.stop()}function lu(){Ci.start()}let Ci=new rf;Ci.setAnimationLoop(zn),typeof self<"u"&&Ci.setContext(self),this.setAnimationLoop=function(S){Mn=S,q.setAnimationLoop(S),S===null?Ci.stop():Ci.start()},q.addEventListener("sessionstart",ou),q.addEventListener("sessionend",lu),this.render=function(S,O){if(O!==void 0&&O.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;if(S.matrixWorldAutoUpdate===!0&&S.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),q.enabled===!0&&q.isPresenting===!0&&(q.cameraAutoUpdate===!0&&q.updateCamera(O),O=q.getCamera()),S.isScene===!0&&S.onBeforeRender(x,S,O,L),p=Kt.get(S,y.length),p.init(O),y.push(p),Ut.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),J.setFromProjectionMatrix(Ut),Rt=this.localClippingEnabled,lt=rt.init(this.clippingPlanes,Rt),m=Mt.get(S,v.length),m.init(),v.push(m),q.enabled===!0&&q.isPresenting===!0){let ct=x.xr.getDepthSensingMesh();ct!==null&&jo(ct,O,-1/0,x.sortObjects)}jo(S,O,0,x.sortObjects),m.finish(),x.sortObjects===!0&&m.sort(ft,yt),tt=q.enabled===!1||q.isPresenting===!1||q.hasDepthSensing()===!1,tt&&Ot.addToRenderList(m,S),this.info.render.frame++,lt===!0&&rt.beginShadows();let H=p.state.shadowsArray;Et.render(H,S,O),lt===!0&&rt.endShadows(),this.info.autoReset===!0&&this.info.reset();let V=m.opaque,F=m.transmissive;if(p.setupLights(),O.isArrayCamera){let ct=O.cameras;if(F.length>0)for(let _t=0,Pt=ct.length;_t<Pt;_t++){let It=ct[_t];hu(V,F,S,It)}tt&&Ot.render(S);for(let _t=0,Pt=ct.length;_t<Pt;_t++){let It=ct[_t];cu(m,S,It,It.viewport)}}else F.length>0&&hu(V,F,S,O),tt&&Ot.render(S),cu(m,S,O);L!==null&&(E.updateMultisampleRenderTarget(L),E.updateRenderTargetMipmap(L)),S.isScene===!0&&S.onAfterRender(x,S,O),ge.resetDefaultState(),w=-1,M=null,y.pop(),y.length>0?(p=y[y.length-1],lt===!0&&rt.setGlobalState(x.clippingPlanes,p.state.camera)):p=null,v.pop(),v.length>0?m=v[v.length-1]:m=null};function jo(S,O,H,V){if(S.visible===!1)return;if(S.layers.test(O.layers)){if(S.isGroup)H=S.renderOrder;else if(S.isLOD)S.autoUpdate===!0&&S.update(O);else if(S.isLight)p.pushLight(S),S.castShadow&&p.pushShadow(S);else if(S.isSprite){if(!S.frustumCulled||J.intersectsSprite(S)){V&&Ft.setFromMatrixPosition(S.matrixWorld).applyMatrix4(Ut);let _t=Z.update(S),Pt=S.material;Pt.visible&&m.push(S,_t,Pt,H,Ft.z,null)}}else if((S.isMesh||S.isLine||S.isPoints)&&(!S.frustumCulled||J.intersectsObject(S))){let _t=Z.update(S),Pt=S.material;if(V&&(S.boundingSphere!==void 0?(S.boundingSphere===null&&S.computeBoundingSphere(),Ft.copy(S.boundingSphere.center)):(_t.boundingSphere===null&&_t.computeBoundingSphere(),Ft.copy(_t.boundingSphere.center)),Ft.applyMatrix4(S.matrixWorld).applyMatrix4(Ut)),Array.isArray(Pt)){let It=_t.groups;for(let Ht=0,qt=It.length;Ht<qt;Ht++){let Lt=It[Ht],se=Pt[Lt.materialIndex];se&&se.visible&&m.push(S,_t,se,H,Ft.z,Lt)}}else Pt.visible&&m.push(S,_t,Pt,H,Ft.z,null)}}let ct=S.children;for(let _t=0,Pt=ct.length;_t<Pt;_t++)jo(ct[_t],O,H,V)}function cu(S,O,H,V){let F=S.opaque,ct=S.transmissive,_t=S.transparent;p.setupLightsView(H),lt===!0&&rt.setGlobalState(x.clippingPlanes,H),V&&dt.viewport(I.copy(V)),F.length>0&&Yr(F,O,H),ct.length>0&&Yr(ct,O,H),_t.length>0&&Yr(_t,O,H),dt.buffers.depth.setTest(!0),dt.buffers.depth.setMask(!0),dt.buffers.color.setMask(!0),dt.setPolygonOffset(!1)}function hu(S,O,H,V){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[V.id]===void 0&&(p.state.transmissionRenderTarget[V.id]=new ni(1,1,{generateMipmaps:!0,type:it.has("EXT_color_buffer_half_float")||it.has("EXT_color_buffer_float")?Vr:ei,minFilter:Xi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ne.workingColorSpace}));let ct=p.state.transmissionRenderTarget[V.id],_t=V.viewport||I;ct.setSize(_t.z,_t.w);let Pt=x.getRenderTarget();x.setRenderTarget(ct),x.getClearColor(W),K=x.getClearAlpha(),K<1&&x.setClearColor(16777215,.5),x.clear(),tt&&Ot.render(H);let It=x.toneMapping;x.toneMapping=yi;let Ht=V.viewport;if(V.viewport!==void 0&&(V.viewport=void 0),p.setupLightsView(V),lt===!0&&rt.setGlobalState(x.clippingPlanes,V),Yr(S,H,V),E.updateMultisampleRenderTarget(ct),E.updateRenderTargetMipmap(ct),it.has("WEBGL_multisampled_render_to_texture")===!1){let qt=!1;for(let Lt=0,se=O.length;Lt<se;Lt++){let xe=O[Lt],_e=xe.object,je=xe.geometry,oe=xe.material,kt=xe.group;if(oe.side===pn&&_e.layers.test(V.layers)){let Hn=oe.side;oe.side=$e,oe.needsUpdate=!0,uu(_e,H,V,je,oe,kt),oe.side=Hn,oe.needsUpdate=!0,qt=!0}}qt===!0&&(E.updateMultisampleRenderTarget(ct),E.updateRenderTargetMipmap(ct))}x.setRenderTarget(Pt),x.setClearColor(W,K),Ht!==void 0&&(V.viewport=Ht),x.toneMapping=It}function Yr(S,O,H){let V=O.isScene===!0?O.overrideMaterial:null;for(let F=0,ct=S.length;F<ct;F++){let _t=S[F],Pt=_t.object,It=_t.geometry,Ht=V===null?_t.material:V,qt=_t.group;Pt.layers.test(H.layers)&&uu(Pt,O,H,It,Ht,qt)}}function uu(S,O,H,V,F,ct){S.onBeforeRender(x,O,H,V,F,ct),S.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,S.matrixWorld),S.normalMatrix.getNormalMatrix(S.modelViewMatrix),F.onBeforeRender(x,O,H,V,S,ct),F.transparent===!0&&F.side===pn&&F.forceSinglePass===!1?(F.side=$e,F.needsUpdate=!0,x.renderBufferDirect(H,O,V,F,S,ct),F.side=Mi,F.needsUpdate=!0,x.renderBufferDirect(H,O,V,F,S,ct),F.side=pn):x.renderBufferDirect(H,O,V,F,S,ct),S.onAfterRender(x,O,H,V,F,ct)}function Zr(S,O,H){O.isScene!==!0&&(O=ee);let V=bt.get(S),F=p.state.lights,ct=p.state.shadowsArray,_t=F.state.version,Pt=Ct.getParameters(S,F.state,ct,O,H),It=Ct.getProgramCacheKey(Pt),Ht=V.programs;V.environment=S.isMeshStandardMaterial?O.environment:null,V.fog=O.fog,V.envMap=(S.isMeshStandardMaterial?B:b).get(S.envMap||V.environment),V.envMapRotation=V.environment!==null&&S.envMap===null?O.environmentRotation:S.envMapRotation,Ht===void 0&&(S.addEventListener("dispose",Xt),Ht=new Map,V.programs=Ht);let qt=Ht.get(It);if(qt!==void 0){if(V.currentProgram===qt&&V.lightsStateVersion===_t)return fu(S,Pt),qt}else Pt.uniforms=Ct.getUniforms(S),S.onBeforeCompile(Pt,x),qt=Ct.acquireProgram(Pt,It),Ht.set(It,qt),V.uniforms=Pt.uniforms;let Lt=V.uniforms;return(!S.isShaderMaterial&&!S.isRawShaderMaterial||S.clipping===!0)&&(Lt.clippingPlanes=rt.uniform),fu(S,Pt),V.needsLights=Lf(S),V.lightsStateVersion=_t,V.needsLights&&(Lt.ambientLightColor.value=F.state.ambient,Lt.lightProbe.value=F.state.probe,Lt.directionalLights.value=F.state.directional,Lt.directionalLightShadows.value=F.state.directionalShadow,Lt.spotLights.value=F.state.spot,Lt.spotLightShadows.value=F.state.spotShadow,Lt.rectAreaLights.value=F.state.rectArea,Lt.ltc_1.value=F.state.rectAreaLTC1,Lt.ltc_2.value=F.state.rectAreaLTC2,Lt.pointLights.value=F.state.point,Lt.pointLightShadows.value=F.state.pointShadow,Lt.hemisphereLights.value=F.state.hemi,Lt.directionalShadowMap.value=F.state.directionalShadowMap,Lt.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Lt.spotShadowMap.value=F.state.spotShadowMap,Lt.spotLightMatrix.value=F.state.spotLightMatrix,Lt.spotLightMap.value=F.state.spotLightMap,Lt.pointShadowMap.value=F.state.pointShadowMap,Lt.pointShadowMatrix.value=F.state.pointShadowMatrix),V.currentProgram=qt,V.uniformsList=null,qt}function du(S){if(S.uniformsList===null){let O=S.currentProgram.getUniforms();S.uniformsList=Us.seqWithValue(O.seq,S.uniforms)}return S.uniformsList}function fu(S,O){let H=bt.get(S);H.outputColorSpace=O.outputColorSpace,H.batching=O.batching,H.batchingColor=O.batchingColor,H.instancing=O.instancing,H.instancingColor=O.instancingColor,H.instancingMorph=O.instancingMorph,H.skinning=O.skinning,H.morphTargets=O.morphTargets,H.morphNormals=O.morphNormals,H.morphColors=O.morphColors,H.morphTargetsCount=O.morphTargetsCount,H.numClippingPlanes=O.numClippingPlanes,H.numIntersection=O.numClipIntersection,H.vertexAlphas=O.vertexAlphas,H.vertexTangents=O.vertexTangents,H.toneMapping=O.toneMapping}function Pf(S,O,H,V,F){O.isScene!==!0&&(O=ee),E.resetTextureUnits();let ct=O.fog,_t=V.isMeshStandardMaterial?O.environment:null,Pt=L===null?x.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:qs,It=(V.isMeshStandardMaterial?B:b).get(V.envMap||_t),Ht=V.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,qt=!!H.attributes.tangent&&(!!V.normalMap||V.anisotropy>0),Lt=!!H.morphAttributes.position,se=!!H.morphAttributes.normal,xe=!!H.morphAttributes.color,_e=yi;V.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(_e=x.toneMapping);let je=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,oe=je!==void 0?je.length:0,kt=bt.get(V),Hn=p.state.lights;if(lt===!0&&(Rt===!0||S!==M)){let un=S===M&&V.id===w;rt.setState(V,S,un)}let le=!1;V.version===kt.__version?(kt.needsLights&&kt.lightsStateVersion!==Hn.state.version||kt.outputColorSpace!==Pt||F.isBatchedMesh&&kt.batching===!1||!F.isBatchedMesh&&kt.batching===!0||F.isBatchedMesh&&kt.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&kt.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&kt.instancing===!1||!F.isInstancedMesh&&kt.instancing===!0||F.isSkinnedMesh&&kt.skinning===!1||!F.isSkinnedMesh&&kt.skinning===!0||F.isInstancedMesh&&kt.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&kt.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&kt.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&kt.instancingMorph===!1&&F.morphTexture!==null||kt.envMap!==It||V.fog===!0&&kt.fog!==ct||kt.numClippingPlanes!==void 0&&(kt.numClippingPlanes!==rt.numPlanes||kt.numIntersection!==rt.numIntersection)||kt.vertexAlphas!==Ht||kt.vertexTangents!==qt||kt.morphTargets!==Lt||kt.morphNormals!==se||kt.morphColors!==xe||kt.toneMapping!==_e||kt.morphTargetsCount!==oe)&&(le=!0):(le=!0,kt.__version=V.version);let Sn=kt.currentProgram;le===!0&&(Sn=Zr(V,O,F));let ns=!1,rn=!1,Js=!1,ve=Sn.getUniforms(),kn=kt.uniforms;if(dt.useProgram(Sn.program)&&(ns=!0,rn=!0,Js=!0),V.id!==w&&(w=V.id,rn=!0),ns||M!==S){dt.buffers.depth.getReversed()?(ut.copy(S.projectionMatrix),Vp(ut),Gp(ut),ve.setValue(C,"projectionMatrix",ut)):ve.setValue(C,"projectionMatrix",S.projectionMatrix),ve.setValue(C,"viewMatrix",S.matrixWorldInverse);let li=ve.map.cameraPosition;li!==void 0&&li.setValue(C,zt.setFromMatrixPosition(S.matrixWorld)),St.logarithmicDepthBuffer&&ve.setValue(C,"logDepthBufFC",2/(Math.log(S.far+1)/Math.LN2)),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&ve.setValue(C,"isOrthographic",S.isOrthographicCamera===!0),M!==S&&(M=S,rn=!0,Js=!0)}if(F.isSkinnedMesh){ve.setOptional(C,F,"bindMatrix"),ve.setOptional(C,F,"bindMatrixInverse");let un=F.skeleton;un&&(un.boneTexture===null&&un.computeBoneTexture(),ve.setValue(C,"boneTexture",un.boneTexture,E))}F.isBatchedMesh&&(ve.setOptional(C,F,"batchingTexture"),ve.setValue(C,"batchingTexture",F._matricesTexture,E),ve.setOptional(C,F,"batchingIdTexture"),ve.setValue(C,"batchingIdTexture",F._indirectTexture,E),ve.setOptional(C,F,"batchingColorTexture"),F._colorsTexture!==null&&ve.setValue(C,"batchingColorTexture",F._colorsTexture,E));let js=H.morphAttributes;if((js.position!==void 0||js.normal!==void 0||js.color!==void 0)&&Bt.update(F,H,Sn),(rn||kt.receiveShadow!==F.receiveShadow)&&(kt.receiveShadow=F.receiveShadow,ve.setValue(C,"receiveShadow",F.receiveShadow)),V.isMeshGouraudMaterial&&V.envMap!==null&&(kn.envMap.value=It,kn.flipEnvMap.value=It.isCubeTexture&&It.isRenderTargetTexture===!1?-1:1),V.isMeshStandardMaterial&&V.envMap===null&&O.environment!==null&&(kn.envMapIntensity.value=O.environmentIntensity),rn&&(ve.setValue(C,"toneMappingExposure",x.toneMappingExposure),kt.needsLights&&If(kn,Js),ct&&V.fog===!0&&mt.refreshFogUniforms(kn,ct),mt.refreshMaterialUniforms(kn,V,X,at,p.state.transmissionRenderTarget[S.id]),Us.upload(C,du(kt),kn,E)),V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(Us.upload(C,du(kt),kn,E),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&ve.setValue(C,"center",F.center),ve.setValue(C,"modelViewMatrix",F.modelViewMatrix),ve.setValue(C,"normalMatrix",F.normalMatrix),ve.setValue(C,"modelMatrix",F.matrixWorld),V.isShaderMaterial||V.isRawShaderMaterial){let un=V.uniformsGroups;for(let li=0,ci=un.length;li<ci;li++){let pu=un[li];N.update(pu,Sn),N.bind(pu,Sn)}}return Sn}function If(S,O){S.ambientLightColor.needsUpdate=O,S.lightProbe.needsUpdate=O,S.directionalLights.needsUpdate=O,S.directionalLightShadows.needsUpdate=O,S.pointLights.needsUpdate=O,S.pointLightShadows.needsUpdate=O,S.spotLights.needsUpdate=O,S.spotLightShadows.needsUpdate=O,S.rectAreaLights.needsUpdate=O,S.hemisphereLights.needsUpdate=O}function Lf(S){return S.isMeshLambertMaterial||S.isMeshToonMaterial||S.isMeshPhongMaterial||S.isMeshStandardMaterial||S.isShadowMaterial||S.isShaderMaterial&&S.lights===!0}this.getActiveCubeFace=function(){return T},this.getActiveMipmapLevel=function(){return R},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(S,O,H){bt.get(S.texture).__webglTexture=O,bt.get(S.depthTexture).__webglTexture=H;let V=bt.get(S);V.__hasExternalTextures=!0,V.__autoAllocateDepthBuffer=H===void 0,V.__autoAllocateDepthBuffer||it.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),V.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(S,O){let H=bt.get(S);H.__webglFramebuffer=O,H.__useDefaultFramebuffer=O===void 0},this.setRenderTarget=function(S,O=0,H=0){L=S,T=O,R=H;let V=!0,F=null,ct=!1,_t=!1;if(S){let It=bt.get(S);if(It.__useDefaultFramebuffer!==void 0)dt.bindFramebuffer(C.FRAMEBUFFER,null),V=!1;else if(It.__webglFramebuffer===void 0)E.setupRenderTarget(S);else if(It.__hasExternalTextures)E.rebindTextures(S,bt.get(S.texture).__webglTexture,bt.get(S.depthTexture).__webglTexture);else if(S.depthBuffer){let Lt=S.depthTexture;if(It.__boundDepthTexture!==Lt){if(Lt!==null&&bt.has(Lt)&&(S.width!==Lt.image.width||S.height!==Lt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");E.setupDepthRenderbuffer(S)}}let Ht=S.texture;(Ht.isData3DTexture||Ht.isDataArrayTexture||Ht.isCompressedArrayTexture)&&(_t=!0);let qt=bt.get(S).__webglFramebuffer;S.isWebGLCubeRenderTarget?(Array.isArray(qt[O])?F=qt[O][H]:F=qt[O],ct=!0):S.samples>0&&E.useMultisampledRTT(S)===!1?F=bt.get(S).__webglMultisampledFramebuffer:Array.isArray(qt)?F=qt[H]:F=qt,I.copy(S.viewport),G.copy(S.scissor),z=S.scissorTest}else I.copy(At).multiplyScalar(X).floor(),G.copy(Gt).multiplyScalar(X).floor(),z=ae;if(dt.bindFramebuffer(C.FRAMEBUFFER,F)&&V&&dt.drawBuffers(S,F),dt.viewport(I),dt.scissor(G),dt.setScissorTest(z),ct){let It=bt.get(S.texture);C.framebufferTexture2D(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,C.TEXTURE_CUBE_MAP_POSITIVE_X+O,It.__webglTexture,H)}else if(_t){let It=bt.get(S.texture),Ht=O||0;C.framebufferTextureLayer(C.FRAMEBUFFER,C.COLOR_ATTACHMENT0,It.__webglTexture,H||0,Ht)}w=-1},this.readRenderTargetPixels=function(S,O,H,V,F,ct,_t){if(!(S&&S.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Pt=bt.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&_t!==void 0&&(Pt=Pt[_t]),Pt){dt.bindFramebuffer(C.FRAMEBUFFER,Pt);try{let It=S.texture,Ht=It.format,qt=It.type;if(!St.textureFormatReadable(Ht)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!St.textureTypeReadable(qt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=S.width-V&&H>=0&&H<=S.height-F&&C.readPixels(O,H,V,F,Jt.convert(Ht),Jt.convert(qt),ct)}finally{let It=L!==null?bt.get(L).__webglFramebuffer:null;dt.bindFramebuffer(C.FRAMEBUFFER,It)}}},this.readRenderTargetPixelsAsync=async function(S,O,H,V,F,ct,_t){if(!(S&&S.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Pt=bt.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&_t!==void 0&&(Pt=Pt[_t]),Pt){let It=S.texture,Ht=It.format,qt=It.type;if(!St.textureFormatReadable(Ht))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!St.textureTypeReadable(qt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(O>=0&&O<=S.width-V&&H>=0&&H<=S.height-F){dt.bindFramebuffer(C.FRAMEBUFFER,Pt);let Lt=C.createBuffer();C.bindBuffer(C.PIXEL_PACK_BUFFER,Lt),C.bufferData(C.PIXEL_PACK_BUFFER,ct.byteLength,C.STREAM_READ),C.readPixels(O,H,V,F,Jt.convert(Ht),Jt.convert(qt),0);let se=L!==null?bt.get(L).__webglFramebuffer:null;dt.bindFramebuffer(C.FRAMEBUFFER,se);let xe=C.fenceSync(C.SYNC_GPU_COMMANDS_COMPLETE,0);return C.flush(),await Hp(C,xe,4),C.bindBuffer(C.PIXEL_PACK_BUFFER,Lt),C.getBufferSubData(C.PIXEL_PACK_BUFFER,0,ct),C.deleteBuffer(Lt),C.deleteSync(xe),ct}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(S,O=null,H=0){S.isTexture!==!0&&(vr("WebGLRenderer: copyFramebufferToTexture function signature has changed."),O=arguments[0]||null,S=arguments[1]);let V=Math.pow(2,-H),F=Math.floor(S.image.width*V),ct=Math.floor(S.image.height*V),_t=O!==null?O.x:0,Pt=O!==null?O.y:0;E.setTexture2D(S,0),C.copyTexSubImage2D(C.TEXTURE_2D,H,0,0,_t,Pt,F,ct),dt.unbindTexture()},this.copyTextureToTexture=function(S,O,H=null,V=null,F=0){S.isTexture!==!0&&(vr("WebGLRenderer: copyTextureToTexture function signature has changed."),V=arguments[0]||null,S=arguments[1],O=arguments[2],F=arguments[3]||0,H=null);let ct,_t,Pt,It,Ht,qt,Lt,se,xe,_e=S.isCompressedTexture?S.mipmaps[F]:S.image;H!==null?(ct=H.max.x-H.min.x,_t=H.max.y-H.min.y,Pt=H.isBox3?H.max.z-H.min.z:1,It=H.min.x,Ht=H.min.y,qt=H.isBox3?H.min.z:0):(ct=_e.width,_t=_e.height,Pt=_e.depth||1,It=0,Ht=0,qt=0),V!==null?(Lt=V.x,se=V.y,xe=V.z):(Lt=0,se=0,xe=0);let je=Jt.convert(O.format),oe=Jt.convert(O.type),kt;O.isData3DTexture?(E.setTexture3D(O,0),kt=C.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(E.setTexture2DArray(O,0),kt=C.TEXTURE_2D_ARRAY):(E.setTexture2D(O,0),kt=C.TEXTURE_2D),C.pixelStorei(C.UNPACK_FLIP_Y_WEBGL,O.flipY),C.pixelStorei(C.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),C.pixelStorei(C.UNPACK_ALIGNMENT,O.unpackAlignment);let Hn=C.getParameter(C.UNPACK_ROW_LENGTH),le=C.getParameter(C.UNPACK_IMAGE_HEIGHT),Sn=C.getParameter(C.UNPACK_SKIP_PIXELS),ns=C.getParameter(C.UNPACK_SKIP_ROWS),rn=C.getParameter(C.UNPACK_SKIP_IMAGES);C.pixelStorei(C.UNPACK_ROW_LENGTH,_e.width),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,_e.height),C.pixelStorei(C.UNPACK_SKIP_PIXELS,It),C.pixelStorei(C.UNPACK_SKIP_ROWS,Ht),C.pixelStorei(C.UNPACK_SKIP_IMAGES,qt);let Js=S.isDataArrayTexture||S.isData3DTexture,ve=O.isDataArrayTexture||O.isData3DTexture;if(S.isRenderTargetTexture||S.isDepthTexture){let kn=bt.get(S),js=bt.get(O),un=bt.get(kn.__renderTarget),li=bt.get(js.__renderTarget);dt.bindFramebuffer(C.READ_FRAMEBUFFER,un.__webglFramebuffer),dt.bindFramebuffer(C.DRAW_FRAMEBUFFER,li.__webglFramebuffer);for(let ci=0;ci<Pt;ci++)Js&&C.framebufferTextureLayer(C.READ_FRAMEBUFFER,C.COLOR_ATTACHMENT0,bt.get(S).__webglTexture,F,qt+ci),S.isDepthTexture?(ve&&C.framebufferTextureLayer(C.DRAW_FRAMEBUFFER,C.COLOR_ATTACHMENT0,bt.get(O).__webglTexture,F,xe+ci),C.blitFramebuffer(It,Ht,ct,_t,Lt,se,ct,_t,C.DEPTH_BUFFER_BIT,C.NEAREST)):ve?C.copyTexSubImage3D(kt,F,Lt,se,xe+ci,It,Ht,ct,_t):C.copyTexSubImage2D(kt,F,Lt,se,xe+ci,It,Ht,ct,_t);dt.bindFramebuffer(C.READ_FRAMEBUFFER,null),dt.bindFramebuffer(C.DRAW_FRAMEBUFFER,null)}else ve?S.isDataTexture||S.isData3DTexture?C.texSubImage3D(kt,F,Lt,se,xe,ct,_t,Pt,je,oe,_e.data):O.isCompressedArrayTexture?C.compressedTexSubImage3D(kt,F,Lt,se,xe,ct,_t,Pt,je,_e.data):C.texSubImage3D(kt,F,Lt,se,xe,ct,_t,Pt,je,oe,_e):S.isDataTexture?C.texSubImage2D(C.TEXTURE_2D,F,Lt,se,ct,_t,je,oe,_e.data):S.isCompressedTexture?C.compressedTexSubImage2D(C.TEXTURE_2D,F,Lt,se,_e.width,_e.height,je,_e.data):C.texSubImage2D(C.TEXTURE_2D,F,Lt,se,ct,_t,je,oe,_e);C.pixelStorei(C.UNPACK_ROW_LENGTH,Hn),C.pixelStorei(C.UNPACK_IMAGE_HEIGHT,le),C.pixelStorei(C.UNPACK_SKIP_PIXELS,Sn),C.pixelStorei(C.UNPACK_SKIP_ROWS,ns),C.pixelStorei(C.UNPACK_SKIP_IMAGES,rn),F===0&&O.generateMipmaps&&C.generateMipmap(kt),dt.unbindTexture()},this.copyTextureToTexture3D=function(S,O,H=null,V=null,F=0){return S.isTexture!==!0&&(vr("WebGLRenderer: copyTextureToTexture3D function signature has changed."),H=arguments[0]||null,V=arguments[1]||null,S=arguments[2],O=arguments[3],F=arguments[4]||0),vr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(S,O,H,V,F)},this.initRenderTarget=function(S){bt.get(S).__webglFramebuffer===void 0&&E.setupRenderTarget(S)},this.initTexture=function(S){S.isCubeTexture?E.setTextureCube(S,0):S.isData3DTexture?E.setTexture3D(S,0):S.isDataArrayTexture||S.isCompressedArrayTexture?E.setTexture2DArray(S,0):E.setTexture2D(S,0),dt.unbindTexture()},this.resetState=function(){T=0,R=0,L=null,dt.reset(),ge.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Qn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorspace=ne._getDrawingBufferColorSpace(t),e.unpackColorSpace=ne._getUnpackColorSpace()}};var Pr=class i{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new Wt(t),this.near=e,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Ir=class extends ze{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new mn,this.environmentIntensity=1,this.environmentRotation=new mn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},oh=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Wc,this.updateRanges=[],this.version=0,this.uuid=Fn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Fn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Fn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},qe=new P,fo=class i{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyMatrix4(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyNormalMatrix(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.transformDirection(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=Pn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=he(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=Pn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=Pn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=Pn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=Pn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array),s=he(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array),s=he(s,this.array),r=he(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Ne(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new i(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Lr=class extends si{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new Wt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Es,pr=new P,Ts=new P,As=new P,Rs=new st,mr=new st,hf=new ue,Na=new P,gr=new P,Oa=new P,Rd=new st,tc=new st,Cd=new st,po=class extends ze{constructor(t=new Lr){if(super(),this.isSprite=!0,this.type="Sprite",Es===void 0){Es=new Re;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new oh(e,5);Es.setIndex([0,1,2,0,2,3]),Es.setAttribute("position",new fo(n,3,0,!1)),Es.setAttribute("uv",new fo(n,2,3,!1))}this.geometry=Es,this.material=t,this.center=new st(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ts.setFromMatrixScale(this.matrixWorld),hf.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),As.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ts.multiplyScalar(-As.z);let n=this.material.rotation,s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));let a=this.center;Fa(Na.set(-.5,-.5,0),As,a,Ts,s,r),Fa(gr.set(.5,-.5,0),As,a,Ts,s,r),Fa(Oa.set(.5,.5,0),As,a,Ts,s,r),Rd.set(0,0),tc.set(1,0),Cd.set(1,1);let o=t.ray.intersectTriangle(Na,gr,Oa,!1,pr);if(o===null&&(Fa(gr.set(-.5,.5,0),As,a,Ts,s,r),tc.set(0,1),o=t.ray.intersectTriangle(Na,Oa,gr,!1,pr),o===null))return;let l=t.ray.origin.distanceTo(pr);l<t.near||l>t.far||e.push({distance:l,point:pr.clone(),uv:_i.getInterpolation(pr,Na,gr,Oa,Rd,tc,Cd,new st),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Fa(i,t,e,n,s,r){Rs.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(mr.x=r*Rs.x-s*Rs.y,mr.y=s*Rs.x+r*Rs.y):mr.copy(Rs),i.copy(t),i.x+=mr.x,i.y+=mr.y,i.applyMatrix4(hf)}var lh=class extends sn{constructor(t=null,e=1,n=1,s,r,a,o,l,c=cn,h=cn,u,d){super(null,a,o,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var mo=class extends Ne{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Cs=new ue,Pd=new ue,Ba=[],Id=new ii,O_=new ue,xr=new Me,_r=new wi,go=class extends Me{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new mo(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,O_)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new ii),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Cs),Id.copy(t.boundingBox).applyMatrix4(Cs),this.boundingBox.union(Id)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new wi),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Cs),_r.copy(t.boundingSphere).applyMatrix4(Cs),this.boundingSphere.union(_r)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=t*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(t,e){let n=this.matrixWorld,s=this.count;if(xr.geometry=this.geometry,xr.material=this.material,xr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),_r.copy(this.boundingSphere),_r.applyMatrix4(n),t.ray.intersectsSphere(_r)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Cs),Pd.multiplyMatrices(n,Cs),xr.matrixWorld=Pd,xr.raycast(t,Ba);for(let a=0,o=Ba.length;a<o;a++){let l=Ba[a];l.instanceId=r,l.object=this,e.push(l)}Ba.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new mo(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new lh(new Float32Array(s*this.count),s,this.count,Fh,On));let r=this.morphTexture.source.data.data,a=0;for(let c=0;c<n.length;c++)a+=n[c];let o=this.geometry.morphTargetsRelative?1:1-a,l=s*t;r[l]=o,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var Yi=class extends si{static get type(){return"PointsMaterial"}constructor(t){super(),this.isPointsMaterial=!0,this.color=new Wt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ld=new ue,ch=new no,za=new wi,Ha=new P,Ws=class extends ze{constructor(t=new Re,e=new Yi){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),za.copy(n.boundingSphere),za.applyMatrix4(s),za.radius+=r,t.ray.intersectsSphere(za)===!1)return;Ld.copy(s).invert(),ch.copy(t.ray).applyMatrix4(Ld);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let g=d,_=f;g<_;g++){let m=c.getX(g);Ha.fromBufferAttribute(u,m),Dd(Ha,m,l,s,t,e,this)}}else{let d=Math.max(0,a.start),f=Math.min(u.count,a.start+a.count);for(let g=d,_=f;g<_;g++)Ha.fromBufferAttribute(u,g),Dd(Ha,g,l,s,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Dd(i,t,e,n,s,r,a){let o=ch.distanceSqToPoint(i);if(o<e){let l=new P;ch.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}var xo=class extends sn{constructor(t,e,n,s,r,a,o,l,c){super(t,e,n,s,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},xn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),r+=n.distanceTo(s),e.push(r),s=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),s=0,r=n.length,a;e?a=e:a=t*n[r-1];let o=0,l=r-1,c;for(;o<=l;)if(s=Math.floor(o+(l-o)/2),c=n[s]-a,c<0)o=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===a)return s/(r-1);let h=n[s],d=n[s+1]-h,f=(a-h)/d;return(s+f)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let a=this.getPoint(s),o=this.getPoint(r),l=e||(a.isVector2?new st:new P);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new P,s=[],r=[],a=[],o=new P,l=new ue;for(let f=0;f<=t;f++){let g=f/t;s[f]=this.getTangentAt(g,new P)}r[0]=new P,a[0]=new P;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let f=1;f<=t;f++){if(r[f]=r[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(s[f-1],s[f]),o.length()>Number.EPSILON){o.normalize();let g=Math.acos(Ue(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(o,g))}a[f].crossVectors(s[f],r[f])}if(e===!0){let f=Math.acos(Ue(r[0].dot(r[t]),-1,1));f/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(f=-f);for(let g=1;g<=t;g++)r[g].applyMatrix4(l.makeRotationAxis(s[g],f*g)),a[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},Dr=class extends xn{constructor(t=0,e=0,n=1,s=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(t,e=new st){let n=e,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);let o=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},hh=class extends Dr{constructor(t,e,n,s,r,a){super(t,e,n,n,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function Wh(){let i=0,t=0,e=0,n=0;function s(r,a,o,l){i=r,t=o,e=-3*r+3*a-2*o-l,n=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){s(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,u){let d=(a-r)/c-(o-r)/(c+h)+(o-a)/h,f=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,f*=h,s(a,o,d,f)},calc:function(r){let a=r*r,o=a*r;return i+t*r+e*a+n*o}}}var Va=new P,ec=new Wh,nc=new Wh,ic=new Wh,uh=class extends xn{constructor(t=[],e=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=s}getPoint(t,e=new P){let n=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let c,h;this.closed||o>0?c=s[(o-1)%r]:(Va.subVectors(s[0],s[1]).add(s[0]),c=Va);let u=s[o%r],d=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:(Va.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Va),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,g=Math.pow(c.distanceToSquared(u),f),_=Math.pow(u.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(h),f);_<1e-4&&(_=1),g<1e-4&&(g=_),m<1e-4&&(m=_),ec.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,_,m),nc.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,_,m),ic.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,_,m)}else this.curveType==="catmullrom"&&(ec.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),nc.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),ic.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(ec.calc(l),nc.calc(l),ic.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new P().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function kd(i,t,e,n,s){let r=(n-t)*.5,a=(s-e)*.5,o=i*i,l=i*o;return(2*e-2*n+r+a)*l+(-3*e+3*n-2*r-a)*o+r*i+e}function F_(i,t){let e=1-i;return e*e*t}function B_(i,t){return 2*(1-i)*i*t}function z_(i,t){return i*i*t}function wr(i,t,e,n){return F_(i,t)+B_(i,e)+z_(i,n)}function H_(i,t){let e=1-i;return e*e*e*t}function V_(i,t){let e=1-i;return 3*e*e*i*t}function G_(i,t){return 3*(1-i)*i*i*t}function W_(i,t){return i*i*i*t}function Er(i,t,e,n,s){return H_(i,t)+V_(i,e)+G_(i,n)+W_(i,s)}var _o=class extends xn{constructor(t=new st,e=new st,n=new st,s=new st){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new st){let n=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Er(t,s.x,r.x,a.x,o.x),Er(t,s.y,r.y,a.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},dh=class extends xn{constructor(t=new P,e=new P,n=new P,s=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new P){let n=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Er(t,s.x,r.x,a.x,o.x),Er(t,s.y,r.y,a.y,o.y),Er(t,s.z,r.z,a.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},vo=class extends xn{constructor(t=new st,e=new st){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new st){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new st){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},fh=class extends xn{constructor(t=new P,e=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new P){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new P){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},yo=class extends xn{constructor(t=new st,e=new st,n=new st){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new st){let n=e,s=this.v0,r=this.v1,a=this.v2;return n.set(wr(t,s.x,r.x,a.x),wr(t,s.y,r.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ph=class extends xn{constructor(t=new P,e=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new P){let n=e,s=this.v0,r=this.v1,a=this.v2;return n.set(wr(t,s.x,r.x,a.x),wr(t,s.y,r.y,a.y),wr(t,s.z,r.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},bo=class extends xn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new st){let n=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,l=s[a===0?a:a-1],c=s[a],h=s[a>s.length-2?s.length-1:a+1],u=s[a>s.length-3?s.length-1:a+2];return n.set(kd(o,l.x,c.x,h.x,u.x),kd(o,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let s=t.points[e];this.points.push(new st().fromArray(s))}return this}},mh=Object.freeze({__proto__:null,ArcCurve:hh,CatmullRomCurve3:uh,CubicBezierCurve:_o,CubicBezierCurve3:dh,EllipseCurve:Dr,LineCurve:vo,LineCurve3:fh,QuadraticBezierCurve:yo,QuadraticBezierCurve3:ph,SplineCurve:bo}),gh=class extends xn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new mh[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=n){let a=s[r]-n,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,s=this.curves.length;n<s;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let s=0,r=this.curves;s<r.length;s++){let a=r[s],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let s=t.curves[e];this.curves.push(new mh[s.type]().fromJSON(s))}return this}},kr=class extends gh{constructor(t){super(),this.type="Path",this.currentPoint=new st,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new vo(this.currentPoint.clone(),new st(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,s){let r=new yo(this.currentPoint.clone(),new st(t,e),new st(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(t,e,n,s,r,a){let o=new _o(this.currentPoint.clone(),new st(t,e),new st(n,s),new st(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new bo(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,s,r,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+o,e+l,n,s,r,a),this}absarc(t,e,n,s,r,a){return this.absellipse(t,e,n,n,s,r,a),this}ellipse(t,e,n,s,r,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,s,r,a,o,l),this}absellipse(t,e,n,s,r,a,o,l){let c=new Dr(t,e,n,s,r,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}},xh=class i extends Re{constructor(t=[new st(0,-.5),new st(.5,0),new st(0,.5)],e=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:s},e=Math.floor(e),s=Ue(s,0,Math.PI*2);let r=[],a=[],o=[],l=[],c=[],h=1/e,u=new P,d=new st,f=new P,g=new P,_=new P,m=0,p=0;for(let v=0;v<=t.length-1;v++)switch(v){case 0:m=t[v+1].x-t[v].x,p=t[v+1].y-t[v].y,f.x=p*1,f.y=-m,f.z=p*0,_.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case t.length-1:l.push(_.x,_.y,_.z);break;default:m=t[v+1].x-t[v].x,p=t[v+1].y-t[v].y,f.x=p*1,f.y=-m,f.z=p*0,g.copy(f),f.x+=_.x,f.y+=_.y,f.z+=_.z,f.normalize(),l.push(f.x,f.y,f.z),_.copy(g)}for(let v=0;v<=e;v++){let y=n+v*h*s,x=Math.sin(y),D=Math.cos(y);for(let T=0;T<=t.length-1;T++){u.x=t[T].x*x,u.y=t[T].y,u.z=t[T].x*D,a.push(u.x,u.y,u.z),d.x=v/e,d.y=T/(t.length-1),o.push(d.x,d.y);let R=l[3*T+0]*x,L=l[3*T+1],w=l[3*T+0]*D;c.push(R,L,w)}}for(let v=0;v<e;v++)for(let y=0;y<t.length-1;y++){let x=y+v*t.length,D=x,T=x+t.length,R=x+t.length+1,L=x+1;r.push(D,T,L),r.push(R,L,T)}this.setIndex(r),this.setAttribute("position",new re(a,3)),this.setAttribute("uv",new re(o,2)),this.setAttribute("normal",new re(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.points,t.segments,t.phiStart,t.phiLength)}},Mo=class i extends xh{constructor(t=1,e=1,n=4,s=8){let r=new kr;r.absarc(0,-e/2,t,Math.PI*1.5,0),r.absarc(0,e/2,t,0,Math.PI*.5),super(r.getPoints(n),s),this.type="CapsuleGeometry",this.parameters={radius:t,length:e,capSegments:n,radialSegments:s}}static fromJSON(t){return new i(t.radius,t.length,t.capSegments,t.radialSegments)}},So=class i extends Re{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],l=[],c=new P,h=new st;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){let f=n+u/e*s;c.x=t*Math.cos(f),c.y=t*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/t+1)/2,h.y=(a[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new re(a,3)),this.setAttribute("normal",new re(o,3)),this.setAttribute("uv",new re(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}},Zi=class i extends Re{constructor(t=1,e=1,n=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],f=[],g=0,_=[],m=n/2,p=0;v(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new re(u,3)),this.setAttribute("normal",new re(d,3)),this.setAttribute("uv",new re(f,2));function v(){let x=new P,D=new P,T=0,R=(e-t)/n;for(let L=0;L<=r;L++){let w=[],M=L/r,I=M*(e-t)+t;for(let G=0;G<=s;G++){let z=G/s,W=z*l+o,K=Math.sin(W),$=Math.cos(W);D.x=I*K,D.y=-M*n+m,D.z=I*$,u.push(D.x,D.y,D.z),x.set(K,R,$).normalize(),d.push(x.x,x.y,x.z),f.push(z,1-M),w.push(g++)}_.push(w)}for(let L=0;L<s;L++)for(let w=0;w<r;w++){let M=_[w][L],I=_[w+1][L],G=_[w+1][L+1],z=_[w][L+1];(t>0||w!==0)&&(h.push(M,I,z),T+=3),(e>0||w!==r-1)&&(h.push(I,G,z),T+=3)}c.addGroup(p,T,0),p+=T}function y(x){let D=g,T=new st,R=new P,L=0,w=x===!0?t:e,M=x===!0?1:-1;for(let G=1;G<=s;G++)u.push(0,m*M,0),d.push(0,M,0),f.push(.5,.5),g++;let I=g;for(let G=0;G<=s;G++){let W=G/s*l+o,K=Math.cos(W),$=Math.sin(W);R.x=w*$,R.y=m*M,R.z=w*K,u.push(R.x,R.y,R.z),d.push(0,M,0),T.x=K*.5+.5,T.y=$*.5*M+.5,f.push(T.x,T.y),g++}for(let G=0;G<s;G++){let z=D+G,W=I+G;x===!0?h.push(W,W+1,z):h.push(W+1,W,z),L+=3}c.addGroup(p,L,x===!0?1:2),p+=L}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},wo=class i extends Zi{constructor(t=1,e=1,n=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new i(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Ur=class i extends Re{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};let r=[],a=[];o(s),c(n),h(),this.setAttribute("position",new re(r,3)),this.setAttribute("normal",new re(r.slice(),3)),this.setAttribute("uv",new re(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(v){let y=new P,x=new P,D=new P;for(let T=0;T<e.length;T+=3)f(e[T+0],y),f(e[T+1],x),f(e[T+2],D),l(y,x,D,v)}function l(v,y,x,D){let T=D+1,R=[];for(let L=0;L<=T;L++){R[L]=[];let w=v.clone().lerp(x,L/T),M=y.clone().lerp(x,L/T),I=T-L;for(let G=0;G<=I;G++)G===0&&L===T?R[L][G]=w:R[L][G]=w.clone().lerp(M,G/I)}for(let L=0;L<T;L++)for(let w=0;w<2*(T-L)-1;w++){let M=Math.floor(w/2);w%2===0?(d(R[L][M+1]),d(R[L+1][M]),d(R[L][M])):(d(R[L][M+1]),d(R[L+1][M+1]),d(R[L+1][M]))}}function c(v){let y=new P;for(let x=0;x<r.length;x+=3)y.x=r[x+0],y.y=r[x+1],y.z=r[x+2],y.normalize().multiplyScalar(v),r[x+0]=y.x,r[x+1]=y.y,r[x+2]=y.z}function h(){let v=new P;for(let y=0;y<r.length;y+=3){v.x=r[y+0],v.y=r[y+1],v.z=r[y+2];let x=m(v)/2/Math.PI+.5,D=p(v)/Math.PI+.5;a.push(x,1-D)}g(),u()}function u(){for(let v=0;v<a.length;v+=6){let y=a[v+0],x=a[v+2],D=a[v+4],T=Math.max(y,x,D),R=Math.min(y,x,D);T>.9&&R<.1&&(y<.2&&(a[v+0]+=1),x<.2&&(a[v+2]+=1),D<.2&&(a[v+4]+=1))}}function d(v){r.push(v.x,v.y,v.z)}function f(v,y){let x=v*3;y.x=t[x+0],y.y=t[x+1],y.z=t[x+2]}function g(){let v=new P,y=new P,x=new P,D=new P,T=new st,R=new st,L=new st;for(let w=0,M=0;w<r.length;w+=9,M+=6){v.set(r[w+0],r[w+1],r[w+2]),y.set(r[w+3],r[w+4],r[w+5]),x.set(r[w+6],r[w+7],r[w+8]),T.set(a[M+0],a[M+1]),R.set(a[M+2],a[M+3]),L.set(a[M+4],a[M+5]),D.copy(v).add(y).add(x).divideScalar(3);let I=m(D);_(T,M+0,v,I),_(R,M+2,y,I),_(L,M+4,x,I)}}function _(v,y,x,D){D<0&&v.x===1&&(a[y]=v.x-1),x.x===0&&x.z===0&&(a[y]=D/2/Math.PI+.5)}function m(v){return Math.atan2(v.z,-v.x)}function p(v){return Math.atan2(-v.y,Math.sqrt(v.x*v.x+v.z*v.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.vertices,t.indices,t.radius,t.details)}},Eo=class i extends Ur{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var Ei=class extends kr{constructor(t){super(t),this.uuid=Fn(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let n=0,s=this.holes.length;n<s;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let s=t.holes[e];this.holes.push(new kr().fromJSON(s))}return this}},$_={triangulate:function(i,t,e=2){let n=t&&t.length,s=n?t[0]*e:i.length,r=uf(i,0,s,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,l,c,h,u,d,f;if(n&&(r=J_(i,t,r,e)),i.length>80*e){o=c=i[0],l=h=i[1];for(let g=e;g<s;g+=e)u=i[g],d=i[g+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);f=Math.max(c-o,h-l),f=f!==0?32767/f:0}return Nr(r,a,e,o,l,f,0),a}};function uf(i,t,e,n,s){let r,a;if(s===ov(i,t,e,n)>0)for(r=t;r<e;r+=n)a=Ud(r,i[r],i[r+1],a);else for(r=e-n;r>=t;r-=n)a=Ud(r,i[r],i[r+1],a);return a&&ko(a,a.next)&&(Fr(a),a=a.next),a}function Ji(i,t){if(!i)return i;t||(t=i);let e=i,n;do if(n=!1,!e.steiner&&(ko(e,e.next)||we(e.prev,e,e.next)===0)){if(Fr(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Nr(i,t,e,n,s,r,a){if(!i)return;!a&&r&&ev(i,n,s,r);let o=i,l,c;for(;i.prev!==i.next;){if(l=i.prev,c=i.next,r?q_(i,n,s,r):X_(i)){t.push(l.i/e|0),t.push(i.i/e|0),t.push(c.i/e|0),Fr(i),i=c.next,o=c.next;continue}if(i=c,i===o){a?a===1?(i=Y_(Ji(i),t,e),Nr(i,t,e,n,s,r,2)):a===2&&Z_(i,t,e,n,s,r):Nr(Ji(i),t,e,n,s,r,1);break}}}function X_(i){let t=i.prev,e=i,n=i.next;if(we(t,e,n)>=0)return!1;let s=t.x,r=e.x,a=n.x,o=t.y,l=e.y,c=n.y,h=s<r?s<a?s:a:r<a?r:a,u=o<l?o<c?o:c:l<c?l:c,d=s>r?s>a?s:a:r>a?r:a,f=o>l?o>c?o:c:l>c?l:c,g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&Is(s,o,r,l,a,c,g.x,g.y)&&we(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function q_(i,t,e,n){let s=i.prev,r=i,a=i.next;if(we(s,r,a)>=0)return!1;let o=s.x,l=r.x,c=a.x,h=s.y,u=r.y,d=a.y,f=o<l?o<c?o:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,_=o>l?o>c?o:c:l>c?l:c,m=h>u?h>d?h:d:u>d?u:d,p=_h(f,g,t,e,n),v=_h(_,m,t,e,n),y=i.prevZ,x=i.nextZ;for(;y&&y.z>=p&&x&&x.z<=v;){if(y.x>=f&&y.x<=_&&y.y>=g&&y.y<=m&&y!==s&&y!==a&&Is(o,h,l,u,c,d,y.x,y.y)&&we(y.prev,y,y.next)>=0||(y=y.prevZ,x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==a&&Is(o,h,l,u,c,d,x.x,x.y)&&we(x.prev,x,x.next)>=0))return!1;x=x.nextZ}for(;y&&y.z>=p;){if(y.x>=f&&y.x<=_&&y.y>=g&&y.y<=m&&y!==s&&y!==a&&Is(o,h,l,u,c,d,y.x,y.y)&&we(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;x&&x.z<=v;){if(x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==a&&Is(o,h,l,u,c,d,x.x,x.y)&&we(x.prev,x,x.next)>=0)return!1;x=x.nextZ}return!0}function Y_(i,t,e){let n=i;do{let s=n.prev,r=n.next.next;!ko(s,r)&&df(s,n,n.next,r)&&Or(s,r)&&Or(r,s)&&(t.push(s.i/e|0),t.push(n.i/e|0),t.push(r.i/e|0),Fr(n),Fr(n.next),n=i=r),n=n.next}while(n!==i);return Ji(n)}function Z_(i,t,e,n,s,r){let a=i;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&sv(a,o)){let l=ff(a,o);a=Ji(a,a.next),l=Ji(l,l.next),Nr(a,t,e,n,s,r,0),Nr(l,t,e,n,s,r,0);return}o=o.next}a=a.next}while(a!==i)}function J_(i,t,e,n){let s=[],r,a,o,l,c;for(r=0,a=t.length;r<a;r++)o=t[r]*n,l=r<a-1?t[r+1]*n:i.length,c=uf(i,o,l,n,!1),c===c.next&&(c.steiner=!0),s.push(iv(c));for(s.sort(j_),r=0;r<s.length;r++)e=K_(s[r],e);return e}function j_(i,t){return i.x-t.x}function K_(i,t){let e=Q_(i,t);if(!e)return t;let n=ff(e,i);return Ji(n,n.next),Ji(e,e.next)}function Q_(i,t){let e=t,n=-1/0,s,r=i.x,a=i.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let d=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(d<=r&&d>n&&(n=d,s=e.x<e.next.x?e:e.next,d===r))return s}e=e.next}while(e!==t);if(!s)return null;let o=s,l=s.x,c=s.y,h=1/0,u;e=s;do r>=e.x&&e.x>=l&&r!==e.x&&Is(a<c?r:n,a,l,c,a<c?n:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),Or(e,i)&&(u<h||u===h&&(e.x>s.x||e.x===s.x&&tv(s,e)))&&(s=e,h=u)),e=e.next;while(e!==o);return s}function tv(i,t){return we(i.prev,i,t.prev)<0&&we(t.next,i,i.next)<0}function ev(i,t,e,n){let s=i;do s.z===0&&(s.z=_h(s.x,s.y,t,e,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,nv(s)}function nv(i){let t,e,n,s,r,a,o,l,c=1;do{for(e=i,i=null,r=null,a=0;e;){for(a++,n=e,o=0,t=0;t<c&&(o++,n=n.nextZ,!!n);t++);for(l=c;o>0||l>0&&n;)o!==0&&(l===0||!n||e.z<=n.z)?(s=e,e=e.nextZ,o--):(s=n,n=n.nextZ,l--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;e=n}r.nextZ=null,c*=2}while(a>1);return i}function _h(i,t,e,n,s){return i=(i-e)*s|0,t=(t-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,i|t<<1}function iv(i){let t=i,e=i;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==i);return e}function Is(i,t,e,n,s,r,a,o){return(s-a)*(t-o)>=(i-a)*(r-o)&&(i-a)*(n-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(s-a)*(n-o)}function sv(i,t){return i.next.i!==t.i&&i.prev.i!==t.i&&!rv(i,t)&&(Or(i,t)&&Or(t,i)&&av(i,t)&&(we(i.prev,i,t.prev)||we(i,t.prev,t))||ko(i,t)&&we(i.prev,i,i.next)>0&&we(t.prev,t,t.next)>0)}function we(i,t,e){return(t.y-i.y)*(e.x-t.x)-(t.x-i.x)*(e.y-t.y)}function ko(i,t){return i.x===t.x&&i.y===t.y}function df(i,t,e,n){let s=Wa(we(i,t,e)),r=Wa(we(i,t,n)),a=Wa(we(e,n,i)),o=Wa(we(e,n,t));return!!(s!==r&&a!==o||s===0&&Ga(i,e,t)||r===0&&Ga(i,n,t)||a===0&&Ga(e,i,n)||o===0&&Ga(e,t,n))}function Ga(i,t,e){return t.x<=Math.max(i.x,e.x)&&t.x>=Math.min(i.x,e.x)&&t.y<=Math.max(i.y,e.y)&&t.y>=Math.min(i.y,e.y)}function Wa(i){return i>0?1:i<0?-1:0}function rv(i,t){let e=i;do{if(e.i!==i.i&&e.next.i!==i.i&&e.i!==t.i&&e.next.i!==t.i&&df(e,e.next,i,t))return!0;e=e.next}while(e!==i);return!1}function Or(i,t){return we(i.prev,i,i.next)<0?we(i,t,i.next)>=0&&we(i,i.prev,t)>=0:we(i,t,i.prev)<0||we(i,i.next,t)<0}function av(i,t){let e=i,n=!1,s=(i.x+t.x)/2,r=(i.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==i);return n}function ff(i,t){let e=new vh(i.i,i.x,i.y),n=new vh(t.i,t.x,t.y),s=i.next,r=t.prev;return i.next=t,t.prev=i,e.next=s,s.prev=e,n.next=e,e.prev=n,r.next=n,n.prev=r,n}function Ud(i,t,e,n){let s=new vh(i,t,e);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function Fr(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function vh(i,t,e){this.i=i,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function ov(i,t,e,n){let s=0;for(let r=t,a=e-n;r<e;r+=n)s+=(i[a]-i[r])*(i[r+1]+i[a+1]),a=r;return s}var bi=class i{static area(t){let e=t.length,n=0;for(let s=e-1,r=0;r<e;s=r++)n+=t[s].x*t[r].y-t[r].x*t[s].y;return n*.5}static isClockWise(t){return i.area(t)<0}static triangulateShape(t,e){let n=[],s=[],r=[];Nd(t),Od(n,t);let a=t.length;e.forEach(Nd);for(let l=0;l<e.length;l++)s.push(a),a+=e[l].length,Od(n,e[l]);let o=$_.triangulate(n,s);for(let l=0;l<o.length;l+=3)r.push(o.slice(l,l+3));return r}};function Nd(i){let t=i.length;t>2&&i[t-1].equals(i[0])&&i.pop()}function Od(i,t){for(let e=0;e<t.length;e++)i.push(t[e].x),i.push(t[e].y)}var Br=class i extends Re{constructor(t=new Ei([new st(.5,.5),new st(-.5,.5),new st(-.5,-.5),new st(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let n=this,s=[],r=[];for(let o=0,l=t.length;o<l;o++){let c=t[o];a(c)}this.setAttribute("position",new re(s,3)),this.setAttribute("uv",new re(r,2)),this.computeVertexNormals();function a(o){let l=[],c=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,d=e.bevelEnabled!==void 0?e.bevelEnabled:!0,f=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:f-.1,_=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3,p=e.extrudePath,v=e.UVGenerator!==void 0?e.UVGenerator:lv,y,x=!1,D,T,R,L;p&&(y=p.getSpacedPoints(h),x=!0,d=!1,D=p.computeFrenetFrames(h,!1),T=new P,R=new P,L=new P),d||(m=0,f=0,g=0,_=0);let w=o.extractPoints(c),M=w.shape,I=w.holes;if(!bi.isClockWise(M)){M=M.reverse();for(let tt=0,ot=I.length;tt<ot;tt++){let C=I[tt];bi.isClockWise(C)&&(I[tt]=C.reverse())}}let z=bi.triangulateShape(M,I),W=M;for(let tt=0,ot=I.length;tt<ot;tt++){let C=I[tt];M=M.concat(C)}function K(tt,ot,C){return ot||console.error("THREE.ExtrudeGeometry: vec does not exist"),tt.clone().addScaledVector(ot,C)}let $=M.length,at=z.length;function X(tt,ot,C){let Dt,it,St,dt=tt.x-ot.x,Nt=tt.y-ot.y,bt=C.x-tt.x,E=C.y-tt.y,b=dt*dt+Nt*Nt,B=dt*E-Nt*bt;if(Math.abs(B)>Number.EPSILON){let Y=Math.sqrt(b),et=Math.sqrt(bt*bt+E*E),Z=ot.x-Nt/Y,Ct=ot.y+dt/Y,mt=C.x-E/et,Mt=C.y+bt/et,Kt=((mt-Z)*E-(Mt-Ct)*bt)/(dt*E-Nt*bt);Dt=Z+dt*Kt-tt.x,it=Ct+Nt*Kt-tt.y;let rt=Dt*Dt+it*it;if(rt<=2)return new st(Dt,it);St=Math.sqrt(rt/2)}else{let Y=!1;dt>Number.EPSILON?bt>Number.EPSILON&&(Y=!0):dt<-Number.EPSILON?bt<-Number.EPSILON&&(Y=!0):Math.sign(Nt)===Math.sign(E)&&(Y=!0),Y?(Dt=-Nt,it=dt,St=Math.sqrt(b)):(Dt=dt,it=Nt,St=Math.sqrt(b/2))}return new st(Dt/St,it/St)}let ft=[];for(let tt=0,ot=W.length,C=ot-1,Dt=tt+1;tt<ot;tt++,C++,Dt++)C===ot&&(C=0),Dt===ot&&(Dt=0),ft[tt]=X(W[tt],W[C],W[Dt]);let yt=[],At,Gt=ft.concat();for(let tt=0,ot=I.length;tt<ot;tt++){let C=I[tt];At=[];for(let Dt=0,it=C.length,St=it-1,dt=Dt+1;Dt<it;Dt++,St++,dt++)St===it&&(St=0),dt===it&&(dt=0),At[Dt]=X(C[Dt],C[St],C[dt]);yt.push(At),Gt=Gt.concat(At)}for(let tt=0;tt<m;tt++){let ot=tt/m,C=f*Math.cos(ot*Math.PI/2),Dt=g*Math.sin(ot*Math.PI/2)+_;for(let it=0,St=W.length;it<St;it++){let dt=K(W[it],ft[it],Dt);ut(dt.x,dt.y,-C)}for(let it=0,St=I.length;it<St;it++){let dt=I[it];At=yt[it];for(let Nt=0,bt=dt.length;Nt<bt;Nt++){let E=K(dt[Nt],At[Nt],Dt);ut(E.x,E.y,-C)}}}let ae=g+_;for(let tt=0;tt<$;tt++){let ot=d?K(M[tt],Gt[tt],ae):M[tt];x?(R.copy(D.normals[0]).multiplyScalar(ot.x),T.copy(D.binormals[0]).multiplyScalar(ot.y),L.copy(y[0]).add(R).add(T),ut(L.x,L.y,L.z)):ut(ot.x,ot.y,0)}for(let tt=1;tt<=h;tt++)for(let ot=0;ot<$;ot++){let C=d?K(M[ot],Gt[ot],ae):M[ot];x?(R.copy(D.normals[tt]).multiplyScalar(C.x),T.copy(D.binormals[tt]).multiplyScalar(C.y),L.copy(y[tt]).add(R).add(T),ut(L.x,L.y,L.z)):ut(C.x,C.y,u/h*tt)}for(let tt=m-1;tt>=0;tt--){let ot=tt/m,C=f*Math.cos(ot*Math.PI/2),Dt=g*Math.sin(ot*Math.PI/2)+_;for(let it=0,St=W.length;it<St;it++){let dt=K(W[it],ft[it],Dt);ut(dt.x,dt.y,u+C)}for(let it=0,St=I.length;it<St;it++){let dt=I[it];At=yt[it];for(let Nt=0,bt=dt.length;Nt<bt;Nt++){let E=K(dt[Nt],At[Nt],Dt);x?ut(E.x,E.y+y[h-1].y,y[h-1].x+C):ut(E.x,E.y,u+C)}}}J(),lt();function J(){let tt=s.length/3;if(d){let ot=0,C=$*ot;for(let Dt=0;Dt<at;Dt++){let it=z[Dt];Ut(it[2]+C,it[1]+C,it[0]+C)}ot=h+m*2,C=$*ot;for(let Dt=0;Dt<at;Dt++){let it=z[Dt];Ut(it[0]+C,it[1]+C,it[2]+C)}}else{for(let ot=0;ot<at;ot++){let C=z[ot];Ut(C[2],C[1],C[0])}for(let ot=0;ot<at;ot++){let C=z[ot];Ut(C[0]+$*h,C[1]+$*h,C[2]+$*h)}}n.addGroup(tt,s.length/3-tt,0)}function lt(){let tt=s.length/3,ot=0;Rt(W,ot),ot+=W.length;for(let C=0,Dt=I.length;C<Dt;C++){let it=I[C];Rt(it,ot),ot+=it.length}n.addGroup(tt,s.length/3-tt,1)}function Rt(tt,ot){let C=tt.length;for(;--C>=0;){let Dt=C,it=C-1;it<0&&(it=tt.length-1);for(let St=0,dt=h+m*2;St<dt;St++){let Nt=$*St,bt=$*(St+1),E=ot+Dt+Nt,b=ot+it+Nt,B=ot+it+bt,Y=ot+Dt+bt;zt(E,b,B,Y)}}}function ut(tt,ot,C){l.push(tt),l.push(ot),l.push(C)}function Ut(tt,ot,C){Ft(tt),Ft(ot),Ft(C);let Dt=s.length/3,it=v.generateTopUV(n,s,Dt-3,Dt-2,Dt-1);ee(it[0]),ee(it[1]),ee(it[2])}function zt(tt,ot,C,Dt){Ft(tt),Ft(ot),Ft(Dt),Ft(ot),Ft(C),Ft(Dt);let it=s.length/3,St=v.generateSideWallUV(n,s,it-6,it-3,it-2,it-1);ee(St[0]),ee(St[1]),ee(St[3]),ee(St[1]),ee(St[2]),ee(St[3])}function Ft(tt){s.push(l[tt*3+0]),s.push(l[tt*3+1]),s.push(l[tt*3+2])}function ee(tt){r.push(tt.x),r.push(tt.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return cv(e,n,t)}static fromJSON(t,e){let n=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];n.push(o)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new mh[s.type]().fromJSON(s)),new i(n,t.options)}},lv={generateTopUV:function(i,t,e,n,s){let r=t[e*3],a=t[e*3+1],o=t[n*3],l=t[n*3+1],c=t[s*3],h=t[s*3+1];return[new st(r,a),new st(o,l),new st(c,h)]},generateSideWallUV:function(i,t,e,n,s,r){let a=t[e*3],o=t[e*3+1],l=t[e*3+2],c=t[n*3],h=t[n*3+1],u=t[n*3+2],d=t[s*3],f=t[s*3+1],g=t[s*3+2],_=t[r*3],m=t[r*3+1],p=t[r*3+2];return Math.abs(o-h)<Math.abs(a-c)?[new st(a,1-l),new st(c,1-u),new st(d,1-g),new st(_,1-p)]:[new st(o,1-l),new st(h,1-u),new st(f,1-g),new st(m,1-p)]}};function cv(i,t,e){if(e.shapes=[],Array.isArray(i))for(let n=0,s=i.length;n<s;n++){let r=i[n];e.shapes.push(r.uuid)}else e.shapes.push(i.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var To=class i extends Ur{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}},$s=class i extends Ur{constructor(t=1,e=0){let n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new i(t.radius,t.detail)}};var Ao=class i extends Re{constructor(t=new Ei([new st(0,.5),new st(-.5,-.5),new st(.5,-.5)]),e=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};let n=[],s=[],r=[],a=[],o=0,l=0;if(Array.isArray(t)===!1)c(t);else for(let h=0;h<t.length;h++)c(t[h]),this.addGroup(o,l,h),o+=l,l=0;this.setIndex(n),this.setAttribute("position",new re(s,3)),this.setAttribute("normal",new re(r,3)),this.setAttribute("uv",new re(a,2));function c(h){let u=s.length/3,d=h.extractPoints(e),f=d.shape,g=d.holes;bi.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,p=g.length;m<p;m++){let v=g[m];bi.isClockWise(v)===!0&&(g[m]=v.reverse())}let _=bi.triangulateShape(f,g);for(let m=0,p=g.length;m<p;m++){let v=g[m];f=f.concat(v)}for(let m=0,p=f.length;m<p;m++){let v=f[m];s.push(v.x,v.y,0),r.push(0,0,1),a.push(v.x,v.y)}for(let m=0,p=_.length;m<p;m++){let v=_[m],y=v[0]+u,x=v[1]+u,D=v[2]+u;n.push(y,x,D),l+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes;return hv(e,t)}static fromJSON(t,e){let n=[];for(let s=0,r=t.shapes.length;s<r;s++){let a=e[t.shapes[s]];n.push(a)}return new i(n,t.curveSegments)}};function hv(i,t){if(t.shapes=[],Array.isArray(i))for(let e=0,n=i.length;e<n;e++){let s=i[e];t.shapes.push(s.uuid)}else t.shapes.push(i.uuid);return t}var _n=class i extends Re{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new P,d=new P,f=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){let v=[],y=p/n,x=0;p===0&&a===0?x=.5/e:p===n&&l===Math.PI&&(x=-.5/e);for(let D=0;D<=e;D++){let T=D/e;u.x=-t*Math.cos(s+T*r)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(s+T*r)*Math.sin(a+y*o),g.push(u.x,u.y,u.z),d.copy(u).normalize(),_.push(d.x,d.y,d.z),m.push(T+x,1-y),v.push(c++)}h.push(v)}for(let p=0;p<n;p++)for(let v=0;v<e;v++){let y=h[p][v+1],x=h[p][v],D=h[p+1][v],T=h[p+1][v+1];(p!==0||a>0)&&f.push(y,x,T),(p!==n-1||l<Math.PI)&&f.push(x,D,T)}this.setIndex(f),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(_,3)),this.setAttribute("uv",new re(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var ji=class i extends Re{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);let a=[],o=[],l=[],c=[],h=new P,u=new P,d=new P;for(let f=0;f<=n;f++)for(let g=0;g<=s;g++){let _=g/s*r,m=f/n*Math.PI*2;u.x=(t+e*Math.cos(m))*Math.cos(_),u.y=(t+e*Math.cos(m))*Math.sin(_),u.z=e*Math.sin(m),o.push(u.x,u.y,u.z),h.x=t*Math.cos(_),h.y=t*Math.sin(_),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=s;g++){let _=(s+1)*f+g-1,m=(s+1)*(f-1)+g-1,p=(s+1)*(f-1)+g,v=(s+1)*f+g;a.push(_,m,v),a.push(m,p,v)}this.setIndex(a),this.setAttribute("position",new re(o,3)),this.setAttribute("normal",new re(l,3)),this.setAttribute("uv",new re(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var Ro=class extends si{static get type(){return"MeshLambertMaterial"}constructor(t){super(),this.isMeshLambertMaterial=!0,this.color=new Wt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Wt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=jd,this.normalScale=new st(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new mn,this.combine=kh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function $a(i,t,e){return!i||!e&&i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function uv(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}var Xs=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=s,s=e[++n],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}a=n,n=0;break e}break n}for(;n<a;){let o=n+a>>>1;t<e[o]?a=o:n=o+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=n[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},yh=class extends Xs{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Lu,endingEnd:Lu}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],l=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case Du:r=t,o=2*e-n;break;case ku:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Du:a=t,l=2*n-e;break;case ku:a=1,l=n+s[1]-s[0];break;default:a=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-o),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-e)/(s-e),_=g*g,m=_*g,p=-d*m+2*d*_-d*g,v=(1+d)*m+(-1.5-2*d)*_+(-.5+d)*g+1,y=(-1-f)*m+(1.5+f)*_+.5*g,x=f*m-f*_;for(let D=0;D!==o;++D)r[D]=p*a[h+D]+v*a[c+D]+y*a[l+D]+x*a[u+D];return r}},bh=class extends Xs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=(n-e)/(s-e),u=1-h;for(let d=0;d!==o;++d)r[d]=a[c+d]*u+a[l+d]*h;return r}},Mh=class extends Xs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},Ln=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=$a(e,this.TimeBufferType),this.values=$a(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:$a(t.times,Array),values:$a(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Mh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new bh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new yh(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ja:e=this.InterpolantFactoryMethodDiscrete;break;case Gc:e=this.InterpolantFactoryMethodLinear;break;case Al:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ja;case this.InterpolantFactoryMethodLinear:return Gc;case this.InterpolantFactoryMethodSmooth:return Al}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t}return this}trim(t,e){let n=this.times,s=n.length,r=0,a=s-1;for(;r!==s&&n[r]<t;)++r;for(;a!==-1&&n[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),t=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),t=!1;break}a=l}if(s!==void 0&&uv(s))for(let o=0,l=s.length;o!==l;++o){let c=s[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===Al,r=t.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=t[o],h=t[o+1];if(c!==h&&(o!==1||c!==t[0]))if(s)l=!0;else{let u=o*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){let _=e[u+g];if(_!==e[d+g]||_!==e[f+g]){l=!0;break}}}if(l){if(o!==a){t[a]=t[o];let u=o*n,d=a*n;for(let f=0;f!==n;++f)e[d+f]=e[u+f]}++a}}if(r>0){t[a]=t[r];for(let o=r*n,l=a*n,c=0;c!==n;++c)e[l+c]=e[o+c];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};Ln.prototype.TimeBufferType=Float32Array;Ln.prototype.ValueBufferType=Float32Array;Ln.prototype.DefaultInterpolation=Gc;var Ki=class extends Ln{constructor(t,e,n){super(t,e,n)}};Ki.prototype.ValueTypeName="bool";Ki.prototype.ValueBufferType=Array;Ki.prototype.DefaultInterpolation=ja;Ki.prototype.InterpolantFactoryMethodLinear=void 0;Ki.prototype.InterpolantFactoryMethodSmooth=void 0;var Sh=class extends Ln{};Sh.prototype.ValueTypeName="color";var wh=class extends Ln{};wh.prototype.ValueTypeName="number";var Eh=class extends Xs{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-e)/(s-e),c=t*o;for(let h=c+o;c!==h;c+=4)Bn.slerpFlat(r,0,a,c-o,a,c,l);return r}},Co=class extends Ln{InterpolantFactoryMethodLinear(t){return new Eh(this.times,this.values,this.getValueSize(),t)}};Co.prototype.ValueTypeName="quaternion";Co.prototype.InterpolantFactoryMethodSmooth=void 0;var Qi=class extends Ln{constructor(t,e,n){super(t,e,n)}};Qi.prototype.ValueTypeName="string";Qi.prototype.ValueBufferType=Array;Qi.prototype.DefaultInterpolation=ja;Qi.prototype.InterpolantFactoryMethodLinear=void 0;Qi.prototype.InterpolantFactoryMethodSmooth=void 0;var Th=class extends Ln{};Th.prototype.ValueTypeName="vector";var Ah=class{constructor(t,e,n){let s=this,r=!1,a=0,o=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){o++,r===!1&&s.onStart!==void 0&&s.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,s.onProgress!==void 0&&s.onProgress(h,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}},dv=new Ah,Rh=class{constructor(t){this.manager=t!==void 0?t:dv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Rh.DEFAULT_MATERIAL_NAME="__DEFAULT";var Po=class extends ze{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Wt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},zr=class extends Po{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ze.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Wt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},sc=new ue,Fd=new P,Bd=new P,Ch=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new st(512,512),this.map=null,this.mapPass=null,this.matrix=new ue,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Cr,this._frameExtents=new st(1,1),this._viewportCount=1,this._viewports=[new Te(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;Fd.setFromMatrixPosition(t.matrixWorld),e.position.copy(Fd),Bd.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Bd),e.updateMatrixWorld(),sc.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(sc),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(sc)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Ph=class extends Ch{constructor(){super(new lo(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Hr=class extends Po{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ze.DEFAULT_UP),this.updateMatrix(),this.target=new ze,this.shadow=new Ph}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var $h="\\[\\]\\.:\\/",fv=new RegExp("["+$h+"]","g"),Xh="[^"+$h+"]",pv="[^"+$h.replace("\\.","")+"]",mv=/((?:WC+[\/:])*)/.source.replace("WC",Xh),gv=/(WCOD+)?/.source.replace("WCOD",pv),xv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Xh),_v=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Xh),vv=new RegExp("^"+mv+gv+xv+_v+"$"),yv=["material","materials","bones","map"],Ih=class{constructor(t,e,n){let s=n||be.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},be=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(fv,"")}static parseTrackName(t){let e=vv.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);yv.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let l=n(o.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let a=t[s];if(a===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};be.Composite=Ih;be.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};be.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};be.prototype.GetterByBindingType=[be.prototype._getValue_direct,be.prototype._getValue_array,be.prototype._getValue_arrayElement,be.prototype._getValue_toArray];be.prototype.SetterByBindingTypeAndVersioning=[[be.prototype._setValue_direct,be.prototype._setValue_direct_setNeedsUpdate,be.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[be.prototype._setValue_array,be.prototype._setValue_array_setNeedsUpdate,be.prototype._setValue_array_setMatrixWorldNeedsUpdate],[be.prototype._setValue_arrayElement,be.prototype._setValue_arrayElement_setNeedsUpdate,be.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[be.prototype._setValue_fromArray,be.prototype._setValue_fromArray_setNeedsUpdate,be.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Vv=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Lh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Lh);var Gr=new P;function vn(i,t,e,n,s,r){let a=2*Math.PI*s/4,o=Math.max(r-2*s,0),l=Math.PI/4;Gr.copy(t),Gr[n]=0,Gr.normalize();let c=.5*a/(a+o),h=1-Gr.angleTo(i)/l;return Math.sign(Gr[e])===1?h*c:o/(a+o)+c+c*(1-h)}var Uo=class extends ri{constructor(t=1,e=1,n=1,s=2,r=.1){if(s=s*2+1,r=Math.min(t/2,e/2,n/2,r),super(1,1,1,s,s,s),s===1)return;let a=this.toNonIndexed();this.index=null,this.attributes.position=a.attributes.position,this.attributes.normal=a.attributes.normal,this.attributes.uv=a.attributes.uv;let o=new P,l=new P,c=new P(t,e,n).divideScalar(2).subScalar(r),h=this.attributes.position.array,u=this.attributes.normal.array,d=this.attributes.uv.array,f=h.length/6,g=new P,_=.5/s;for(let m=0,p=0;m<h.length;m+=3,p+=2)switch(o.fromArray(h,m),l.copy(o),l.x-=Math.sign(l.x)*_,l.y-=Math.sign(l.y)*_,l.z-=Math.sign(l.z)*_,l.normalize(),h[m+0]=c.x*Math.sign(o.x)+l.x*r,h[m+1]=c.y*Math.sign(o.y)+l.y*r,h[m+2]=c.z*Math.sign(o.z)+l.z*r,u[m+0]=l.x,u[m+1]=l.y,u[m+2]=l.z,Math.floor(m/f)){case 0:g.set(1,0,0),d[p+0]=vn(g,l,"z","y",r,n),d[p+1]=1-vn(g,l,"y","z",r,e);break;case 1:g.set(-1,0,0),d[p+0]=1-vn(g,l,"z","y",r,n),d[p+1]=1-vn(g,l,"y","z",r,e);break;case 2:g.set(0,1,0),d[p+0]=1-vn(g,l,"x","z",r,t),d[p+1]=vn(g,l,"z","x",r,n);break;case 3:g.set(0,-1,0),d[p+0]=1-vn(g,l,"x","z",r,t),d[p+1]=1-vn(g,l,"z","x",r,n);break;case 4:g.set(0,0,1),d[p+0]=1-vn(g,l,"x","y",r,t),d[p+1]=1-vn(g,l,"y","x",r,e);break;case 5:g.set(0,0,-1),d[p+0]=vn(g,l,"x","y",r,t),d[p+1]=1-vn(g,l,"y","x",r,e);break}}};var pf=new Map,Fo=new Map,mf=new Map;function Ae(i,t){let e=pf.get(i);return e||(e=t(),pf.set(i,e)),e}function xf(i){return Object.keys(i).map(t=>t+":"+(i[t]&&i[t].isTexture?i[t].uuid:i[t])).join(",")}function U(i,t={}){let e=i+"|"+xf(t),n=Fo.get(e);return n||(n=new Ro({color:i}),t.emissive!==void 0&&(n.emissive=new Wt(t.emissive),n.emissiveIntensity=t.ei??1),t.opacity!==void 0&&(n.transparent=!0,n.opacity=t.opacity,n.depthWrite=t.opacity>.9),t.side&&(n.side=pn),t.flat&&(n.flatShading=!0),t.map&&(n.map=t.map),t.fog===!1&&(n.fog=!1),Fo.set(e,n)),n}function He(i,t={}){let e="B"+i+"|"+xf(t),n=Fo.get(e);return n||(n=new Vs({color:i,transparent:t.opacity!==void 0,opacity:t.opacity??1,depthWrite:t.opacity===void 0}),t.side&&(n.side=pn),t.blend&&(n.blending=Ns),t.map&&(n.map=t.map),t.fog===!1&&(n.fog=!1),Fo.set(e,n)),n}var de=i=>U(i,{emissive:i,ei:1});function A(i,t,e=0,n=0,s=0,r=null){let a=new Me(i,t);return a.position.set(e,n,s),r&&r.add(a),a}var j=(i,t,e)=>Ae(`box${i},${t},${e}`,()=>new ri(i,t,e)),Oe=(i,t,e,n)=>Ae(`rbox${i},${t},${e},${n}`,()=>new Uo(i,t,e,3,n)),Vt=(i,t,e,n=12)=>Ae(`cyl${i},${t},${e},${n}`,()=>new Zi(i,t,e,n)),ie=(i,t=14,e=10)=>Ae(`sph${i},${t},${e}`,()=>new _n(i,t,e)),Xe=(i,t,e=12)=>Ae(`cone${i},${t},${e}`,()=>new wo(i,t,e)),No=(i,t)=>Ae(`caps${i},${t}`,()=>new Mo(i,t,4,10)),Bo=(i,t,e=8,n=20,s=Math.PI*2)=>Ae(`tor${i},${t},${s}`,()=>new ji(i,t,e,n,s)),zo=(i,t=0)=>Ae(`ico${i},${t}`,()=>new To(i,t)),Zh=i=>Ae(`dode${i}`,()=>new Eo(i,0)),oi=(i,t)=>Ae(`pl${i},${t}`,()=>new ai(i,t));function ts(i,t,e,n,s){let r=mf.get(i);if(r)return r;let a=document.createElement("canvas");return a.width=t,a.height=e,n(a.getContext("2d"),t,e),r=new xo(a),r.colorSpace=nn,r.anisotropy=4,s&&(r.wrapS=r.wrapT=Tr,r.repeat.set(s[0],s[1])),mf.set(i,r),r}function Oo(i="#e8382f",t="#ffffff"){return ts("stripe"+i+t,128,32,(e,n,s)=>{e.fillStyle=t,e.fillRect(0,0,n,s),e.fillStyle=i;for(let r=-s;r<n+s;r+=32)e.beginPath(),e.moveTo(r,s),e.lineTo(r+16,s),e.lineTo(r+16+s,0),e.lineTo(r+s,0),e.fill()})}function bv(i,t,e){return ts("road"+i+t,256,256,(n,s,r)=>{n.fillStyle="#"+i.toString(16).padStart(6,"0"),n.fillRect(0,0,s,r);for(let l=0;l<900;l++)n.fillStyle=`rgba(${Math.random()<.5?"0,0,0":"255,255,255"},${Math.random()*.05})`,n.fillRect(Math.random()*s,Math.random()*r,2,2);let a="#"+t.toString(16).padStart(6,"0");n.fillStyle=a,e&&(n.shadowColor=a,n.shadowBlur=8);let o=s/3;for(let l of[o,o*2])for(let c=0;c<r;c+=128)n.fillRect(l-3,c+16,6,70);n.fillRect(4,0,5,r),n.fillRect(s-9,0,5,r)},[1,1])}function Mv(i){return ts("win"+i,64,128,(t,e,n)=>{t.fillStyle=i?"#1c1638":"#d8e6f5",t.fillRect(0,0,e,n);for(let s=6;s<n-6;s+=16)for(let r=6;r<e-6;r+=14){let a=Math.random()<(i?.55:.3);t.fillStyle=i?a?["#ffe14d","#39f3ff","#ff3df2"][Math.floor(Math.random()*3)]:"#2c2550":a?"#9fd4ff":"#5a7da8",t.fillRect(r,s,8,10)}})}function Sv(){return ts("carpet",64,64,(i,t,e)=>{i.fillStyle="#b5232f",i.fillRect(0,0,t,e),i.strokeStyle="#ffd166",i.lineWidth=3,i.strokeRect(4,4,t-8,e-8),i.fillStyle="#1d6f8c",i.beginPath(),i.moveTo(t/2,12),i.lineTo(t-14,e/2),i.lineTo(t/2,e-12),i.lineTo(14,e/2),i.fill(),i.fillStyle="#ffd166",i.beginPath(),i.arc(t/2,e/2,6,0,Math.PI*2),i.fill()})}function Jh(i,t,e,n=128,s=128,r=70){return ts("txt"+i+t+e,n,s,a=>{t&&(a.fillStyle=t,a.beginPath(),a.arc(n/2,s/2,n/2-2,0,Math.PI*2),a.fill()),a.fillStyle=e,a.font=`900 ${r}px Arial`,a.textAlign="center",a.textBaseline="middle",a.fillText(i,n/2,s/2+4)})}function wv(){return ts("blob",64,64,(i,t,e)=>{let n=i.createRadialGradient(t/2,e/2,2,t/2,e/2,t/2);n.addColorStop(0,"rgba(0,0,0,0.55)"),n.addColorStop(1,"rgba(0,0,0,0)"),i.fillStyle=n,i.fillRect(0,0,t,e)})}function _f(){return ts("spark",64,64,(i,t,e)=>{let n=i.createRadialGradient(t/2,e/2,0,t/2,e/2,t/2);n.addColorStop(0,"rgba(255,255,255,1)"),n.addColorStop(.3,"rgba(255,255,255,0.7)"),n.addColorStop(1,"rgba(255,255,255,0)"),i.fillStyle=n,i.fillRect(0,0,t,e)})}function Wr(i,t={}){let e=new Qt,n=new Qt;e.add(n);let s=U(i.body),r=U(i.accent),a=U(i.visor),o=de(i.eye),l=new Qt,c=new Qt;l.position.set(-.22,.78,0),c.position.set(.22,.78,0);for(let v of[l,c]){A(No(.13,.36),r,0,-.3,0,v);let y=A(Oe(.3,.18,.44,.07),s,0,-.66,-.06,v);y.castShadow=!0,n.add(v)}let h=A(No(.4,.32),s,0,1.18,0,n);h.scale.set(1,1,.86),h.castShadow=!0,A(Oe(.5,.36,.12,.05),r,0,1.22,-.32,n),A(ie(.075,10,8),de(i.eye),0,1.24,-.39,n),A(Vt(.4,.4,.1,18),r,0,.86,0,n),A(Oe(.46,.5,.14,.06),r,0,1.2,.33,n);for(let v of[-.11,.11])A(ie(.05,8,6),de(i.eye),v,1.32,.41,n);A(j(.28,.05,.03),de(i.eye),0,1.12,.41,n);let u=new Qt,d=new Qt;u.position.set(-.53,1.45,0),d.position.set(.53,1.45,0);for(let v of[u,d])A(No(.11,.3),s,0,-.24,0,v),A(ie(.14,12,10),r,0,-.52,0,v),n.add(v);let f=new Qt;f.position.set(0,2,0),n.add(f);let g=A(Oe(.98,.8,.84,.24),s,0,0,0,f);g.castShadow=!0,A(Oe(.8,.46,.1,.08),a,0,.02,-.39,f),A(Oe(.6,.3,.08,.06),r,0,.05,.4,f);let _=[];for(let v of[-.18,.18])_.push(A(Oe(.15,.2,.05,.05),o,v,.05,-.45,f));if(A(j(.2,.04,.03),o,0,-.12,-.45,f),t.ears==="pointy")for(let v of[-.34,.34]){let y=A(Xe(.16,.36,4),r,v,.5,0,f);y.rotation.z=v>0?-.35:.35}else{for(let v of[-.51,.51]){let y=A(Vt(.14,.14,.1,14),r,v,0,0,f);y.rotation.z=Math.PI/2}A(Vt(.03,.03,.3,6),r,0,.52,0,f),A(ie(.085,10,8),de(i.accent),0,.7,0,f)}t.mask&&A(j(1,.2,.06),U(1118481),0,.06,-.47,f);let m=new Qt;m.position.set(0,1.25,.42),n.add(m);for(let v of[-.17,.17]){A(Vt(.13,.13,.5,12),r,v,0,0,m);let y=A(Xe(.11,.5,10),He(16753183,{opacity:.9,blend:!0}),v,-.5,0,m);y.rotation.x=Math.PI,y.userData.flame=!0}if(m.visible=!!t.jet,t.sack){A(ie(.48,12,10),U(10251071),.1,1.45,.55,n).scale.set(1,1.1,.9),A(Vt(.12,.2,.18,8),U(7162927),.1,1.98,.55,n);for(let y=0;y<3;y++)A(j(.22,.08,.12),U(16763196,{emissive:6702080,ei:.6}),-.05+y*.12,2.05+y*.03,.5,n)}if(t.tail){let v=new Qt;v.position.set(0,.95,.38),n.add(v);for(let y=0;y<4;y++)A(ie(.13-y*.012,8,6),y%2?U(2236962):r,0,y*.12,.12+y*.12,v);v.rotation.x=.6,e.userData.tail=v}let p=new Me(oi(1.4,1.4),He(16777215,{map:wv(),opacity:1}));return p.rotation.x=-Math.PI/2,p.position.y=.02,e.add(p),e.userData={...e.userData,rig:n,legL:l,legR:c,armL:u,armR:d,head:f,jet:m,eyes:_,shadow:p,torso:h},e}var Ev={body:7032736,accent:3811932,visor:722964,eye:16727386};function Ho(){return Wr(Ev,{ears:"pointy",mask:!0,sack:!0,tail:!0})}function Dn(i,t,e,n){let s=i.userData,r=Math.sin(e),a=Math.cos(e);s.rig.rotation.set(0,0,0),s.rig.position.set(0,0,0),s.head.rotation.set(0,0,0),t==="run"?(s.legL.rotation.x=r*.9,s.legR.rotation.x=-r*.9,s.armL.rotation.x=-r*.8,s.armR.rotation.x=r*.8,s.armL.rotation.z=-.15,s.armR.rotation.z=.15,s.rig.position.y=Math.abs(a)*.12,s.rig.rotation.x=-.12,s.head.rotation.z=r*.04):t==="jump"?(s.legL.rotation.x=.9,s.legR.rotation.x=-.3,s.armL.rotation.x=-2.4,s.armR.rotation.x=-2.4,s.armL.rotation.z=-.3,s.armR.rotation.z=.3,s.rig.rotation.x=-.2):t==="slide"?(s.rig.rotation.x=1.15,s.rig.position.y=.32,s.rig.position.z=.4,s.legL.rotation.x=-.3,s.legR.rotation.x=-.5,s.armL.rotation.x=-2.8,s.armR.rotation.x=-2.8):t==="fly"?(s.rig.rotation.x=-.35,s.legL.rotation.x=.4+r*.15,s.legR.rotation.x=.4-r*.15,s.armL.rotation.z=-1.2,s.armR.rotation.z=1.2,s.rig.position.y=Math.sin(n*4)*.1):t==="fall"?(s.rig.rotation.x=1.4,s.rig.position.y=.25,s.rig.position.z=.9,s.armL.rotation.z=-1.4,s.armR.rotation.z=1.4,s.legL.rotation.x=-.4,s.legR.rotation.x=.3):t==="wave"?(s.armR.rotation.z=2.6+Math.sin(n*8)*.35,s.armL.rotation.z=-.15,s.legL.rotation.x=0,s.legR.rotation.x=0,s.rig.position.y=Math.abs(Math.sin(n*4))*.05,s.head.rotation.z=Math.sin(n*2)*.08):(s.legL.rotation.x=0,s.legR.rotation.x=0,s.armL.rotation.x=Math.sin(n*2)*.08,s.armR.rotation.x=-Math.sin(n*2)*.08,s.armL.rotation.z=-.12,s.armR.rotation.z=.12,s.rig.position.y=Math.sin(n*2.2)*.03,s.head.rotation.y=Math.sin(n*.9)*.25),s.jet.visible&&s.jet.children.forEach(l=>{l.userData.flame&&(l.scale.y=.8+Math.random()*.6)});let o=n%3.7<.12?.15:1;s.eyes.forEach(l=>{l.scale.y=o}),i.userData.tail&&(i.userData.tail.rotation.y=Math.sin(n*6)*.4)}function vf(){let i=new Qt,t=U(5979289),e=U(2760007),n=A(Oe(2.3,2.1,4.6,.3),t,0,1.55,0,i);n.castShadow=!0,A(Oe(2.32,.9,1.6,.2),U(1708080),0,2,-1.6,i),A(j(2.34,.25,4.62),U(16763196),0,1,0,i);for(let[o,l]of[[-1.05,-1.5],[1.05,-1.5],[-1.05,1.5],[1.05,1.5]]){let c=A(Vt(.48,.48,.4,14),U(1118481),o,.5,l,i);c.rotation.z=Math.PI/2;let h=A(Vt(.22,.22,.42,10),U(12303291),o,.5,l,i);h.rotation.z=Math.PI/2}A(j(2,1.6,.06),e,0,1.6,2.32,i);let s=A(oi(1.1,1.1),He(16777215,{map:Jh("G","#ff3d5a","#ffffff")}),0,1.7,2.37,i);s.userData.logo=!0;let r=A(ie(.22,12,8),de(16719904),0,2.75,1.4,i);i.userData.light=r;let a=Ho();return a.position.set(0,2.62,.6),a.rotation.y=Math.PI,a.scale.setScalar(.9),i.add(a),i.userData.thief=a,A(j(1.4,.15,1.4),e,0,2.62,.6,i),i}function yf(){return Ae("goldbar",()=>{let i=new Ei;i.moveTo(-.3,0),i.lineTo(.3,0),i.lineTo(.22,.24),i.lineTo(-.22,.24),i.lineTo(-.3,0);let t=new Br(i,{depth:.34,bevelEnabled:!0,bevelThickness:.03,bevelSize:.03,bevelSegments:1});return t.translate(0,-.12,-.17),t})}function bf(){return U(16761370,{emissive:8014592,ei:.55})}function Mf(){let i=new Qt;return A(Ae("gem",()=>new $s(.4,0)),U(3725823,{emissive:678538,ei:.8,flat:!0}),0,0,0,i).scale.set(.8,1.15,.8),i}function Sf(i){let t=new Qt,e=new Qt;t.add(e);let n=A(ie(.75,18,14),He(16777215,{opacity:.18}),0,0,0,t);n.renderOrder=2;let s=A(Bo(.78,.05,6,28),He(16777215,{opacity:.6}),0,0,0,t);if(s.userData.ring=!0,i==="magnet"){let r=A(Bo(.3,.12,8,18,Math.PI),U(16727386),0,.05,0,e);r.rotation.z=Math.PI;for(let a of[-.3,.3])A(j(.25,.16,.25),U(14540253),a,.1,0,e)}else if(i==="shield")A(Ae("helm",()=>new _n(.4,16,10,0,Math.PI*2,0,Math.PI/2)),U(3786495),0,-.1,0,e).scale.set(1,1.1,1.1),A(j(.06,.3,.8),U(16777215),0,.2,0,e),A(j(.6,.14,.1),U(1319229),0,-.05,-.36,e);else if(i==="jet")A(No(.14,.6),U(16756768),0,0,0,e).rotation.x=Math.PI/2,A(j(1,.05,.25),U(16742912),0,0,.02,e),A(j(.4,.05,.15),U(16742912),0,0,.36,e),A(j(.05,.22,.15),U(16742912),0,.1,.36,e),A(ie(.1,8,6),U(3786495),0,.08,-.22,e),e.rotation.y=.6;else if(i==="double"){let r=A(Vt(.42,.42,.12,24),U(10181887),0,0,0,e);r.rotation.x=Math.PI/2;let a=A(oi(.7,.7),He(16777215,{map:Jh("x2",null,"#ffffff")}),0,0,-.07,e);a.rotation.y=Math.PI,A(oi(.7,.7),He(16777215,{map:Jh("x2",null,"#ffffff")}),0,0,.07,e)}else if(i==="vault"){A(Oe(.7,.62,.6,.06),U(10134706),0,0,0,e);let r=A(Vt(.16,.16,.06,16),U(4937059),0,0,-.32,e);r.rotation.x=Math.PI/2,A(j(.05,.2,.02),U(16763196),0,0,-.36,e),n.visible=!1}return t.userData.inner=e,t}function $r(i){let t=new Qt,e=i==="emp"?3123455:14690344;A(ie(.5,16,12),U(e,{emissive:e,ei:.35}),0,.5,0,t),A(Vt(.12,.12,.2,8),U(3355443),0,1.05,0,t);let n=A(ie(.1,8,6),He(i==="emp"?10286591:16769357,{blend:!0,opacity:1}),0,1.2,0,t);if(t.userData.spark=n,i==="emp"){let s=A(Bo(.62,.05,6,24),He(10286591,{opacity:.8,blend:!0}),0,.5,0,t);s.rotation.x=Math.PI/2,t.userData.ring=s}return t}function yn(i,t=Math.random){return i[Math.floor(t()*i.length)]}function Yh(i,t,e,n=.4,s=.4){for(let r of t)for(let a of e){let o=A(Vt(n,n,.32,14),U(1776411),r,s,a,i);o.rotation.z=Math.PI/2}}function wf(i,t,e={}){let n=new Qt,s=t.palette,r=t.night;switch(i){case"barrier":{for(let o of[-.85,.85])A(j(.12,.95,.12),U(14540253),o,.47,0,n);let a=A(j(2,.42,.12),U(16777215,{map:Oo()}),0,.72,0,n);a.castShadow=!0,A(j(2,.08,.5),U(10066329),0,.04,0,n);for(let o of[-.85,.85])A(ie(.08,8,6),de(16752640),o,1,0,n);break}case"neonBarrier":{A(j(2,.85,.3),U(1906744),0,.42,0,n),A(j(2.04,.1,.32),de(3798015),0,.82,0,n),A(j(2.04,.1,.32),de(16727538),0,.15,0,n);break}case"crate":{let a=A(j(1.9,.92,.95),U(13208380),0,.46,0,n);a.castShadow=!0;for(let o of[.1,.82])A(j(1.94,.1,.99),U(9067051),0,o,0,n);A(j(.12,.92,.99),U(9067051),0,.46,0,n);break}case"log":{let a=A(Vt(.46,.46,2.1,14),U(8015658),0,.46,0,n);a.rotation.z=Math.PI/2,a.castShadow=!0;for(let o of[-1.06,1.06]){let l=A(Vt(.4,.4,.02,14),U(14267004),o,.46,0,n);l.rotation.z=Math.PI/2}A(ie(.16,8,6),U(5025616),.4,.9,0,n);break}case"iceBlock":{let a=A(Oe(1.9,.92,.9,.1),U(10476799,{opacity:.85}),0,.46,0,n);a.castShadow=!0,A(j(1.6,.06,.6),U(16777215),0,.95,0,n);break}case"sandbags":{for(let a=0;a<3;a++)A(ie(.42,10,8),U(14268282),-.66+a*.66,.3,0,n).scale.set(1,.65,.9);for(let a=0;a<2;a++)A(ie(.42,10,8),U(13280360),-.33+a*.66,.72,0,n).scale.set(1,.6,.9);break}case"gantry":{for(let o of[-1.05,1.05])A(j(.14,2.6,.14),U(5592405),o,1.3,0,n);let a=A(j(2.2,.85,.15),U(16777215,{map:Oo("#1b1b1b","#ffcc00")}),0,1.9,0,n);a.castShadow=!0,A(Ae("warn",()=>new So(.28,3)),U(16777215),0,1.9,-.09,n).rotation.set(0,Math.PI,Math.PI/2*0);break}case"holoGate":{for(let a of[-1.05,1.05])A(j(.16,2.6,.16),U(2827600),a,1.3,0,n);A(j(2.1,.9,.06),U(16727538,{emissive:16727538,ei:.8,opacity:.75}),0,1.9,0,n),A(j(2.2,.08,.1),de(3798015),0,1.42,0,n);break}case"bambooBar":{for(let a of[-1.05,1.05])A(Vt(.08,.08,2.6,8),U(10124090),a,1.3,0,n);for(let a of[1.55,1.8,2.05]){let o=A(Vt(.1,.1,2.2,8),U(13153370),0,a,0,n);o.rotation.z=Math.PI/2}A(j(1.2,.5,.05),U(16740193),0,2.45,0,n);break}case"branch":{for(let o of[-1.15,1.15])A(Zh(.45),U(9276813,{flat:!0}),o,.4,0,n);let a=A(Vt(.3,.34,2.8,10),U(7162945),0,1.75,0,n);a.rotation.z=Math.PI/2;for(let o of[-.8,.1,.9])A(zo(.42,0),U(5025616,{flat:!0}),o,2.15,0,n);for(let o of[-1.15,1.15])A(Vt(.18,.22,1.4,8),U(7162945),o,1.1,0,n);break}case"icicleArch":{for(let a of[-1.1,1.1])A(j(.3,2.6,.5),U(13627391),a,1.3,0,n);A(j(2.5,.55,.6),U(13627391,{opacity:.9}),0,2.15,0,n);for(let a=0;a<6;a++){let o=A(Xe(.1,.5,6),U(15268095,{opacity:.9}),-.8+a*.32,1.65,0,n);o.rotation.x=Math.PI}break}case"carpetArch":{for(let a of[-1.05,1.05])A(Vt(.09,.09,2.7,8),U(9198123),a,1.35,0,n);A(Vt(.06,.06,2.3,8),U(9198123),0,2.6,0,n).rotation.z=Math.PI/2,A(oi(2,1.15),U(16777215,{map:Sv(),side:!0}),0,2,0,n);for(let a of[-.7,0,.7])A(ie(.1,8,6),de(16765286),a,1.38,0,n);break}case"van":{let a=e.color??yn(s),o=A(Oe(2,1.8,3.8,.22),U(a),0,1.35,0,n);o.castShadow=!0,A(Oe(2.02,.7,1,.15),U(2241348),0,1.75,-1.55,n),A(j(2.04,.12,3.84),U(16777215),0,.85,0,n),Yh(n,[-.92,.92],[-1.25,1.25]);for(let l of[-.7,.7])A(j(.3,.16,.05),de(16774848),l,.95,-1.92,n);break}case"hoverCar":{let a=e.color??yn(s),o=A(Oe(2,1.4,3.6,.4),U(2827600),0,1.35,0,n);o.castShadow=!0,A(Oe(1.7,.6,1.6,.25),U(3798015,{emissive:674389,ei:1,opacity:.85}),0,2.1,.1,n),A(j(2.1,.1,3.7),de(a),0,.62,0,n),A(j(1.8,.05,3.4),He(a,{opacity:.5,blend:!0}),0,.1,0,n);break}case"hut":{let a=A(j(1.9,1.6,2.2),U(14727288),0,.8,0,n);a.castShadow=!0;let o=A(Xe(1.75,1.1,4),U(11569722,{flat:!0}),0,2.15,0,n);o.rotation.y=Math.PI/4,A(j(1,.9,.05),U(3065014),0,.9,-1.12,n);break}case"boulder":{let a=A(Zh(1.15),U(9080726,{flat:!0}),0,1.05,0,n);a.scale.set(.95,1.05,1.3),a.castShadow=!0,A(zo(.3,0),U(5025616,{flat:!0}),.5,2,0,n);break}case"snowman":{A(ie(.85,14,10),U(16777215),0,.8,0,n).castShadow=!0,A(ie(.6,14,10),U(16777215),0,1.85,0,n),A(ie(.42,12,10),U(16777215),0,2.6,0,n);let a=A(Xe(.08,.4,8),U(16742912),0,2.6,-.5,n);a.rotation.x=-Math.PI/2,A(Vt(.3,.3,.35,12),U(2236962),0,3,0,n),A(Vt(.65,.65,.12,12),U(14174794),0,2.2,0,n);break}case"stall":{A(j(1.9,1.1,1.6),U(10251071),0,.55,0,n).castShadow=!0;for(let o of[-.9,.9])A(j(.1,2.4,.1),U(7162927),o,1.2,-.75,n);let a=A(j(2.1,.12,1.9),U(16777215,{map:Oo("#e76f51","#fff1d0")}),0,2.4,0,n);a.rotation.x=.15;for(let o=0;o<4;o++)A(ie(.18,8,6),U(yn([16742912,15320170,9159498,14174794])),-.6+o*.4,1.25,0,n);break}case"truck":case"neonTruck":case"iceTruck":case"logTruck":case"plowTruck":case"caravan":{let a=e.len||12,o=2.6,l=e.color??yn(s),c=i==="neonTruck"?2827600:i==="iceTruck"?16777215:i==="caravan"?16180160:i==="logTruck"?7162945:l,h=A(j(2.2,o-.6,a-2.6),U(c),0,.6+(o-.6)/2,-(a-2.6)/2-0,n);if(h.castShadow=!0,A(j(2.24,.08,a-2.6),U(9082531),0,o-.02,-(a-2.6)/2,n),i==="neonTruck"&&(A(j(2.26,.08,a-2.6),de(3798015),0,1.2,-(a-2.6)/2,n),A(j(2.26,.08,a-2.6),de(16727538),0,2.2,-(a-2.6)/2,n)),i==="iceTruck"&&A(j(2.26,.5,a-3),U(16740193),0,1.6,-(a-2.6)/2,n),i==="logTruck")for(let d=0;d<3;d++){let f=A(Vt(.3,.3,a-3,10),U(9067051),-.75+d*.75,1,-(a-2.6)/2,n);f.rotation.x=Math.PI/2}i==="caravan"&&A(j(2.26,.3,a-2.6),U(2792847),0,1.4,-(a-2.6)/2,n),i==="plowTruck"&&A(j(2.26,.15,a-2.6),U(16777215),0,o+.05,-(a-2.6)/2,n);let u=A(Oe(2.2,2.2,2.4,.25),U(l),0,1.45,-(a-1.2),n);if(u.castShadow=!0,A(j(2,.7,.05),U(2241348),0,1.9,-(a-2.42),n),Yh(n,[-1,1],[-1.2,-(a-4.5),-(a-1.2)],.45,.45),i==="plowTruck"&&A(j(2.6,.9,.3),U(16763196),0,.6,-(a+.1),n),e.ramp){let f=new Qt;n.add(f);let g=Math.atan2(o,4),_=Math.hypot(o,4),m=A(j(2.1,.12,_),U(11581632),0,o/2,4/2,f);m.rotation.x=g;for(let p of[-1.02,1.02]){let v=A(j(.08,.2,_),U(16763904),p,o/2+.1,2,f);v.rotation.x=g}for(let p=0;p<4;p++){let v=A(j(2.1,.03,.1),U(5592405),0,(p+.5)*o/4+.08,4-(p+.5)*4/4,f);v.rotation.x=g}}else{A(j(2,1.6,.06),U(6713210),0,1.6,.03,n);for(let d of[-.85,.85])A(j(.25,.15,.05),de(16719904),d,.85,.06,n)}break}case"cone":{A(Xe(.38,.85,14),U(16739584),0,.45,0,n).castShadow=!0,A(Vt(.24,.29,.14,14),U(16777215),0,.48,0,n),A(j(.8,.06,.8),U(16739584),0,.03,0,n);break}case"neonCone":{A(Xe(.38,.85,14),U(2827600),0,.45,0,n),A(Vt(.24,.29,.14,14),de(3798015),0,.48,0,n);break}case"sandcastle":{A(j(.9,.5,.8),U(15254650),0,.25,0,n);for(let a of[-.32,.32])A(Vt(.16,.18,.45,8),U(15254650),a,.7,0,n);A(Xe(.15,.3,8),U(16740193),.32,1.05,0,n);break}case"stump":{A(Vt(.42,.5,.75,12),U(8015658),0,.37,0,n).castShadow=!0,A(Vt(.38,.38,.02,12),U(14267004),0,.76,0,n);break}case"snowCone":{A(Xe(.5,.85,10),U(16777215),0,.42,0,n),A(ie(.12,8,6),U(14174794),0,.9,0,n);break}case"jar":{let a=A(ie(.45,12,10),U(12871739),0,.45,0,n);a.scale.y=1.05,A(Vt(.2,.25,.25,10),U(10506797),0,.92,0,n),A(Vt(.46,.46,.08,12),U(2792847),0,.5,0,n);break}case"car":case"buggy":case"cart":case"sled":case"camelCart":default:{let a=e.color??yn(s),o=A(Oe(1.9,.9,3.4,.25),U(a),0,.8,0,n);if(o.castShadow=!0,A(Oe(1.6,.65,1.7,.2),U(i==="sled"?14174794:2241348),0,1.5,.2,n),i!=="sled")Yh(n,[-.88,.88],[-1.1,1.1],.36,.36);else for(let l of[-.8,.8])A(j(.1,.1,3.6),U(10066329),l,.15,0,n);for(let l of[-.6,.6])A(j(.35,.18,.05),de(16774848),l,.85,1.72,n);A(j(1.92,.08,.1),U(2236962),0,.5,1.7,n);break}}return n}function jh(i,t,e,n,s=5025616,r=8015658){A(Vt(.18*n,.25*n,1.6*n,7),U(r),t,.8*n,e,i);let a=A(zo(1.1*n,0),U(s,{flat:!0}),t,2.2*n,e,i);a.castShadow=!0,A(zo(.75*n,0),U(s,{flat:!0}),t+.4*n,2.9*n,e+.2,i)}function Ef(i,t,e,n,s){A(Vt(.18*n,.22*n,1*n,6),U(7162945),t,.5*n,e,i);for(let r=0;r<3;r++){let a=A(Xe((1.3-r*.32)*n,1.4*n,8),U(s&&r===2?16777215:3112266,{flat:!0}),t,(1.3+r*.85)*n,e,i);a.castShadow=r===0,s&&r<2&&A(Xe((1-r*.3)*n,.35*n,8),U(16777215),t,(1.85+r*.85)*n,e,i)}}function Kh(i,t,e,n){let s=t,r=0;for(let a=0;a<6;a++){let o=A(Vt(.16*n,.2*n,.7*n,7),U(a%2?10124111:9071423),s,r+.35*n,e,i);o.rotation.z=-.08*a,s+=.08*a*n,r+=.66*n}for(let a=0;a<6;a++){let o=a/6*Math.PI*2,l=A(j(.3*n,.06*n,1.9*n),U(4173385,{flat:!0}),s+Math.cos(o)*.8*n,r+.1*n,e+Math.sin(o)*.8*n,i);l.rotation.y=-o+Math.PI/2,l.rotation.x=.35}for(let a=0;a<3;a++)A(ie(.15*n,6,5),U(7162927),s+(a-1)*.15*n,r-.1*n,e,i)}function Tv(i,t,e,n=16774064,s=1){A(Vt(.07,.09,4,6),U(5594214),t,2,e,i),A(j(.9,.08,.08),U(5594214),t-.45*s,4,e,i),A(j(.35,.12,.25),de(n),t-.85*s,3.92,e,i)}function gf(i,t,e,n,s,r,a,o,l){let c=A(j(n,s,r),U(a),t,s/2,e,i);c.castShadow=!0;let h=A(Xe(Math.max(n,r)*.78,s*.6,4),U(o,{flat:!0}),t,s+s*.3,e,i);h.rotation.y=Math.PI/4;let u=l?de(16769357):U(10474751),d=t>0?-1:1;for(let f of[-r*.25,r*.25])A(j(.05,.7,.7),u,t+d*(n/2+.03),s*.6,e+f,i);A(j(.05,1.3,.8),U(9067051),t+d*(n/2+.03),.65,e,i)}function Av(i,t,e,n,s,r,a,o){let l=Mv(a),c=a?U(16777215,{map:l,emissive:16777215,ei:0}):U(16777215,{map:l});a&&(c.emissiveMap=l,c.emissiveIntensity=.9,c.emissive=new Wt(16777215));let h=A(j(n,s,r),c,t,s/2,e,i);h.material=c,o!==void 0&&A(j(n+.1,.3,r+.1),a?de(o):U(o),t,s,e,i)}function Rv(i,t,e,n,s=9080726){A(Zh(n),U(s,{flat:!0}),t,n*.6,e,i).rotation.set(t,e,0)}function Xr(i,t,e,n=Math.random){let s=new Qt,r=i.palette,a=6.4,o=2+Math.floor(n()*2);for(let l=0;l<o;l++){let c=-((l+.5)/o)*e+(n()-.5)*4,h=t*(a+1.5+n()*5),u=n();switch(i.props){case"city":u<.5?gf(s,t*(a+3.5+n()*3),c,3.5+n()*2,2.6+n()*1.5,3.5+n()*2,yn(r,n),yn([15292223,8212126,3829413,5208386],n),!1):u<.8?jh(s,h,c,.9+n()*.5):A(j(.8,.8,4),U(4165434),t*(a+.6),.4,c,s);break;case"neon":if(u<.65)Av(s,t*(a+4+n()*4),c,4+n()*3,8+n()*16,4+n()*3,!0,yn(r,n));else{let d=yn(r,n);A(j(.2,3,.2),U(2827600),h,1.5,c,s),A(j(2.4,1.2,.12),de(d),h,3.4,c,s).rotation.y=t*.6}break;case"island":if(u<.55)Kh(s,h,c,.9+n()*.4);else if(u<.75){A(Vt(.05,.05,2.4,5),U(16777215),h,1.2,c,s);let d=A(Xe(1.3,.6,8),U(yn([16740193,3065014,16760681],n)),h,2.4,c,s);d.castShadow=!0}else Rv(s,h,c,.6+n()*.6,13218442);break;case"forest":if(u<.6)jh(s,h,c,1.2+n()*.8,yn([3112242,5025616,3706428],n),6111287);else if(u<.8){let d=A(Bo(1.1,.25,6,16),U(10391402,{flat:!0}),h,1.4,c,s);d.rotation.y=Math.PI/2;for(let f=0;f<8;f++){let g=f/8*Math.PI*2;A(j(.3,.4,.4),U(10391402),h,1.4+Math.sin(g)*1.4,c+Math.cos(g)*1.4,s)}}else A(Vt(.12,.15,.6,6),U(16773590),h,.3,c,s),A(ie(.45,10,6),U(15022389),h,.65,c,s).scale.y=.6;break;case"snow":if(u<.65)Ef(s,h,c,1+n()*.6,!0);else if(u<.85){let d=A(ie(1.4,10,8),U(16777215),h,0,c,s);d.scale.y=.5}else gf(s,t*(a+4),c,3.5,2.6,3.5,9067067,16777215,!1);break;case"desert":default:if(u<.35)Kh(s,h,c,.9+n()*.4);else if(u<.65){let d=t*(a+3.5+n()*2);A(j(3.2,2.6,3.2),U(16180160),d,1.3,c,s).castShadow=!0,A(Ae("dome",()=>new _n(1.2,14,8,0,Math.PI*2,0,Math.PI/2)),U(yn([13934615,2792847,16777215],n)),d,2.6,c,s),A(j(.06,1.2,.8),U(2792847),d-t*1.62,.6,c,s)}else u<.85?A(ie(2.5,12,8),U(15317106),h+t*2,-.6,c,s).scale.set(1.4,.55,1):(A(Vt(.06,.06,2.8,5),U(3877402),h,1.4,c,s),A(Ae("lant",()=>new $s(.28,0)),de(16757575),h,2.95,c,s));break}}return(i.props==="city"||i.props==="neon"||i.props==="snow")&&Tv(s,t*(a-.3),-e*.5,i.night?16727538:16774064,t),i.props==="desert"&&n()<.6&&(A(Vt(.05,.05,2.4,5),U(3877402),t*(a-.2),1.2,-e*.5,s),A(Ae("lant",()=>new $s(.28,0)),de(16757575),t*(a-.2),2.55,-e*.5,s)),s}function Tf(i,t){let e=new Qt,n=8.6,s=A(oi(n,t),U(16777215,{map:bv(i.road,i.line,i.night)}),0,0,-t/2,e);s.rotation.x=-Math.PI/2,s.receiveShadow=!0;for(let r of[-1,1]){let a=A(j(1.4,.18,t),U(i.side),r*(n/2+.7),.09,-t/2,e);a.receiveShadow=!0;let o=A(oi(70,t),U(i.ground),r*(n/2+1.4+35),-.01,-t/2,e);if(o.rotation.x=-Math.PI/2,o.receiveShadow=!0,i.water){let l=A(oi(60,t),U(i.water,{emissive:674389,ei:.3}),r*(n/2+14+30),.02,-t/2,e);l.rotation.x=-Math.PI/2}i.night&&A(j(.08,.06,t),de(r<0?16727538:3798015),r*(n/2+.02),.2,-t/2,e)}return e}function Qh(i){let t=new _n(450,24,12),e=new gn({side:$e,depthWrite:!1,fog:!1,uniforms:{top:{value:new Wt(i.sky[0])},bottom:{value:new Wt(i.sky[1])}},vertexShader:"varying vec3 vp; void main(){ vp = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:"uniform vec3 top; uniform vec3 bottom; varying vec3 vp; void main(){ float h = clamp(vp.y*1.6+0.15,0.0,1.0); gl_FragColor = vec4(mix(bottom, top, h),1.0); }"}),n=new Me(t,e),s=new Qt;if(s.add(n),i.night){let r=new Float32Array(1800);for(let l=0;l<600;l++){let c=Math.random()*Math.PI*2,h=Math.random()*1.2+.1,u=420;r[l*3]=Math.cos(c)*Math.cos(h)*u,r[l*3+1]=Math.sin(h)*u,r[l*3+2]=Math.sin(c)*Math.cos(h)*u}let a=new Re;a.setAttribute("position",new Ne(r,3)),s.add(new Ws(a,new Yi({color:16777215,size:2.2,sizeAttenuation:!1,fog:!1})));let o=A(ie(14,16,12),He(16774872,{fog:!1}),-120,160,-330,s);o.material.fog=!1}else{let r=A(ie(18,16,12),He(16774864,{fog:!1}),140,170,-360,s);r.material.fog=!1;let a=He(16777215,{opacity:.92,fog:!1});for(let o=0;o<12;o++){let l=new Qt,c=-Math.PI/2+(Math.random()-.5)*2.4;l.position.set(Math.cos(c)*330,70+Math.random()*80,Math.sin(c)*330);for(let h=0;h<4;h++)A(ie(10+Math.random()*8,10,8),a,h*12-18,Math.random()*6,Math.random()*6,l);l.lookAt(0,l.position.y,0),s.add(l)}}return s}function Af(i){let t=new Qt,e=i.house,n=[[],[],[],[],[],[]],s=(x,D)=>(n[x].push(D),D),r=U(e.wall),a=U(e.roof,{flat:!0}),o=U(e.trim),l=i.night?de(16770442):U(11066623,{emissive:2775680,ei:.25}),c=A(Vt(7.5,7.8,.4,32),U(i.side),0,-.2,0,t);c.receiveShadow=!0;let h=A(Vt(7.3,7.3,.05,32),U(i.ground),0,.01,0,t);h.receiveShadow=!0;let u=new Qt;t.add(u),s(0,u);for(let[x,D]of[[-2.3,-1.8],[2.3,-1.8],[-2.3,1.8],[2.3,1.8]])A(j(.12,4.2,.12),U(16756768),x,2.1,D,u);for(let x of[1.4,2.8,4.1])A(j(4.7,.1,.1),U(16756768),0,x,1.8,u),A(j(4.7,.1,.1),U(16756768),0,x,-1.8,u);let d=A(j(1.6,1,.08),U(16777215,{map:Oo("#1b1b1b","#ffcc00")}),3.4,1.2,2.4,u);d.rotation.y=-.4,A(j(.08,1.2,.08),U(5592405),3.4,.6,2.4,u);for(let x of[-3.6,-2.9])A(Xe(.3,.7,10),U(16739584),x,.35,3,u);let f=e.style;if(f==="classic"||f==="chalet"||f==="cabin"){s(1,A(j(4.4,.3,3.6),U(10395294),0,.15,0,t));let x=s(1,A(j(4.2,2.8,3.4),r,0,1.7,0,t));if(x.castShadow=!0,f==="cabin")for(let R=.5;R<3;R+=.45)s(1,A(j(4.25,.06,3.45),U(7162927),0,R,0,t));let D=Ae("gable"+f,()=>{let R=new Ei;R.moveTo(-2.6,0),R.lineTo(2.6,0),R.lineTo(0,f==="cabin"?2.4:1.8),R.lineTo(-2.6,0);let L=new Br(R,{depth:4,bevelEnabled:!1});return L.translate(0,0,-2),L}),T=s(2,A(D,a,0,3.1,0,t));T.castShadow=!0,s(2,A(j(.6,1.2,.6),U(9067067),1.3,4,-.6,t)),s(3,A(j(.9,1.6,.08),U(8015658),0,1.1,1.72,t)),s(3,A(ie(.06,6,4),U(16763196),.3,1.1,1.78,t));for(let R of[-1.4,1.4])s(3,A(j(.9,.8,.06),l,R,2,1.72,t)),s(3,A(j(1.06,.1,.1),o,R,1.55,1.75,t));if(s(3,A(j(.9,.7,.06),l,0,3.6,2,t)),f==="chalet")for(let R=0;R<8;R++){let L=A(Xe(.07,.35,5),U(14677759),-2.3+R*.66,2.95,2.05,t);L.rotation.x=Math.PI,s(3,L)}}else if(f==="modern"){let x=s(1,A(j(4.6,2.4,3.6),r,0,1.2,0,t));x.castShadow=!0;let D=s(2,A(j(3.4,2,3),r,.6,3.4,-.2,t));D.castShadow=!0,s(2,A(j(3.6,.15,3.2),o,.6,4.45,-.2,t)),s(3,A(j(2.6,1.4,.06),l,-.6,1.3,1.82,t)),s(3,A(j(2.2,1,.06),l,.6,3.4,1.32,t)),s(3,A(j(.8,1.8,.06),U(1118481),1.5,.9,1.82,t)),s(5,A(j(4.7,.08,.08),de(e.trim),0,2.4,1.82,t)),s(5,A(j(.08,2.4,.08),de(3798015),-2.3,1.2,1.82,t))}else if(f==="beach"){for(let[T,R]of[[-1.8,-1.4],[1.8,-1.4],[-1.8,1.4],[1.8,1.4]])s(1,A(Vt(.15,.15,1.4,8),U(9071423),T,.7,R,t));s(1,A(j(4.4,.25,3.8),U(13208380),0,1.45,0,t));let x=s(1,A(j(3.6,2.2,3),r,0,2.65,0,t));x.castShadow=!0;let D=s(2,A(Xe(3.4,2.2,4),a,0,4.85,0,t));D.rotation.y=Math.PI/4,D.castShadow=!0,s(3,A(j(.9,1.5,.06),U(3065014),0,2.4,1.52,t));for(let T of[-1.15,1.15])s(3,A(j(.7,.6,.06),l,T,2.9,1.52,t));for(let T=0;T<5;T++)s(3,A(j(1,.08,.3),U(9071423),0,.2+T*.27,2+T*.05-0+(4-T)*.3,t))}else if(f==="arabian"){let x=s(1,A(j(4.6,3,3.8),r,0,1.5,0,t));x.castShadow=!0,s(1,A(j(4.8,.25,4),U(14731680),0,3.05,0,t));let D=s(2,A(Ae("bigdome",()=>new _n(1.7,20,12,0,Math.PI*2,0,Math.PI/2)),a,0,3.15,0,t));D.castShadow=!0,s(2,A(Vt(.05,.05,.8,6),U(13934615),0,5.1,0,t)),s(2,A(ie(.15,8,6),U(13934615),0,5.5,0,t));for(let R of[-2.6,2.6])s(2,A(Vt(.35,.4,4.6,10),r,R,2.3,-1.6,t)),s(2,A(Ae("smalldome",()=>new _n(.42,12,8,0,Math.PI*2,0,Math.PI/2)),a,R,4.6,-1.6,t));let T=Ae("arch",()=>{let R=new Ei;return R.moveTo(-.55,0),R.lineTo(.55,0),R.lineTo(.55,1.3),R.absarc(0,1.3,.55,0,Math.PI,!1),R.lineTo(-.55,0),new Ao(R)});s(3,A(T,U(e.trim),0,0,1.92,t));for(let R of[-1.5,1.5])s(3,A(T,l,R,1.2,1.92,t)).scale.set(.6,.6,1)}let g=U(f==="modern"?2827600:16777215);for(let x=-6;x<=6;x++)Math.abs(x)<=1||s(4,A(j(.12,.8,.12),g,x*.5,.4,4.6,t));for(let x of[-2,2])s(4,A(j(2.1,.08,.06),g,x,.6,4.6,t));s(4,A(j(1.4,.03,3),U(14274752),0,.04,3.2,t));let _=f==="chalet"?null:f==="arabian"||f==="beach"?"palm":"tree";for(let[x,D]of[[-5,1],[5,-.5],[-4.3,-3.6]]){let T=new Qt;t.add(T),s(4,T),_==="palm"?Kh(T,x,D,1):f==="chalet"?Ef(T,x,D,1.1,!0):jh(T,x,D,1.1,f==="modern"?8086015:5025616)}for(let x=0;x<10;x++){let D=-3.2+x%5*.35+(x>=5?4.9:0),T=2.3+x*37%7*.12;s(4,A(ie(.13,6,5),U([16732067,16769357,16743001,16777215][x%4]),D,.2,T,t))}s(4,A(j(.35,.3,.45),U(e.trim),2.6,1,4.4,t)),s(4,A(j(.08,.9,.08),U(5592405),2.6,.45,4.4,t));for(let x=0;x<9;x++)s(5,A(ie(.09,6,4),de([16727386,16769357,3798015][x%3]),-2+x*.5,3+Math.sin(x/8*Math.PI)*-.25,1.95,t));s(5,A(Vt(.04,.04,2.2,6),U(13421772),-2.6,4.3,-1.2,t));let m=s(5,A(oi(.9,.55),U(e.trim,{side:!0}),-2.15,5.1,-1.2,t));m.userData.flag=!0;let p=s(5,A(Ae("dish",()=>new _n(.5,12,6,0,Math.PI*2,0,Math.PI/3)),U(14540253,{side:!0}),1.9,3.7,-1.3,t));p.rotation.x=-.9;let v=new Qt;v.position.set(4.6,.4,3.4),v.scale.setScalar(.45),v.rotation.y=-.6,t.add(v),s(5,v),A(Vt(.9,1,.8,12),U(14540253),0,-.4,0,v);let y=Wr({body:16765773,accent:16752412,visor:3876096,eye:16777215});return y.userData.shadow.visible=!1,y.rotation.y=Math.PI,v.add(y),t.userData.parts=n,t}function Rf(i,t){let e=i.userData.parts;for(let n=0;n<e.length;n++){let s=n===0?t<3:n<=t;for(let r of e[n])r.visible=s}}var es=30,Pv=8,tu=420,Iv=165,Lv={low:{y0:0,y1:.95,len:.7,hw:1},cone:{y0:0,y1:.85,len:.7,hw:.45},high:{y0:1.15,y1:2.7,len:.5,hw:1.05},block:{y0:0,y1:2.4,len:3.2,hw:1},mover:{y0:0,y1:1.75,len:3.4,hw:.95},truck:{y0:0,y1:2.6,len:12,hw:1.1},bomb:{y0:0,y1:1,len:.9,hw:.55}},Dv={van:3.8,hoverCar:3.6,hut:2.2,boulder:2.8,snowman:1.8,stall:1.7};function Ti(i,t){return i+Math.random()*(t-i)}function Go(i){return Math.floor(Math.random()*i)}function eu(i){for(let t=i.length-1;t>0;t--){let e=Go(t+1);[i[t],i[e]]=[i[e],i[t]]}return i}function Vo(i){let t=i.reduce((n,s)=>n+Math.max(0,s[1]),0),e=Math.random()*t;for(let n of i)if(e-=Math.max(0,n[1]),e<=0)return n[0];return i[0][0]}var Wo=class{constructor(t,e){this.scene=t,this.world=e,this.root=new Qt,t.add(this.root),this.tiles=[];for(let n=0;n<Pv;n++){let s=new Qt;s.add(Tf(e,es));let r=Xr(e,-1,es),a=Xr(e,1,es);s.add(r),s.add(a),s.userData.sides=[r,a],this.root.add(s),this.tiles.push(s)}this.goldMesh=new go(yf(),bf(),tu),this.goldMesh.instanceMatrix.setUsage(Qd),this.goldMesh.frustumCulled=!1,this.goldMesh.castShadow=!1,this.root.add(this.goldMesh),this.gold=[],this.goldFree=[];for(let n=0;n<tu;n++)this.goldFree.push(n);this.pools=new Map,this.obstacles=[],this.pickups=[],this._m=new ue,this._q=new Bn,this._e=new mn,this._s=new P,this._p=new P,this.reset()}dispose(){this.scene.remove(this.root)}reset(){for(let t of this.obstacles)this._release(t.mesh,t.poolKey);for(let t of this.pickups)this._release(t.mesh,t.poolKey);this.obstacles=[],this.pickups=[];for(let t of this.gold)this.goldFree.push(t.idx);this.gold=[],this._hideAllGold(),this.tiles.forEach((t,e)=>{t.position.z=-(e-1)*es}),this.nextD=34,this.spawnPaused=!1,this.nextPowerD=Ti(160,240),this.nextGemD=Ti(500,800),this.nextVaultD=Ti(900,1500),this.lastRow=null,this.tutorial=null,this.tutorialQueue=[]}_hideAllGold(){this._m.makeScale(0,0,0);for(let t=0;t<tu;t++)this.goldMesh.setMatrixAt(t,this._m);this.goldMesh.instanceMatrix.needsUpdate=!0}_get(t,e){let n=this.pools.get(t);n||(n=[],this.pools.set(t,n));let s=n.pop()||e();return s.visible=!0,this.root.add(s),s}_release(t,e){if(!t)return;t.visible=!1,this.root.remove(t);let n=this.pools.get(e);n||(n=[],this.pools.set(e,n)),n.push(t)}addObstacle(t,e,n,s={}){let r=this.world,a=s.kind||r.obstacle[t==="bomb"?"low":t],o=!!s.ramp,l=t==="bomb"?"bomb:"+(s.bombKind||"red"):a+(o?":r":"")+(s.len?":"+s.len:""),c=this._get(l,()=>t==="bomb"?$r(s.bombKind||"red"):wf(a,r,{ramp:o,len:s.len})),h=Lv[t],u=dn[e],d,f;if(t==="truck"){let _=s.len||12;d=n,f=n+_,c.position.set(u,0,-n)}else{let _=t==="block"&&Dv[a]||h.len;d=n-_/2,f=n+_/2,c.position.set(u,0,-n)}c.rotation.set(0,0,0);let g={family:t,kind:a,lane:e,x:u,d0:d,d1:f,y0:h.y0,y1:h.y1,hw:h.hw,mesh:c,poolKey:l,ramp:o,rampLen:o?4:0,mover:s.mover||0,active:!0,boss:!!s.boss};return this.obstacles.push(g),g}addGold(t,e,n=.9){let s=this.goldFree.pop();if(s===void 0)return null;let r={idx:s,x:t,d:e,y:n,magnet:!1,t:Math.random()*6};return this.gold.push(r),r}goldLine(t,e,n,s=2.1,r=.9){for(let a=0;a<n;a++)this.addGold(dn[t],e+a*s,r)}goldArc(t,e,n=1.9,s=7,r=9){for(let a=0;a<s;a++){let o=a/(s-1);this.addGold(dn[t],e-r/2+o*r,.9+Math.sin(o*Math.PI)*n)}}addPickup(t,e,n,s=1.1){let r="pu:"+t,a;t==="gem"?a=this._get(r,()=>Mf()):t==="emp"?a=this._get(r,()=>$r("emp")):a=this._get(r,()=>Sf(t));let o=typeof e=="number"&&e>=0&&e<=2&&Number.isInteger(e)?dn[e]:e;a.position.set(o,s,-n);let l={type:t,x:o,d:n,y:s,mesh:a,poolKey:r,active:!0,t:0};return this.pickups.push(l),l}laneFreeAt(t,e,n){return!this.obstacles.some(s=>s.lane===t&&s.d1>e&&s.d0<n)}startTutorial(){this.tutorialQueue=["jump","slide","lane"]}spawnRows(t,e,n,s){for(;this.nextD<t+Iv;){let r=this.nextD,a=0;this.tutorialQueue.length?a=this._tutorialRow(this.tutorialQueue.shift(),r):this.spawnPaused||s.jet?(s.jet||Math.random()<.6&&this.goldLine(Go(3),r,6),a=0):a=this._row(r,e,n,t);let o=Math.max(16,e*(1.28-.42*n));this.nextD=r+a+o}}_tutorialRow(t,e){let n=(s,r)=>{this.addObstacle(s,r,e).tutorial=!0};if(t==="jump"){for(let s=0;s<3;s++)n("low",s);this.goldArc(1,e)}if(t==="slide"){for(let s=0;s<3;s++)n("high",s);this.goldLine(1,e-2,3,2,.5)}return t==="lane"&&(n("block",0),n("block",1),this.goldLine(2,e-6,7)),this.tutorial=this.tutorial||[],this.tutorial.push({kind:t,d:e}),6}_row(t,e,n,s){let r=Vo([["single",3],["double",2+2*n],["wallLow",.8+n],["wallHigh",.8+n],["mixed",.4+1.6*n],["trucks",1.6+n],["mover",t>500?.6+1.6*n:0],["coins",1.1-.5*n]]),a=0,o=eu([0,1,2]),l=()=>Math.random()<.3?"cone":"low",c=()=>Vo([["low",3],["high",2.5],["block",2+2*n],["cone",1]]),h=o[2];switch(r){case"single":{let u=c();this.addObstacle(u,o[0],t),u==="low"||u==="cone"?this.goldArc(o[0],t):u==="high"&&this.goldLine(o[0],t-2,3,2,.5),this.goldLine(o[1],t-8,8),h=o[1];break}case"double":{let u=Math.random()<.6?"block":c(),d=Math.random()<.5?"block":c();this.addObstacle(u,o[0],t),this.addObstacle(d,o[1],t),this.goldLine(o[2],t-6,7);break}case"wallLow":{for(let u of o)this.addObstacle(l()==="cone"&&Math.random()<.3?"cone":"low",u,t);this.goldArc(o[0],t);break}case"wallHigh":{for(let u of o)this.addObstacle("high",u,t);this.goldLine(o[0],t-3,4,2,.5);break}case"mixed":{let u=eu(["low","high","block"]);o.forEach((f,g)=>this.addObstacle(u[g],f,t));let d=o[u.indexOf("low")];this.goldArc(d,t),h=d;break}case"trucks":{let u=Vo([[1,2],[2,3],[3,1.2+n]]),d=12,f=u===3?[!0,!1,!1]:[Math.random()<.65,!1];eu(f);for(let g=0;g<u;g++){let _=o[g],m=f[g]||!1,p=u===3?0:Ti(0,3);this.addObstacle("truck",_,t+p,{ramp:m,len:d}),m&&(this.goldLine(_,t+p-3.5,7,2.2,.9),this.goldLine(_,t+p+3,4,2,2.6+.9))}u<3&&this.goldLine(o[2],t,6),u<=2&&Math.random()<.3+.3*n?(this.addObstacle("truck",o[0],t+d+1.5,{ramp:!1,len:d}),a=d*2+1.5):a=d,h=u<3?o[2]:o[f.indexOf(!0)];break}case"mover":{let u=o.find(f=>this.laneFreeAt(f,t-32,t+2));if(u===void 0){this.goldLine(o[0],t,8);break}this.addObstacle("mover",u,t,{mover:Ti(7,10)+6*n});let d=o.filter(f=>f!==u);Math.random()<.5+.3*n&&this.addObstacle(Math.random()<.5?"block":"low",d[0],t+4),this.goldLine(d[1],t-4,7),h=d[1];break}case"coins":default:{let u=Go(3);for(let d=0;d<14;d++)d%5===4&&(u=Math.max(0,Math.min(2,u+(Math.random()<.5?-1:1)))),this.addGold(dn[u],t+d*2.1,.9);a=14;break}}if(t>=this.nextPowerD){this.nextPowerD=t+Ti(260,420);let u=Vo([["magnet",3],["double",2.5],["shield",2],["jet",1.8]]);this.laneFreeAt(h,t-12,t-8)&&this.addPickup(u,h,t-10,1.2)}else t>=this.nextGemD?(this.nextGemD=t+Ti(550,900),this.laneFreeAt(h,t-12,t-8)&&this.addPickup("gem",h,t-10,1.1)):t>=this.nextVaultD&&(this.nextVaultD=t+Ti(1100,1800),Math.random()<.55&&this.laneFreeAt(h,t-12,t-8)&&this.addPickup("vault",h,t-10,1));return this.lastRow={d:t,pattern:r},a}skyGold(t,e){let n=Go(3);for(let s=0;s<12;s++)s%6===5&&(n=Math.max(0,Math.min(2,n+(Math.random()<.5?-1:1)))),this.addGold(dn[n],t+s*2.4,e);return 12*2.4}clearRange(t,e,n=!0){this.obstacles=this.obstacles.filter(s=>s.d1>t&&s.d0<e&&(n||!s.boss)?(this._release(s.mesh,s.poolKey),!1):!0)}removeObstacle(t){let e=this.obstacles.indexOf(t);e>=0&&this.obstacles.splice(e,1),this._release(t.mesh,t.poolKey)}removePickup(t){let e=this.pickups.indexOf(t);e>=0&&this.pickups.splice(e,1),this._release(t.mesh,t.poolKey)}update(t,e,n){for(let h of this.tiles)if(-h.position.z+es<e-18){let d=-1/0;for(let f of this.tiles)d=Math.max(d,-f.position.z);h.position.z=-(d+es);for(let f of h.userData.sides)f.scale.z=Math.random()<.5?1:-1,f.position.z=f.scale.z<0?-es:0}for(let h of this.obstacles)if(h.mover&&h.d0-e<48){let u=h.mover*t;h.d0-=u,h.d1-=u,h.mesh.position.z=-(h.d0+h.d1)/2}this.obstacles.length&&(this.obstacles=this.obstacles.filter(h=>h.d1<e-14?(this._release(h.mesh,h.poolKey),!1):!0)),this.pickups.length&&(this.pickups=this.pickups.filter(h=>h.d<e-10?(this._release(h.mesh,h.poolKey),!1):!0));for(let h of this.pickups){if(h.t+=t,h.type==="emp"){h.mesh.userData.ring&&(h.mesh.userData.ring.rotation.z+=t*4);continue}h.mesh.rotation.y+=t*2.2,h.mesh.position.y=h.y+Math.sin(h.t*3)*.15;let u=h.mesh.userData.inner;u&&(u.rotation.y+=t)}let s=this._m,r=this._q,a=this._e,o=this._s,l=this._p,c=[];for(let h of this.gold){if(h.dead||h.d<e-1.5){this._freeGold(h);continue}h.t+=t,a.set(0,h.t*3,0),r.setFromEuler(a),o.set(1,1,1),l.set(h.x,h.y+Math.sin(h.t*4)*.08,-h.d),s.compose(l,r,o),this.goldMesh.setMatrixAt(h.idx,s),c.push(h)}this.gold=c,this.goldMesh.instanceMatrix.needsUpdate=!0}_freeGold(t){this._m.makeScale(0,0,0),this.goldMesh.setMatrixAt(t.idx,this._m),this.goldFree.push(t.idx)}floorAt(t,e,n,s){let r=0;for(let a of this.obstacles)if(!(Math.abs(t-a.x)>a.hw+s-.25)){if(a.ramp&&e>a.d0-a.rampLen&&e<=a.d0){Math.abs(t-a.x)<.95&&(r=Math.max(r,a.y1*(1-(a.d0-e)/a.rampLen)));continue}a.family==="high"||a.family==="bomb"||e>=a.d0-.2&&e<=a.d1+.2&&a.y1<=n&&(r=Math.max(r,a.y1))}return r}laneWidth(){return 2.4}};var nu=class{constructor(){this.ctx=null,this.sfxOn=!0,this.musicOn=!0,this.mode=null,this.coinStreak=0,this.lastCoin=0,this.step=0,this.nextTime=0,this.timer=null,this.jetNode=null}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;this.ctx=new t;let e=this.ctx;this.master=e.createGain(),this.master.gain.value=.9,this.master.connect(e.destination),this.comp=e.createDynamicsCompressor(),this.comp.connect(this.master),this.sfxBus=e.createGain(),this.sfxBus.gain.value=this.sfxOn?.8:0,this.sfxBus.connect(this.comp),this.musicBus=e.createGain(),this.musicBus.gain.value=this.musicOn?.33:0,this.musicBus.connect(this.comp);let n=e.sampleRate;this.noise=e.createBuffer(1,n,e.sampleRate);let s=this.noise.getChannelData(0);for(let r=0;r<n;r++)s[r]=Math.random()*2-1;this.mode&&this.startMusic(this.mode,!0)}suspend(){this.ctx&&this.ctx.state==="running"&&this.ctx.suspend()}resume(){this.ctx&&this.ctx.state==="suspended"&&this.ctx.resume()}setSfx(t){this.sfxOn=t,this.sfxBus&&(this.sfxBus.gain.value=t?.8:0),t||this.jet(!1)}setMusic(t){this.musicOn=t,this.musicBus&&(this.musicBus.gain.value=t?.33:0)}tone(t,e,{type:n="sine",vol:s=.3,when:r=0,slide:a=0,attack:o=.005,bus:l}={}){let c=this.ctx;if(!c)return;let h=c.currentTime+r,u=c.createOscillator(),d=c.createGain();u.type=n,u.frequency.setValueAtTime(t,h),a&&u.frequency.exponentialRampToValueAtTime(Math.max(30,t*a),h+e),d.gain.setValueAtTime(1e-4,h),d.gain.exponentialRampToValueAtTime(s,h+o),d.gain.exponentialRampToValueAtTime(1e-4,h+e),u.connect(d),d.connect(l||this.sfxBus),u.start(h),u.stop(h+e+.02)}noiseHit(t,{vol:e=.3,when:n=0,freq:s=1200,q:r=1,type:a="bandpass",sweep:o=0,bus:l}={}){let c=this.ctx;if(!c)return;let h=c.currentTime+n,u=c.createBufferSource();u.buffer=this.noise;let d=c.createBiquadFilter();d.type=a,d.frequency.setValueAtTime(s,h),d.Q.value=r,o&&d.frequency.exponentialRampToValueAtTime(Math.max(40,s*o),h+t);let f=c.createGain();f.gain.setValueAtTime(e,h),f.gain.exponentialRampToValueAtTime(1e-4,h+t),u.connect(d),d.connect(f),f.connect(l||this.sfxBus),u.start(h,Math.random()*.5),u.stop(h+t+.02)}play(t){if(!this.ctx||!this.sfxOn)return;let e=this;switch(t){case"coin":{let n=performance.now();e.coinStreak=n-e.lastCoin<260?Math.min(e.coinStreak+1,12):0,e.lastCoin=n;let s=1046*Math.pow(2,e.coinStreak%8/24);e.tone(s,.09,{type:"square",vol:.07}),e.tone(s*1.5,.14,{type:"sine",vol:.12,when:.045});break}case"gem":e.tone(1568,.12,{vol:.15}),e.tone(2093,.18,{vol:.12,when:.07}),e.tone(2637,.3,{vol:.1,when:.14});break;case"jump":e.tone(320,.22,{type:"triangle",vol:.2,slide:2.6}),e.noiseHit(.15,{vol:.06,freq:2500,sweep:2});break;case"slide":e.noiseHit(.35,{vol:.16,freq:900,sweep:.4,type:"lowpass"});break;case"land":e.tone(110,.08,{type:"sine",vol:.18,slide:.6});break;case"lane":e.noiseHit(.12,{vol:.07,freq:1800,sweep:1.8,q:2});break;case"stumble":e.tone(180,.18,{type:"sawtooth",vol:.12,slide:.5}),e.noiseHit(.12,{vol:.16,freq:600});break;case"crash":e.noiseHit(.6,{vol:.5,freq:700,sweep:.2,type:"lowpass"}),e.tone(140,.5,{type:"sawtooth",vol:.25,slide:.25}),e.tone(520,.12,{type:"square",vol:.08,when:.05,slide:.5});break;case"powerup":[523,659,784,1046].forEach((n,s)=>e.tone(n,.16,{type:"square",vol:.07,when:s*.06}));break;case"shieldBreak":e.noiseHit(.4,{vol:.3,freq:3e3,sweep:.3,q:3}),e.tone(880,.3,{type:"triangle",vol:.12,slide:.4});break;case"kick":e.tone(200,.12,{type:"square",vol:.15,slide:3}),e.noiseHit(.08,{vol:.2,freq:2e3});break;case"explode":e.noiseHit(1,{vol:.6,freq:1200,sweep:.08,type:"lowpass"}),e.tone(80,.8,{type:"sine",vol:.35,slide:.4});break;case"alarm":for(let n=0;n<3;n++)e.tone(880,.16,{type:"square",vol:.08,when:n*.36}),e.tone(660,.16,{type:"square",vol:.08,when:n*.36+.18});break;case"drop":e.tone(600,.25,{type:"triangle",vol:.12,slide:.3});break;case"laugh":[740,698,740,698,622].forEach((n,s)=>e.tone(n,.08,{type:"square",vol:.06,when:s*.09,slide:.8}));break;case"click":e.tone(1200,.05,{type:"triangle",vol:.12});break;case"buy":e.tone(784,.1,{vol:.15}),e.tone(1175,.2,{vol:.15,when:.08});break;case"build":e.noiseHit(.08,{vol:.25,freq:2e3,q:4}),e.noiseHit(.08,{vol:.25,freq:1800,q:4,when:.15}),e.tone(523,.2,{vol:.12,when:.3}),e.tone(784,.3,{vol:.12,when:.4});break;case"reward":[784,988,1175,1568].forEach((n,s)=>e.tone(n,.22,{type:"triangle",vol:.12,when:s*.08}));break;case"fanfare":[523,659,784,1046,784,1046].forEach((n,s)=>e.tone(n,.25,{type:"square",vol:.06,when:s*.11}));break;case"tick":e.tone(2200,.03,{type:"square",vol:.05});break;case"error":e.tone(200,.18,{type:"square",vol:.08}),e.tone(150,.25,{type:"square",vol:.08,when:.12});break;case"whoosh":e.noiseHit(.5,{vol:.2,freq:400,sweep:6,q:1.5});break;default:break}}jet(t){if(this.ctx){if(t&&!this.jetNode&&this.sfxOn){let e=this.ctx,n=e.createBufferSource();n.buffer=this.noise,n.loop=!0;let s=e.createBiquadFilter();s.type="lowpass",s.frequency.value=500;let r=e.createGain();r.gain.value=1e-4,r.gain.exponentialRampToValueAtTime(.12,e.currentTime+.3),n.connect(s),s.connect(r),r.connect(this.sfxBus),n.start(),this.jetNode={s:n,g:r}}else if(!t&&this.jetNode){let{s:e,g:n}=this.jetNode,s=this.ctx;n.gain.setValueAtTime(n.gain.value,s.currentTime),n.gain.exponentialRampToValueAtTime(1e-4,s.currentTime+.3),e.stop(s.currentTime+.35),this.jetNode=null}}}startMusic(t,e){this.mode===t&&!e&&this.timer||(this.mode=t,this.ctx&&(this.step=0,this.nextTime=this.ctx.currentTime+.08,this.timer&&clearInterval(this.timer),this.timer=setInterval(()=>this.schedule(),25)))}stopMusic(){this.timer&&clearInterval(this.timer),this.timer=null,this.mode=null}schedule(){let t=this.ctx;if(!t||t.state!=="running")return;let n=60/(this.mode==="run"?132:100)/4;for(;this.nextTime<t.currentTime+.12;)this.playStep(this.step,this.nextTime),this.nextTime+=n,this.step=(this.step+1)%64}playStep(t,e){let n=this.ctx,s=this.musicBus,r=t%16,a=Math.floor(t/16),o=[48,43,45,41],l=[[60,64,67],[59,62,67],[57,60,64],[57,60,65]],c=o[a],h=f=>440*Math.pow(2,(f-69)/12),u=(f,g,_,m,p=0,v=0)=>{let y=n.createOscillator(),x=n.createGain();if(y.type=_,y.frequency.value=f,x.gain.setValueAtTime(1e-4,e+p),x.gain.exponentialRampToValueAtTime(m,e+p+.01),x.gain.exponentialRampToValueAtTime(1e-4,e+p+g),v){let D=n.createBiquadFilter();D.type="lowpass",D.frequency.value=v,y.connect(D),D.connect(x)}else y.connect(x);x.connect(s),y.start(e+p),y.stop(e+p+g+.02)},d=(f,g,_,m="highpass")=>{let p=n.createBufferSource();p.buffer=this.noise;let v=n.createBiquadFilter();v.type=m,v.frequency.value=_;let y=n.createGain();y.gain.setValueAtTime(g,e),y.gain.exponentialRampToValueAtTime(1e-4,e+f),p.connect(v),v.connect(y),y.connect(s),p.start(e,Math.random()*.5),p.stop(e+f+.02)};if(this.mode==="run"){if(r%4===0){let p=n.createOscillator(),v=n.createGain();p.frequency.setValueAtTime(150,e),p.frequency.exponentialRampToValueAtTime(45,e+.12),v.gain.setValueAtTime(.9,e),v.gain.exponentialRampToValueAtTime(1e-4,e+.18),p.connect(v),v.connect(s),p.start(e),p.stop(e+.2)}(r===4||r===12)&&d(.14,.35,1500,"bandpass"),r%2===1&&d(.04,.12,7e3);let f=[0,0,12,0,0,12,0,7,0,0,12,0,0,12,7,12];(r%2===0||r===7||r===15)&&u(h(c+f[r]),.16,"sawtooth",.22,0,700);let g=l[a],_=[0,1,2,1];r%2===0&&u(h(g[_[r/2%4]]+12),.12,"square",.05,0,2600),r===0&&g.forEach(p=>u(h(p),1.6,"triangle",.05));let m=[[72,-1,76,-1,79,-1,76,74],[74,-1,71,-1,74,76,74,-1],[72,-1,69,-1,72,76,79,-1],[77,76,74,-1,72,-1,71,-1]];if(t>=0&&r%2===0){let p=m[a][r/2];p>0&&(Math.floor(t/64)%2===0||!0)&&u(h(p),.22,"triangle",.09)}}else{if(r%8===0){let g=n.createOscillator(),_=n.createGain();g.frequency.setValueAtTime(110,e),g.frequency.exponentialRampToValueAtTime(50,e+.1),_.gain.setValueAtTime(.4,e),_.gain.exponentialRampToValueAtTime(1e-4,e+.15),g.connect(_),_.connect(s),g.start(e),g.stop(e+.16)}r%4===2&&d(.05,.06,8e3),r===0&&l[a].forEach(g=>u(h(g),2.3,"triangle",.06)),r%4===0&&u(h(c),.5,"sine",.2);let f=[79,76,72,76,77,74,71,74,76,72,69,72,77,72,69,71];r%4===0&&u(h(f[a*4+r/4]),.4,"sine",.07),r%4===2&&u(h(f[a*4+(r-2)/4]+12),.15,"sine",.025)}}},wt=new nu;var Ai=new P;function $o(i,t,e){return i+(t-i)*e}function Ri(i,t,e,n){return $o(i,t,1-Math.exp(-e*n))}var iu=class{constructor(t,e=90){this.items=[],this.scene=t;let n=_f();this.mats=new Map,this.tex=n;for(let s=0;s<e;s++){let r=new po(this.mat(16777215));r.visible=!1,t.add(r),this.items.push({s:r,life:0,max:1,v:new P,g:0,size:1})}this.i=0}mat(t){let e=this.mats.get(t);return e||(e=new Lr({map:this.tex,color:t,blending:Ns,depthWrite:!1,transparent:!0}),this.mats.set(t,e)),e}burst(t,e,n=8,s=4,r=.5,a=.5,o=4){for(let l=0;l<n;l++){let c=this.items[this.i];this.i=(this.i+1)%this.items.length,c.s.material=this.mat(e),c.s.position.copy(t),c.v.set((Math.random()-.5)*s,Math.random()*s*.8,(Math.random()-.5)*s),c.life=c.max=a*(.6+Math.random()*.6),c.g=o,c.size=r*(.6+Math.random()*.8),c.s.visible=!0}}update(t){for(let e of this.items){if(e.life<=0)continue;if(e.life-=t,e.life<=0){e.s.visible=!1;continue}e.v.y-=e.g*t,e.s.position.addScaledVector(e.v,t);let n=e.life/e.max;e.s.scale.setScalar(e.size*(.4+n*.6)),e.s.material.opacity=n}}clear(){for(let t of this.items)t.life=0,t.s.visible=!1}},Xo=class{constructor(t,e,n="high"){this.hooks=e,this.canvas=t,this.renderer=new uo({canvas:t,antialias:n==="high",powerPreference:"high-performance"}),this.renderer.setClearColor(8900331),this.camera=new Ze(62,1,.1,900),this.scene=new Ir,this.lobby=new Ir,this.mode="lobby",this.view="home",this.time=0,this.paused=!1,this.timeScale=1,this.shake=0,this.lobbyRot=0,this.lobbyRotV=0,this.world=null,this.lobbyWorld=null,this.setQuality(n),this._setupRunScene(),this._resize=()=>this.resize(),window.addEventListener("resize",this._resize),this.resize(),this.last=performance.now(),this._frame=s=>this.frame(s),requestAnimationFrame(this._frame)}setQuality(t){this.quality=t;let e=window.devicePixelRatio||1;this.renderer.setPixelRatio(Math.min(e,t==="high"?2:1)),this.renderer.shadowMap.enabled=t==="high",this.renderer.shadowMap.type=Dh,this.sun&&(this.sun.castShadow=t==="high"),this.lobbySun&&(this.lobbySun.castShadow=t==="high"),this.resize()}resize(){let t=window.innerWidth,e=window.innerHeight;this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix()}_setupRunScene(){let t=this.scene;this.hemi=new zr(16777215,8956518,1),t.add(this.hemi),this.sun=new Hr(16777215,1.3),this.sun.castShadow=this.quality==="high",this.sun.shadow.mapSize.set(1024,1024);let e=this.sun.shadow.camera;e.left=-12,e.right=12,e.top=16,e.bottom=-16,e.near=1,e.far=60,this.sun.shadow.bias=-8e-4,t.add(this.sun),t.add(this.sun.target),this.particles=new iu(t),this.shieldBubble=new Me(new _n(1.25,20,14),He(3786495,{opacity:.25,blend:!0})),this.shieldBubble.visible=!1,this.magnetRing=new Me(new ji(1,.06,6,30),He(16727386,{opacity:.8,blend:!0})),this.magnetRing.rotation.x=Math.PI/2,this.magnetRing.visible=!1,this.marker=new Me(new ai(2.2,5),He(16719904,{opacity:.45,blend:!0})),this.marker.rotation.x=-Math.PI/2,this.marker.visible=!1,t.add(this.shieldBubble,this.magnetRing,this.marker),this.van=vf(),this.van.visible=!1,t.add(this.van),this.thief=Ho(),this.thief.visible=!1,t.add(this.thief),this.projectiles=[]}_applyWorldLighting(t,e,n,s){t.fog=new Pr(e.fog,e.fogNear,e.fogFar),n.color.set(e.hemi[0]),n.groundColor.set(e.hemi[1]),n.intensity=e.hemi[2],s.color.set(e.sun[0]),s.intensity=e.sun[1]}setRunWorld(t){if(this.world!==t&&(this.world=t,this.track&&this.track.dispose(),this.track=new Wo(this.scene,t),this.sky&&this.scene.remove(this.sky),this.sky=Qh(t),this.scene.add(this.sky),this._applyWorldLighting(this.scene,t,this.hemi,this.sun),this.snow&&(this.scene.remove(this.snow),this.snow=null),t.snow)){let n=new Float32Array(2100);for(let r=0;r<700;r++)n[r*3]=(Math.random()-.5)*40,n[r*3+1]=Math.random()*20,n[r*3+2]=-Math.random()*60;let s=new Re;s.setAttribute("position",new Ne(n,3)),this.snow=new Ws(s,new Yi({color:16777215,size:.18,transparent:!0,opacity:.9})),this.scene.add(this.snow)}}setPlayer(t){this.player&&this.scene.remove(this.player),this.player=Wr(t,{jet:!1}),this.scene.add(this.player),this.player.add(this.shieldBubble),this.shieldBubble.position.set(0,1.1,0),this.player.add(this.magnetRing),this.magnetRing.position.set(0,.15,0)}setLobby(t,e,n){let s=this.lobby;if(this.lobbyWorld!==t){for(this.lobbyWorld=t;s.children.length;)s.remove(s.children[0]);this.lobbyHemi=new zr(16777215,8956518,1),this.lobbySun=new Hr(16777215,1.3),this.lobbySun.position.set(8,16,12),this.lobbySun.castShadow=this.quality==="high",this.lobbySun.shadow.mapSize.set(1024,1024);let r=this.lobbySun.shadow.camera;r.left=-12,r.right=12,r.top=12,r.bottom=-12,s.add(this.lobbyHemi,this.lobbySun),this._applyWorldLighting(s,t,this.lobbyHemi,this.lobbySun),s.fog=new Pr(t.fog,40,140),s.add(Qh(t));let a=new Me(new ai(400,400),U(t.ground));a.rotation.x=-Math.PI/2,a.position.y=-.4,a.receiveShadow=!0,s.add(a);for(let h=0;h<3;h++)for(let u of[-1,1]){let d=Xr(t,u,30);d.position.set(u*6,-.4,-6-h*26),s.add(d)}this.house=Af(t),s.add(this.house);let o=new Qt;o.position.set(0,0,6.4);let l=new Me(new Zi(1.2,1.35,.35,28),U(16777215));l.position.y=.17,l.receiveShadow=!0;let c=new Me(new ji(1.25,.06,6,40),U(1619967,{emissive:1619967,ei:1}));c.rotation.x=Math.PI/2,c.position.y=.34,o.add(l,c),s.add(o),this.pedestal=o,this.lobbyThief=Ho(),this.lobbyThief.position.set(-5.2,0,2.5),this.lobbyThief.rotation.y=Math.PI*.75,this.lobbyThief.scale.setScalar(.85),s.add(this.lobbyThief),this.lobbyChar=null,this.lobbySkin=null}Rf(this.house,e),this.lobbyStage=e,n&&this.lobbySkin!==n&&(this.lobbySkin=n,this.lobbyChar&&this.pedestal.remove(this.lobbyChar),this.lobbyChar=Wr(n),this.lobbyChar.position.y=.35,this.pedestal.add(this.lobbyChar),this.waveT=1.2)}celebrateLobby(){this.waveT=1.6}setView(t){this.view=t}dragLobby(t){this.lobbyRotV+=t*.012}buildPulse(){this.buildFx=1.2}showLobby(){this.mode="lobby",wt.jet(!1)}startRun(t){this.setRunWorld(t.world),this.setPlayer(t.skin),this.opts=t,this.track.reset(),this.particles.clear(),this.projectiles.forEach(e=>this.scene.remove(e.mesh)),this.projectiles=[],t.tutorial&&this.track.startTutorial(),this.track.goldLine(1,10,10,2),this.track.nextD=46,this.run={d:0,speed:Ce.startSpeed,x:0,lane:1,targetLane:1,prevLane:1,y:0,vy:0,grounded:!0,slideT:0,state:"intro",introT:1.4,invuln:0,stumbleT:0,score:0,gold:0,gems:0,time:0,mult:t.mult,pu:{magnet:0,shield:0,jet:0,double:0},puMax:{...t.durations},jetY:0,flying:!1,rocketTo:0,revives:0,bossNext:tn.firstAt,nextSkyD:0,crashT:0,phase:0,onRoof:!1,headstartWindow:t.headstarts>0?4.5:0,vaults:0,stats:{gold:0,dist:0,jumps:0,slides:0,pu_magnet:0,pu_jet:0,pu_shield:0,pu_double:0,bosses:0,emps:0,roofs:0,gemsPicked:0,lanes:0}},this.boss=null,this.van.visible=!1,this.marker.visible=!1,this.thief.visible=!0,this.thief.position.set(0,0,-7),this.thief.rotation.y=Math.PI,this.thiefT=0,this.player.position.set(0,0,0),this.player.rotation.set(0,0,0),this.mode="run",this.paused=!1,this.timeScale=1,this.camera.clearViewOffset(),this.viewOff={x:0,y:0},this.camPos=new P(0,6,12),this.camLook=new P(0,1.5,-8),this.hooks.event("thief",{key:"thiefTaunt"}),wt.play("laugh"),this.run.headstartWindow&&this.hooks.event("headstartOffer",{show:!0})}useHeadstart(){let t=this.run;return!t||t.state==="crashed"||t.rocketTo?!1:(t.rocketTo=t.d+bu,t.flying=!0,t.headstartWindow=0,t.state="running",this.hooks.event("headstartOffer",{show:!1}),this.hooks.event("toast",{key:"useHeadstart",kind:"gold"}),wt.play("whoosh"),wt.jet(!0),this.player.userData.jet.visible=!0,t.nextSkyD=t.d+12,!0)}pause(){this.mode==="run"&&!this.paused&&(this.paused=!0,wt.jet(!1))}resume(){this.mode==="run"&&this.paused&&(this.paused=!1,this.last=performance.now(),this.run.flying&&wt.jet(!0))}revive(){let t=this.run;t.revives++,t.state="running",t.invuln=3,t.vy=0,t.y=Math.max(0,this.track.floorAt(t.x,t.d,3,Ce.playerHalfWidth)),t.grounded=!0,t.stumbleT=0,this.track.clearRange(t.d-4,t.d+45),this.player.rotation.set(0,0,0),this.paused=!1,this.last=performance.now(),wt.play("powerup")}finishRun(){let t=this.run;return t.state="over",wt.jet(!1),t.stats.dist=Math.floor(t.d),{score:Math.floor(t.score),dist:Math.floor(t.d),gold:t.gold,gems:t.gems,stats:t.stats,revives:t.revives,vaults:t.vaults}}input(t){let e=this.run;if(!(this.mode!=="run"||this.paused||!e||e.state==="crashed"||e.state==="over")){if(e.state==="intro"&&(e.state="running"),t==="left"||t==="right"){let n=t==="left"?-1:1,s=Math.max(0,Math.min(2,e.targetLane+n));s!==e.targetLane&&(e.prevLane=e.targetLane,e.targetLane=s,e.stats.lanes++,wt.play("lane"))}else if(t==="up"){if(e.flying)return;e.grounded&&(e.vy=Ce.jumpVelocity,e.grounded=!1,e.slideT=0,e.stats.jumps++,wt.play("jump"))}else if(t==="down"){if(e.flying)return;e.grounded||(e.vy=Math.min(e.vy,Ce.fastFall)),e.slideT=Ce.slideTime,e.stats.slides++,wt.play("slide")}}}frame(t){requestAnimationFrame(this._frame);let e=Math.min(.05,(t-this.last)/1e3);this.last=t,!document.hidden&&(this.time+=e,this.mode==="run"?(this.paused||this.updateRun(e*this.timeScale,e),this.renderer.render(this.scene,this.camera)):(this.updateLobby(e),this.renderer.render(this.lobby,this.camera)))}updateLobby(t){let e=this.time,n=this.camera.aspect<1,s=u=>{let d=tf.degToRad(this.camera.fov),f=2*Math.atan(Math.tan(d/2)*this.camera.aspect);return u/2/Math.tan(f/2)},r,a;if(this.view==="char"){let u=Math.max(5.5,s(3.6));r=new P(0,2.2,6.4+u),a=new P(0,1.25,6.4)}else if(this.view==="house"){let u=Math.max(12,s(14));r=new P(2.5,6,u),a=new P(0,2.2,0)}else{let u=Math.max(9,s(8.2));r=new P(0,3.2,6.4+u*.8),a=new P(0,n?1.9:2,3.2)}let o=this.view==="char"||this.view==="house",l=window.innerWidth,c=window.innerHeight,h=o?n?{x:0,y:.27*c}:{x:(document.documentElement.dir==="rtl"?-.24:.24)*l,y:0}:{x:0,y:n?0:.16*c};this.viewOff=this.viewOff||{x:0,y:0},this.viewOff.x=Ri(this.viewOff.x,h.x,6,t),this.viewOff.y=Ri(this.viewOff.y,h.y,6,t),Math.abs(this.viewOff.x)+Math.abs(this.viewOff.y)>.5?this.camera.setViewOffset(l,c,this.viewOff.x,this.viewOff.y,l,c):this.camera.view&&this.camera.view.enabled&&this.camera.clearViewOffset(),this.lobbyCamPos||(this.lobbyCamPos=r.clone(),this.lobbyCamLook=a.clone()),this.lobbyCamPos.lerp(r,1-Math.exp(-4*t)),this.lobbyCamLook.lerp(a,1-Math.exp(-4*t)),this.camera.position.copy(this.lobbyCamPos),this.camera.position.x+=Math.sin(e*.3)*.25,this.camera.lookAt(this.lobbyCamLook),this.camera.fov=55,this.camera.updateProjectionMatrix(),this.lobbyRot+=this.lobbyRotV,this.lobbyRotV*=Math.pow(.04,t),Math.abs(this.lobbyRotV)<.002&&(this.lobbyRot=Ri(this.lobbyRot,0,1.5,t)),this.lobbyChar&&(this.lobbyChar.rotation.y=Math.PI+this.lobbyRot,this.waveT>0?(this.waveT-=t,Dn(this.lobbyChar,"wave",0,e)):Dn(this.lobbyChar,"idle",0,e)),this.lobbyThief&&(Dn(this.lobbyThief,e%7<1.2?"wave":"idle",0,e),this.lobbyThief.position.x=-5.2+Math.sin(e*.5)*.3),this.buildFx>0?(this.buildFx-=t,this.house.scale.setScalar(1+Math.sin(this.buildFx*14)*.03*this.buildFx)):this.house&&this.house.scale.setScalar(1),this.house&&this.house.traverse(u=>{u.userData.flag&&(u.rotation.y=Math.sin(e*3)*.3)})}updateRun(t,e){let n=this.run,s=this.player;if(n.time+=t,this.particles.update(t),n.state==="crashed"){n.crashT+=e,Dn(s,"fall",0,this.time),this._updateCamera(e,!0),n.crashT>.9&&!n.crashNotified&&(n.crashNotified=!0,this.hooks.onCrash({revives:n.revives}));return}n.headstartWindow>0&&(n.headstartWindow-=e,n.headstartWindow<=0&&this.hooks.event("headstartOffer",{show:!1}));let r=Ce.startSpeed+Ce.maxSpeedGain*(1-Math.exp(-n.d/Ce.speedRamp)),a=n.state==="intro"?r*.75:r;n.rocketTo&&(a=r*2.3),n.speed=Ri(n.speed,a,3,t);let o=n.speed*t;n.prevD=n.d,n.d+=o,n.phase+=o*.95,n.state==="intro"&&(n.introT-=t,n.introT<=0&&(n.state="running")),n.score+=o*tl.perMetre*n.mult*(1+(this.opts.scoreBonus||0));let l=dn[n.targetLane],c=Ce.laneSpeed*t,h=n.x;Math.abs(l-n.x)<=c?n.x=l:n.x+=Math.sign(l-n.x)*c,Math.abs(n.x-l)<.01&&(n.lane=n.targetLane);for(let _ of Ks)n.pu[_]>0&&(n.pu[_]-=t,n.pu[_]<=0&&(n.pu[_]=0,_==="jet"&&!n.rocketTo&&this._endFlight()));n.rocketTo&&n.d>=n.rocketTo&&(n.rocketTo=0,n.pu.jet<=0&&this._endFlight()),n.invuln>0&&(n.invuln-=t),n.stumbleT>0&&(n.stumbleT-=t);let u=n.y;if(n.flying)n.y=Ri(n.y,Ce.jetHeight,3,t),n.vy=0,n.grounded=!1,n.nextSkyD<n.d+110&&(n.nextSkyD+=this.track.skyGold(n.nextSkyD,Ce.jetHeight+.6)+5);else{n.slideT>0&&(n.slideT-=t),n.vy-=Ce.gravity*t,n.y+=n.vy*t;let _=n.grounded?u+.35:u+.05,m=this.track.floorAt(n.x,n.d,_,Ce.playerHalfWidth);n.y<=m&&n.vy>.01?n.y=m:n.y<=m?(!n.grounded&&n.vy<-6&&(wt.play("land"),this.particles.burst(Ai.set(n.x,m+.1,-n.d),16777215,5,3,.5,.35,2)),m>2&&!n.onRoof&&n.stats.roofs++,n.y=m,n.vy=0,n.grounded=!0,n.onRoof=m>2):n.y>m+.02&&(n.grounded=!1),n.grounded&&m<.01&&(n.onRoof=!1)}if(this._tutorial(n),n.flying||this._collide(n,h),n.state==="crashed")return;this._pickups(n,t);let d=Math.min(1,n.d/4200);this.track.spawnRows(n.d,n.speed,d,{jet:n.flying}),this.track.update(t,n.d,this.time),!this.boss&&n.d>=n.bossNext&&!n.flying&&this._startBoss(),this.boss&&this._updateBoss(t),this._updateProjectiles(t),this._updateThief(t),s.position.set(n.x,n.y,-n.d);let f=(l-n.x)*-.08;s.rotation.set(0,0,f);let g="run";n.flying?g="fly":n.slideT>0?g="slide":n.grounded||(g="jump"),Dn(s,g,n.phase,this.time),s.userData.jet.visible=n.flying,s.userData.shadow.position.y=n.grounded?.02:this.track.floorAt(n.x,n.d,n.y,.3)-n.y+.02,s.userData.shadow.visible=!n.flying,s.visible=n.invuln>0&&!n.flying?Math.floor(this.time*14)%2===0:!0,this.shieldBubble.visible=n.pu.shield>0,this.shieldBubble.scale.setScalar(1+Math.sin(this.time*6)*.04),this.magnetRing.visible=n.pu.magnet>0,this.magnetRing.rotation.z+=t*5,this.magnetRing.scale.setScalar(1+Math.sin(this.time*8)*.15),n.pu.double>0&&Math.random()<.3&&this.particles.burst(Ai.set(n.x,n.y+1.2,-n.d),11766015,1,1.5,.35,.4,-1),this.sun.position.set(n.x+6,18,-n.d+10),this.sun.target.position.set(n.x,0,-n.d-6),this.sky&&this.sky.position.set(0,0,-n.d),this.snow&&this._updateSnow(t,n),this._updateCamera(e,!1),n.stats.dist=Math.floor(n.d),this.hooks.onTick(n)}_endFlight(){let t=this.run;t.flying&&(t.flying=!1,t.vy=-2,t.invuln=Math.max(t.invuln,1.4),this.track.clearRange(t.d-2,t.d+38),this.track.nextD=Math.max(this.track.nextD,t.d+40),wt.jet(!1))}_tutorial(t){let e=this.track.tutorial;if(!e||!e.length){this.timeScale!==1&&(this.timeScale=1);return}let n=e[0],s=n.d-t.d,r=!1;n.kind==="jump"&&(r=!t.grounded&&t.y>.2),n.kind==="slide"&&(r=t.slideT>0),n.kind==="lane"&&(r=t.targetLane===2);let a=Math.max(3.5,t.speed*.36+1.2);n.done||(r&&s<a+2?(n.done=!0,this.timeScale=1,this.hooks.event("tutorial",{kind:null})):s<16&&s>-1&&(this.hooks.event("tutorial",{kind:n.kind}),this.timeScale=s<a?.1:1)),s<-3&&(e.shift(),this.timeScale=1,this.hooks.event("tutorial",{kind:null}),e.length||this.hooks.event("tutorialDone",{}))}_collide(t,e){let n=this.track,s=Ce.playerHalfWidth,r=t.slideT>0?Ce.slideHeight:Ce.standHeight,a=.3;for(let o of n.obstacles){if(o.d0-t.d>2||t.d-o.d1>2||Math.abs(t.x-o.x)>=o.hw+s||!(t.d+a>o.d0&&t.d-a<o.d1)||t.y>=o.y1-.3||t.y+r<=o.y0||t.invuln>0)continue;let l=t.prevD+a>o.d0&&t.prevD-a<o.d1,c=Math.abs(e-o.x)<o.hw+s;if(l&&!c&&o.family!=="bomb"){this._stumble(t,o);continue}if(this._hit(t,o),t.state==="crashed")return}}_stumble(t,e){if(t.stumbleT>0&&t.invuln<=0){this._hit(t,e,!0);return}t.targetLane=t.prevLane!==t.targetLane?t.prevLane:t.lane,t.stumbleT=3.5,t.invuln=.35,this.shake=.35,wt.play("stumble"),this.hooks.event("toast",{key:"stumble",kind:"warn"}),this.hooks.vibrate(40)}_hit(t,e,n=!1){if(e.tutorial){this.track.removeObstacle(e),this.shake=.3,wt.play("stumble");return}if(t.pu.shield>0&&!n){t.pu.shield=0,t.invuln=1.2,this.particles.burst(Ai.set(e.x,1.2,-(e.d0+.5)),3786495,16,7,.8,.6),this.track.removeObstacle(e),this.shake=.5,wt.play("shieldBreak"),this.hooks.event("toast",{key:"shieldBroken",kind:"info"}),this.hooks.vibrate(60);return}e.family==="bomb"&&(this.particles.burst(Ai.set(e.x,1,-e.d0),16742912,22,8,1.2,.7),wt.play("explode")),t.state="crashed",t.crashT=0,t.crashNotified=!1,this.shake=.8,wt.play("crash"),wt.jet(!1),this.hooks.vibrate(200),this.hooks.event("crash",{}),this.particles.burst(Ai.set(t.x,t.y+1,-t.d),16777215,14,6,.7,.5)}_pickups(t,e){let n=this.track,s=t.slideT>0?Ce.slideHeight:Ce.standHeight,r=t.pu.magnet>0,a=Vn.magnet.radius,o=(t.pu.double>0?2:1)*(this.opts.doubler?2:1),l=t.y+.9;for(let c of n.gold){if(c.dead)continue;let h=c.d-t.d;if(!(h>14||h<-3)){if(r&&!c.magnet&&Math.abs(h)<a*1.4&&Math.hypot(c.x-t.x,c.y-l,h)<a*1.3&&(c.magnet=!0),c.magnet){let u=1-Math.exp(-14*e);c.x=$o(c.x,t.x,u),c.y=$o(c.y,l,u),c.d=$o(c.d,t.d+.3,u)+t.speed*e}Math.abs(c.x-t.x)<.85&&Math.abs(h)<.95&&c.y>t.y-.4&&c.y<t.y+s+.5&&(c.dead=!0,t.gold+=o,t.stats.gold+=o,t.score+=tl.perGold*t.mult*o,wt.play("coin"),Math.random()<.5&&this.particles.burst(Ai.set(c.x,c.y,-c.d),16765773,3,3,.45,.35,2))}}for(let c of[...n.pickups]){let h=c.d-t.d;if(Math.abs(h)>1.2||Math.abs(c.x-t.x)>1)continue;let u=c.type==="emp"?0:c.y-.6;u>t.y+s+.3||u+1.2<t.y||(n.removePickup(c),this._collect(t,c))}}_collect(t,e){let n=Ai.set(e.x,e.y,-e.d);if(e.type==="gem"){t.gems+=1,t.stats.gemsPicked++,wt.play("gem"),this.particles.burst(n,3725823,10,4,.6,.5),this.hooks.event("toast",{text:"+1",icon:"gems",kind:"gem"});return}if(e.type==="vault"){let r=this.hooks.foundVault();wt.play(r?"reward":"error"),this.particles.burst(n,13621475,12,5,.6,.6),r&&t.vaults++,this.hooks.event("toast",{key:r?"vaultFound":"slotsFull",kind:r?"gold":"warn"});return}if(e.type==="emp"){this._kickEmp(t,e);return}let s=t.puMax[e.type];t.pu[e.type]=s,t.stats["pu_"+e.type]++,wt.play("powerup"),this.particles.burst(n,Vn[e.type].color,14,5,.7,.6),this.hooks.event("powerup",{type:e.type}),e.type==="jet"&&!t.flying&&(t.flying=!0,t.nextSkyD=t.d+10,wt.jet(!0))}_updateThief(t){let e=this.thief;if(!e.visible)return;let n=this.run;this.thiefT+=t;let s=this.thiefT;if(s<1.2)e.position.set(0,0,-(n.d+7+s*2)),e.rotation.y=0,Dn(e,"wave",0,this.time),e.rotation.y=Math.PI*(s<.6?1:1-(s-.6)/.6);else if(s<6.5){e.rotation.y=0;let r=9+(s-1.2)*3.2;e.position.set(Math.sin(s*1.3)*1.6,0,-(n.d+r)),Dn(e,"run",s*16,this.time)}else s<8.5?(e.userData.jet.visible=!0,e.position.y+=t*9,e.position.z-=t*(n.speed+18),Dn(e,"fly",s*10,this.time),this.thiefEscapedMsg||(this.thiefEscapedMsg=!0,this.hooks.event("thief",{key:"thiefEscape"}),wt.play("laugh"))):(e.visible=!1,e.userData.jet.visible=!1,this.thiefEscapedMsg=!1)}_startBoss(){let t=this.run;this.boss={state:"enter",t:0,hits:0,ahead:95,x:0,lane:1,laneT:2.4,throwT:2.6,throws:0,tele:null,hitFlash:0},this.track.spawnPaused=!0,this.track.clearRange(t.d+25,t.d+400,!0),this.track.gold.forEach(e=>{e.d>t.d+25&&(e.dead=!0)}),this.van.visible=!0,this.van.rotation.set(0,0,0),this.van.userData.thief.position.set(0,2.62,.6),this.hooks.event("boss",{phase:"start",hits:0,max:tn.hits}),this.hooks.event("toast",{key:"bossIncoming",kind:"warn",big:!0}),wt.play("alarm")}_updateBoss(t){let e=this.boss,n=this.run,s=this.van;if(e.t+=t,e.state==="enter")e.ahead=Ri(e.ahead,tn.gap,1.4,t),e.ahead<tn.gap+1.5&&(e.state="fight",e.t=0,this.hooks.event("toast",{key:"bossHint",kind:"info"}));else if(e.state==="fight"){if(e.ahead=tn.gap+Math.sin(e.t*.8)*2,e.laneT-=t,e.laneT<=0&&(e.lane=Math.floor(Math.random()*3),e.laneT=1.8+Math.random()*1.4),e.throwT-=t,e.throwT<=.7&&!e.tele){let a=Math.random()<.55?n.targetLane:Math.floor(Math.random()*3);e.tele={lane:a}}if(e.tele&&(this.marker.visible=Math.floor(this.time*10)%2===0,this.marker.position.set(dn[e.tele.lane],.06,-(n.d+e.ahead-6))),e.throwT<=0&&e.tele){let a=n.d+e.ahead-3,o=e.tele.lane,l=e.throws%3===2?"emp":Math.random()<.5?"bomb":"low";if(l==="emp"){let c=this.track.addPickup("emp",o,a,0);c.mesh.position.y=0}else l==="bomb"?this.track.addObstacle("bomb",o,a,{bombKind:"red",boss:!0}):this.track.addObstacle("low",o,a,{boss:!0});if(l!=="emp"&&Math.random()<.35){let c=(o+1+Math.floor(Math.random()*2))%3;this.track.addObstacle("low",c,a+1,{boss:!0})}e.throws++,e.throwT=Math.max(1.05,1.75-e.throws*.04),e.tele=null,this.marker.visible=!1,wt.play("drop")}e.t>tn.maxTime&&(e.state="escape",e.t=0,this.marker.visible=!1,this.hooks.event("toast",{key:"bossEscaped",kind:"info"}),this.hooks.event("boss",{phase:"end"}))}else if(e.state==="escape")e.ahead+=t*(8+e.t*30),e.ahead>160&&this._endBoss();else if(e.state==="defeat"){e.ahead+=t*4,s.rotation.z=Math.min(.5,e.t*.6);let a=s.userData.thief;a.position.y+=t*8,a.position.z+=t*3,Dn(a,"fall",0,this.time),Math.random()<.5&&this.particles.burst(Ai.set(e.x+(Math.random()-.5)*2,2+Math.random()*2,-(n.d+e.ahead)),Math.random()<.5?16742912:16765773,3,6,1.2,.6),e.t>2.2&&this._endBoss()}e.x=Ri(e.x,dn[e.lane],2.2,t),s.position.set(e.x,0,-(n.d+e.ahead)),s.rotation.y=(dn[e.lane]-e.x)*.06,e.state!=="defeat"&&Dn(s.userData.thief,e.tele?"wave":"idle",0,this.time);let r=s.userData.light;r.visible=Math.floor(this.time*(e.tele?12:4))%2===0,e.hitFlash>0?(e.hitFlash-=t,s.scale.setScalar(1+e.hitFlash*.25)):s.scale.setScalar(1)}_kickEmp(t,e){if(!this.boss||this.boss.state!=="fight")return;t.stats.emps++,wt.play("kick");let n=$r("emp");n.position.set(t.x,.5,-t.d),this.scene.add(n),this.projectiles.push({mesh:n,t:0,from:new P(t.x,.6,-t.d)})}_updateProjectiles(t){let e=this.boss;for(let n of[...this.projectiles]){n.t+=t/.5;let s=e?new P(e.x,1.8,-(this.run.d+e.ahead)):n.from,r=Math.min(1,n.t);n.mesh.position.lerpVectors(n.from,s,r),n.mesh.position.y+=Math.sin(r*Math.PI)*3,n.from.z-=this.run.speed*t,n.mesh.rotation.x+=t*12,r>=1&&(this.scene.remove(n.mesh),this.projectiles.splice(this.projectiles.indexOf(n),1),e&&e.state==="fight"&&(e.hits++,e.hitFlash=.4,this.shake=.4,wt.play("explode"),this.particles.burst(s,3123455,20,8,1.1,.7),this.hooks.event("boss",{phase:"hit",hits:e.hits,max:tn.hits}),this.hooks.vibrate(50),e.hits>=tn.hits&&this._defeatBoss()))}}_defeatBoss(){let t=this.boss,e=this.run;t.state="defeat",t.t=0,this.marker.visible=!1,e.stats.bosses++,e.gold+=tn.rewardGold,e.gems+=tn.rewardGems,e.score+=1e3*e.mult,this.track.clearRange(e.d,e.d+200,!0),wt.play("fanfare"),this.hooks.event("boss",{phase:"defeat",gold:tn.rewardGold,gems:tn.rewardGems}),this.hooks.event("toast",{key:"bossDefeated",kind:"gold",big:!0})}_endBoss(){let t=this.run;this.van.visible=!1,this.marker.visible=!1,this.boss=null,this.track.spawnPaused=!1,this.track.nextD=Math.max(this.track.nextD,t.d+45),t.bossNext=t.d+tn.every,this.hooks.event("boss",{phase:"end"})}_updateCamera(t,e){let n=this.run,s=this.camera.aspect<.8,r=s?8.6:7.4,a=s?4.9:4,o=n.flying?2.5:0,l=new P(n.x*.55,a+n.y*.62+o,-n.d+r),c=new P(n.x*.4,1+n.y*.7,-n.d-10);if(e&&(l.set(n.x*.6+2.5,4.5+n.y,-n.d+6.5),c.set(n.x,n.y+.6,-n.d)),this.camPos.lerp(l,1-Math.exp(-(e?2:9)*t)),this.camLook.lerp(c,1-Math.exp(-10*t)),this.camera.position.copy(this.camPos),this.shake>0){this.shake=Math.max(0,this.shake-t*1.6);let u=this.shake*.35;this.camera.position.x+=(Math.random()-.5)*u,this.camera.position.y+=(Math.random()-.5)*u}this.camera.lookAt(this.camLook);let h=(s?66:58)+Math.min(8,(n.speed-Ce.startSpeed)*.35)+(n.rocketTo?8:0);Math.abs(this.camera.fov-h)>.05&&(this.camera.fov=Ri(this.camera.fov,h,3,t),this.camera.updateProjectionMatrix())}_updateSnow(t,e){let n=this.snow.geometry.attributes.position,s=n.array;for(let r=0;r<s.length;r+=3)s[r+1]-=t*(2+r%7*.3),s[r]+=Math.sin(this.time+r)*t*.3,(s[r+1]<0||s[r+2]>-e.d+10)&&(s[r+1]=14+Math.random()*6,s[r+2]=-e.d-Math.random()*60,s[r]=e.x+(Math.random()-.5)*40);n.needsUpdate=!0}};var $t=(i,t="0 0 64 64")=>`<svg class="ico" viewBox="${t}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">${i}</svg>`,su={gold:$t('<path d="M10 44 18 24h28l8 20z" fill="#ffc21a" stroke="#a86a00" stroke-width="3" stroke-linejoin="round"/><path d="M20 28h24l3 8H17z" fill="#ffe27a"/><path d="M14 44h36" stroke="#a86a00" stroke-width="3"/>'),gems:$t('<path d="M32 6 54 24 32 58 10 24z" fill="#38d9ff" stroke="#0a5a8a" stroke-width="3" stroke-linejoin="round"/><path d="M10 24h44M32 6l-9 18 9 34 9-34z" fill="none" stroke="#0a5a8a" stroke-width="2.5" stroke-linejoin="round"/><path d="M23 24l9-18" stroke="#c9f6ff" stroke-width="3"/>'),batteries:$t('<rect x="14" y="14" width="36" height="44" rx="6" fill="#3ddc84" stroke="#136b3c" stroke-width="3"/><rect x="24" y="6" width="16" height="9" rx="2" fill="#136b3c"/><path d="M35 22 25 38h8l-4 14 12-18h-8l4-12z" fill="#fff9c4" stroke="#136b3c" stroke-width="2" stroke-linejoin="round"/>'),headstart:$t('<path d="M32 4c10 8 14 20 12 32H20C18 24 22 12 32 4z" fill="#ff5a5a" stroke="#7a1010" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="22" r="6" fill="#9cf5ff" stroke="#7a1010" stroke-width="2.5"/><path d="M20 36 12 46l10-2M44 36l8 10-10-2" fill="#ffb020" stroke="#7a1010" stroke-width="3" stroke-linejoin="round"/><path d="M26 40c0 8 6 16 6 16s6-8 6-16z" fill="#ffd34d"/>'),magnet:$t('<path d="M12 10h12v22a8 8 0 0 0 16 0V10h12v22a20 20 0 0 1-40 0z" fill="#ff3d5a" stroke="#7a0a1c" stroke-width="3" stroke-linejoin="round"/><path d="M12 10h12v9H12zM40 10h12v9H40z" fill="#e8eef5" stroke="#7a0a1c" stroke-width="3"/>'),shield:$t('<path d="M10 38c0-16 10-28 24-28s20 10 20 24v6H34v8H16z" fill="#39c6ff" stroke="#0b3b66" stroke-width="3" stroke-linejoin="round"/><path d="M34 10v30" stroke="#fff" stroke-width="5"/><rect x="38" y="30" width="18" height="7" rx="3" fill="#14213d"/>'),jet:$t('<path d="M8 34 56 18l-4 8-14 6 6 16-6 2-10-14-12 4-2 8-4 1V34z" fill="#ffb020" stroke="#7a4200" stroke-width="3" stroke-linejoin="round"/><circle cx="46" cy="24" r="3" fill="#39c6ff"/>'),double:$t('<circle cx="32" cy="32" r="26" fill="#9b5cff" stroke="#3b1a7a" stroke-width="3"/><text x="32" y="42" font-family="Arial Black,Arial" font-weight="900" font-size="26" text-anchor="middle" fill="#fff">x2</text>'),vault:$t('<rect x="8" y="10" width="48" height="44" rx="6" fill="#9aa4b2" stroke="#3a4250" stroke-width="3"/><circle cx="32" cy="32" r="12" fill="#4b5563" stroke="#3a4250" stroke-width="3"/><path d="M32 22v20M22 32h20" stroke="#ffc21a" stroke-width="3"/><rect x="12" y="54" width="8" height="5" fill="#3a4250"/><rect x="44" y="54" width="8" height="5" fill="#3a4250"/>'),vault_wood:$t('<rect x="8" y="12" width="48" height="42" rx="5" fill="#c98b3c" stroke="#6b3e12" stroke-width="3"/><path d="M8 26h48M8 40h48" stroke="#8a5a2b" stroke-width="3"/><rect x="26" y="28" width="12" height="12" rx="2" fill="#ffc21a" stroke="#6b3e12" stroke-width="2.5"/>'),vault_steel:$t('<rect x="8" y="10" width="48" height="44" rx="6" fill="#b7c2d0" stroke="#3a4250" stroke-width="3"/><circle cx="32" cy="32" r="12" fill="#5d6b7c" stroke="#3a4250" stroke-width="3"/><path d="M32 22v20M22 32h20" stroke="#e8eef5" stroke-width="3"/>'),vault_diamond:$t('<rect x="8" y="10" width="48" height="44" rx="6" fill="#4dd7ff" stroke="#0a4a7a" stroke-width="3"/><path d="M32 18 44 30 32 46 20 30z" fill="#e6fbff" stroke="#0a4a7a" stroke-width="3" stroke-linejoin="round"/>'),daily:$t('<rect x="8" y="12" width="48" height="44" rx="6" fill="#fff" stroke="#1f3a8a" stroke-width="3"/><path d="M8 24h48" stroke="#1f3a8a" stroke-width="3"/><rect x="8" y="12" width="48" height="12" rx="6" fill="#ff5a5a" stroke="#1f3a8a" stroke-width="3"/><path d="M20 6v12M44 6v12" stroke="#1f3a8a" stroke-width="4" stroke-linecap="round"/><path d="m24 40 6 6 12-14" fill="none" stroke="#3ddc84" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>'),missions:$t('<rect x="12" y="8" width="40" height="50" rx="5" fill="#fff" stroke="#1f3a8a" stroke-width="3"/><rect x="22" y="4" width="20" height="9" rx="3" fill="#ffc21a" stroke="#1f3a8a" stroke-width="3"/><path d="m18 24 4 4 7-8M18 38l4 4 7-8" fill="none" stroke="#3ddc84" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M34 26h12M34 40h12" stroke="#1f3a8a" stroke-width="4" stroke-linecap="round"/>'),wheel:$t('<circle cx="32" cy="32" r="26" fill="#ffc21a" stroke="#7a4200" stroke-width="3"/><path d="M32 6v52M6 32h52M14 14l36 36M50 14 14 50" stroke="#ff5a5a" stroke-width="5"/><circle cx="32" cy="32" r="7" fill="#fff" stroke="#7a4200" stroke-width="3"/>'),gift:$t('<rect x="8" y="26" width="48" height="30" rx="4" fill="#ff5a5a" stroke="#7a1010" stroke-width="3"/><rect x="5" y="18" width="54" height="11" rx="3" fill="#ff7a7a" stroke="#7a1010" stroke-width="3"/><path d="M32 18v38" stroke="#ffc21a" stroke-width="7"/><path d="M32 18c-6-12-18-10-14-2 2 3 8 3 14 2zm0 0c6-12 18-10 14-2-2 3-8 3-14 2z" fill="#ffc21a" stroke="#7a4200" stroke-width="2.5"/>'),shop:$t('<path d="M6 10h8l6 30h30l6-22H18" fill="none" stroke="#1f3a8a" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/><path d="M19 18h37l-6 22H23z" fill="#3ddc84"/><circle cx="24" cy="50" r="5" fill="#1f3a8a"/><circle cx="46" cy="50" r="5" fill="#1f3a8a"/>'),offer:$t('<path d="M32 4l7 10 12-2-2 12 10 8-10 8 2 12-12-2-7 10-7-10-12 2 2-12-10-8 10-8-2-12 12 2z" fill="#ff3df2" stroke="#6b0a5c" stroke-width="3" stroke-linejoin="round"/><text x="32" y="40" font-family="Arial Black,Arial" font-weight="900" font-size="18" text-anchor="middle" fill="#fff">%</text>'),club:$t('<path d="M8 22 20 32 32 12l12 20 12-10-6 30H14z" fill="#ffc21a" stroke="#7a4200" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="40" r="5" fill="#38d9ff"/>'),upgrades:$t('<path d="M32 6 52 26H40v28H24V26H12z" fill="#3ddc84" stroke="#136b3c" stroke-width="3" stroke-linejoin="round"/>'),characters:$t('<rect x="14" y="12" width="36" height="28" rx="10" fill="#f5f8ff" stroke="#1f3a8a" stroke-width="3"/><rect x="19" y="18" width="26" height="14" rx="5" fill="#14213d"/><rect x="23" y="21" width="6" height="8" rx="2" fill="#4dfcff"/><rect x="35" y="21" width="6" height="8" rx="2" fill="#4dfcff"/><path d="M32 12V5" stroke="#1f3a8a" stroke-width="3"/><circle cx="32" cy="5" r="3" fill="#18b7ff"/><rect x="18" y="42" width="28" height="16" rx="8" fill="#18b7ff" stroke="#1f3a8a" stroke-width="3"/>'),build:$t('<path d="M8 30 32 10l24 20v26H8z" fill="#fff1d6" stroke="#7a3b1e" stroke-width="3" stroke-linejoin="round"/><path d="M4 32 32 8l28 24" fill="none" stroke="#e9573f" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/><rect x="26" y="38" width="12" height="18" fill="#7a4f2a"/><path d="m40 16 12 12-4 4-12-12z" fill="#ffc21a" stroke="#7a4200" stroke-width="2"/>'),settings:$t('<path d="M27 6h10l2 7 6 3 7-3 5 8-5 6v6l5 6-5 8-7-3-6 3-2 7H27l-2-7-6-3-7 3-5-8 5-6v-6l-5-6 5-8 7 3 6-3z" fill="#e8eef5" stroke="#1f3a8a" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="32" r="9" fill="#1f3a8a"/>'),pause:$t('<rect x="16" y="12" width="11" height="40" rx="3" fill="#fff"/><rect x="37" y="12" width="11" height="40" rx="3" fill="#fff"/>'),play:$t('<path d="M20 10 52 32 20 54z" fill="#fff" stroke="#136b3c" stroke-width="3" stroke-linejoin="round"/>'),close:$t('<path d="M16 16l32 32M48 16 16 48" stroke="#fff" stroke-width="8" stroke-linecap="round"/>'),check:$t('<path d="m12 34 13 13 27-30" fill="none" stroke="#3ddc84" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>'),lock:$t('<rect x="12" y="28" width="40" height="30" rx="5" fill="#ffc21a" stroke="#7a4200" stroke-width="3"/><path d="M20 28v-8a12 12 0 0 1 24 0v8" fill="none" stroke="#7a4200" stroke-width="5"/><circle cx="32" cy="42" r="4" fill="#7a4200"/>'),star:$t('<path d="M32 4l8 18 19 2-14 13 4 19-17-10-17 10 4-19L5 24l19-2z" fill="#ffc21a" stroke="#7a4200" stroke-width="3" stroke-linejoin="round"/>'),trophy:$t('<path d="M18 8h28v14a14 14 0 0 1-28 0z" fill="#ffc21a" stroke="#7a4200" stroke-width="3"/><path d="M18 14H8c0 10 6 14 12 14M46 14h10c0 10-6 14-12 14" fill="none" stroke="#7a4200" stroke-width="3"/><path d="M28 36h8v10h-8zM20 46h24v10H20z" fill="#ffc21a" stroke="#7a4200" stroke-width="3"/>'),globe:$t('<circle cx="32" cy="32" r="24" fill="#38d9ff" stroke="#0a4a7a" stroke-width="3"/><path d="M8 32h48M32 8c-10 12-10 36 0 48M32 8c10 12 10 36 0 48" fill="none" stroke="#0a4a7a" stroke-width="3"/>'),arrowL:$t('<path d="M40 10 18 32l22 22" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>'),arrowR:$t('<path d="M24 10l22 22-22 22" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>'),map:$t('<path d="M6 14l16-6 20 6 16-6v42l-16 6-20-6-16 6z" fill="#7ccf5a" stroke="#1f5a1a" stroke-width="3" stroke-linejoin="round"/><path d="M22 8v42M42 14v42" stroke="#1f5a1a" stroke-width="3"/><circle cx="32" cy="28" r="5" fill="#ff5a5a"/>'),plus:$t('<circle cx="32" cy="32" r="26" fill="#3ddc84" stroke="#136b3c" stroke-width="3"/><path d="M32 18v28M18 32h28" stroke="#fff" stroke-width="7" stroke-linecap="round"/>'),swipe:$t('<path d="M24 58V30a5 5 0 0 1 10 0v12-6a5 5 0 0 1 10 0v6-3a5 5 0 0 1 10 0v13c0 6-4 10-10 10H30" fill="#fff" stroke="#1f3a8a" stroke-width="3" stroke-linejoin="round"/>'),robotHead:$t('<rect x="8" y="14" width="48" height="38" rx="14" fill="#f5f8ff" stroke="#0b1a4a" stroke-width="3"/><rect x="14" y="22" width="36" height="20" rx="7" fill="#14213d"/><rect x="20" y="26" width="8" height="11" rx="3" fill="#4dfcff"/><rect x="36" y="26" width="8" height="11" rx="3" fill="#4dfcff"/><path d="M32 14V6" stroke="#0b1a4a" stroke-width="3"/><circle cx="32" cy="6" r="4" fill="#18b7ff" stroke="#0b1a4a" stroke-width="2"/><rect x="2" y="26" width="7" height="14" rx="3" fill="#18b7ff" stroke="#0b1a4a" stroke-width="2.5"/><rect x="55" y="26" width="7" height="14" rx="3" fill="#18b7ff" stroke="#0b1a4a" stroke-width="2.5"/>'),info:$t('<circle cx="32" cy="32" r="26" fill="#18b7ff" stroke="#0b3b66" stroke-width="3"/><path d="M32 28v18" stroke="#fff" stroke-width="7" stroke-linecap="round"/><circle cx="32" cy="18" r="4.5" fill="#fff"/>'),sound:$t('<path d="M10 24h10l14-12v40L20 40H10z" fill="#fff" stroke="#1f3a8a" stroke-width="3" stroke-linejoin="round"/><path d="M42 22c4 6 4 14 0 20M48 16c8 9 8 23 0 32" fill="none" stroke="#1f3a8a" stroke-width="4" stroke-linecap="round"/>'),music:$t('<path d="M24 46V12l28-6v34" fill="none" stroke="#1f3a8a" stroke-width="4"/><circle cx="18" cy="46" r="8" fill="#9b5cff" stroke="#1f3a8a" stroke-width="3"/><circle cx="46" cy="40" r="8" fill="#9b5cff" stroke="#1f3a8a" stroke-width="3"/>'),vibe:$t('<rect x="20" y="8" width="24" height="48" rx="5" fill="#fff" stroke="#1f3a8a" stroke-width="3"/><path d="M10 20v24M54 20v24M4 26v12M60 26v12" stroke="#1f3a8a" stroke-width="3" stroke-linecap="round"/>'),boss:$t('<rect x="6" y="20" width="44" height="26" rx="6" fill="#5b3c99" stroke="#1a1030" stroke-width="3"/><path d="M50 28h6l4 8v10H50z" fill="#3a2a5c" stroke="#1a1030" stroke-width="3"/><circle cx="18" cy="48" r="6" fill="#111"/><circle cx="46" cy="48" r="6" fill="#111"/><circle cx="28" cy="14" r="5" fill="#ff2020"/>')};function ht(i,t=""){return`<span class="i ${t}">${su[i]||""}</span>`}var qr=()=>typeof window<"u"?window.EbotNative:null;function qo(i){return En.find(t=>t.id===i)}var bn={mode:"demo",ready:!1,prices:{},handlers:null,demoConfirm:null,init(i){this.handlers=i;let t=qr();if(window.__ebotBilling={onReady:e=>this._onReady(e),onProducts:e=>this._onProducts(e),onPurchase:e=>this._onPurchase(e),onPurchaseFailed:(e,n)=>this._onFailed(e,n),onRestoreDone:e=>this._onRestoreDone(e)},t&&typeof t.billingInit=="function"){this.mode="play";let e=En.filter(s=>s.type==="inapp").map(s=>s.id),n=En.filter(s=>s.type==="subs").map(s=>s.id);try{t.billingInit(JSON.stringify({inapp:e,subs:n}))}catch(s){console.warn("billingInit failed",s)}}else this.mode="demo",this.ready=!0},price(i){return this.prices[i]||(qo(i)?qo(i).price:"")},async buy(i){let t=qo(i);if(!t)return;if(this.mode==="play"){if(!this.ready){this.handlers.message("storeUnavailable","error");return}try{qr().purchase(i)}catch{this.handlers.message("purchaseFail","error")}return}if(!(this.demoConfirm?await this.demoConfirm(t):!0))return;let n="demo-"+i+"-"+Date.now()+"-"+Math.random().toString(36).slice(2);this._deliver({productId:i,purchaseToken:n,state:"purchased",quantity:1,acknowledged:!1,type:t.type,fresh:!0})},restore(){if(this.mode==="play")try{qr().restorePurchases()}catch{this.handlers.message("storeUnavailable","error")}else this.handlers.message("restored","ok")},_onReady(i){this.ready=!!i,this.handlers.onReady&&this.handlers.onReady(this.ready)},_onProducts(i){try{let t=JSON.parse(i);for(let e of t)e.productId&&e.price&&(this.prices[e.productId]=e.price)}catch(t){console.warn("bad products json",t)}this.handlers.onPrices&&this.handlers.onPrices()},_onPurchase(i){let t;try{t=JSON.parse(i)}catch{return}this._deliver(t)},_onFailed(i,t){i==="canceled"?this.handlers.message("purchaseCancel","info"):i==="unavailable"?this.handlers.message("storeUnavailable","error"):this.handlers.message("purchaseFail","error",t)},_onRestoreDone(i){let t={};try{t=JSON.parse(i||"{}")}catch{}this.handlers.onRestore&&this.handlers.onRestore(t)},_deliver(i){let t=qo(i.productId);if(!t)return;if(i.state==="pending"){this.handlers.message("purchasePending","info");return}if(i.state!=="purchased")return;let e=Math.max(1,i.quantity||1);this.handlers.grant(t,e,i.purchaseToken,i)&&i.fresh!==!1&&this.handlers.message("purchaseOk","ok"),this.mode==="play"&&(t.consumable?qr().finishPurchase(i.purchaseToken,!0):i.acknowledged||qr().finishPurchase(i.purchaseToken,!1))}};var Fe=(i,t=document)=>t.querySelector(i),hn=i=>"#"+i.toString(16).padStart(6,"0"),Yo=i=>String(i).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]);function Zs(i,t=!1){let e=i.k==="vault"?"vault_"+(i.v||"steel"):i.k;return`<span class="item ${t?"big":""}">${ht(e)}<b>${i.k==="vault"?"\xD7"+i.n:Ke(i.n)}</b></span>`}function Je(i){let t=[];return i.gold&&t.push(`${ht("gold")}${Ke(i.gold)}`),i.gems&&t.push(`${ht("gems")}${Ke(i.gems)}`),i.batteries&&t.push(`${ht("batteries")}${Ke(i.batteries)}`),`<span class="cost">${t.join(" ")}</span>`}function ru(i,t=56){return`<svg width="${t}" height="${t}" viewBox="0 0 64 64"><rect x="8" y="14" width="48" height="38" rx="14" fill="${hn(i.body)}" stroke="#0b1a4a" stroke-width="3"/><rect x="14" y="22" width="36" height="20" rx="7" fill="${hn(i.visor)}"/><rect x="20" y="26" width="8" height="11" rx="3" fill="${hn(i.eye)}"/><rect x="36" y="26" width="8" height="11" rx="3" fill="${hn(i.eye)}"/><path d="M32 14V6" stroke="#0b1a4a" stroke-width="3"/><circle cx="32" cy="6" r="4" fill="${hn(i.accent)}" stroke="#0b1a4a" stroke-width="2"/><rect x="2" y="26" width="7" height="14" rx="3" fill="${hn(i.accent)}" stroke="#0b1a4a" stroke-width="2.5"/><rect x="55" y="26" width="7" height="14" rx="3" fill="${hn(i.accent)}" stroke="#0b1a4a" stroke-width="2.5"/></svg>`}var Zo=class{constructor(t){this.app=t,this.root=Fe("#ui"),this.modals=[],this.sheet=null,this.viewChar=null,this.viewSkin=null,this.popupQueue=[],this.hudFrame=0,this.lastTut=void 0,this.root.innerHTML=`
      <div id="lobby" class="layer hidden"></div>
      <div id="hud" class="layer hidden"></div>
      <div id="sheet" class="hidden"></div>
      <div id="modals"></div>
      <div id="toasts"></div>`,this.lobbyEl=Fe("#lobby"),this.hudEl=Fe("#hud"),this.sheetEl=Fe("#sheet"),this.modalsEl=Fe("#modals"),this.toastsEl=Fe("#toasts"),this.root.addEventListener("click",e=>{let n=e.target.closest("[data-a]");!n||n.disabled||(e.preventDefault(),wt.play("click"),this.action(n.dataset.a,n))}),this._lobbyDrag(),rl(()=>this.refresh()),setInterval(()=>this.tick(),1e3)}openModal(t,e,n={}){let s=document.createElement("div");s.className="modal-wrap "+(n.cls||""),s.dataset.id=t,this.modalsEl.appendChild(s);let r={id:t,el:s,render:e,opts:n};return this.modals.push(r),this._renderModal(r),requestAnimationFrame(()=>s.classList.add("show")),r}_renderModal(t){if(!t)return;let e=t.el.querySelector(".mbody"),n=e?e.scrollTop:0,s=t.render();if(s===t.lastHTML)return;t.lastHTML=s,t.el.innerHTML=t.opts.raw?s:`
      <div class="modal ${t.opts.size||""}">
        <div class="mhead"><h2>${t.opts.title?t.opts.title():""}</h2>${t.opts.noClose?"":`<button class="x" data-a="modal:close">${ht("close")}</button>`}</div>
        <div class="mbody">${s}</div>
      </div>`;let r=t.el.querySelector(".mbody");r&&(r.scrollTop=n),t.opts.after&&t.opts.after(t.el),this._updateTimers(t.el)}closeModal(t){let e=t?this.modals.findIndex(s=>s.id===t):this.modals.length-1;if(e<0)return;let[n]=this.modals.splice(e,1);n.el.classList.remove("show"),setTimeout(()=>n.el.remove(),180),n.opts.onClose&&n.opts.onClose(),this.modals.length||this._showNextPopup()}closeAllModals(){for(;this.modals.length;)this.closeModal()}topModal(){return this.modals[this.modals.length-1]}hasModal(t){return this.modals.some(e=>e.id===t)}refresh(){this.lobbyEl.classList.contains("hidden")||this.renderLobby(),this.sheet&&this.renderSheet();for(let t of this.modals)!t.opts.static&&!t.busy&&this._renderModal(t)}tick(){this._updateTimers(this.root)&&this.refresh()}_updateTimers(t){let e=!1,n=Date.now();return t.querySelectorAll("[data-until]").forEach(s=>{let r=+s.dataset.until-n;if(r<=0){e=!0;return}s.textContent=s.dataset.tpl?k(s.dataset.tpl,{t:jr(r)}):jr(r)}),e}confirm(t,e=k("yes"),n=k("no")){return new Promise(s=>{let r=this.openModal("confirm",()=>`
        <p class="msg">${t}</p>
        <div class="btn-row"><button class="btn red" data-a="confirm:no">${n}</button><button class="btn green" data-a="confirm:yes">${e}</button></div>`,{title:()=>k("confirmBuy"),size:"small",static:!0,onClose:()=>s(!1)});r.resolve=a=>{r.opts.onClose=null,this.closeModal("confirm"),s(a)}})}info(t,e){this.openModal("info",()=>e,{title:()=>t,size:"small",static:!0})}toast(t,e="info",n={}){let s=document.createElement("div");s.className=`toast ${e} ${n.big?"big":""} ${n.center?"center":""}`,s.innerHTML=(n.icon?ht(n.icon):"")+`<span>${t}</span>`,this.toastsEl.appendChild(s),setTimeout(()=>s.classList.add("out"),n.dur||1500),setTimeout(()=>s.remove(),(n.dur||1500)+500)}popup(t,e,n=""){this.popupQueue.push({title:t,items:e,extra:n}),this.hasModal("popup")||this._showNextPopup()}_showNextPopup(){if(this.hasModal("popup")||!this.popupQueue.length||this.app.inRun())return;let t=this.popupQueue.shift();wt.play("reward"),this.openModal("popup",()=>`
      <div class="burst"></div>
      ${t.extra}
      <div class="items">${(t.items||[]).map(e=>Zs(e,!0)).join("")}</div>
      <button class="btn green wide" data-a="modal:close">${k("collect")}</button>`,{title:()=>t.title,size:"small reward",static:!0,onClose:()=>setTimeout(()=>this._showNextPopup(),200)})}showLobby(){this.hudEl.classList.add("hidden"),this.lobbyEl.classList.remove("hidden"),this.renderLobby(),this._showNextPopup()}showHud(){this.closeAllModals(),this.closeSheet(!0),this.lobbyEl.classList.add("hidden"),this.hudEl.classList.remove("hidden"),this.renderHud()}renderLobby(){let t=Yt(),e=El(),n=Gn(t.world),s=t.iap.starter?hs()?"club":"offers":"starter",r=(l,c,h,u,d="")=>`<button class="side-btn" data-a="${l}">${ht(c)}<span>${h}</span>${u?`<i class="badge">${u===!0?"!":u}</i>`:""}${d}</button>`,a=os()?"":`<small class="timer" data-until="${t.giftNext}"></small>`;this.lobbyEl.classList.toggle("sheet-open",!!this.sheet);let o=`
      ${this.topBar()}
      <div class="lobby-title"><div class="logo">${ht("robotHead")}<span>${k("title")}</span></div>
        <div class="stats-row"><span class="chip">${ht("trophy")}${fe(t.best)}</span><span class="chip mult">${k("multiplier")} x${Di()}</span></div></div>
      <div class="side start">
        ${r("open:daily","daily",k("daily"),e.daily)}
        ${r("open:missions","missions",k("missions"),e.missions||!1)}
        ${r("open:wheel","wheel",k("wheel"),e.wheel)}
        ${r("open:upgrades","upgrades",k("upgrades"),!1)}
      </div>
      <div class="side end">
        ${r("gift","gift",k("gift"),e.gift,a)}
        ${r("open:vaults","vault",k("vaults"),e.vaults)}
        ${r("open:shop:gems","shop",k("shop"),!1)}
        ${s==="club"?r("club","club",k("p_ebot_club"),e.club):r("open:shop:offers","offer",s==="starter"?k("p_starter_pack"):k("tabOffers"),s==="starter")}
      </div>
      <div class="lobby-bottom">
        <button class="world-chip" data-a="open:worlds">${ht("map")}<span>${ye(n.name)}</span><small>${Tn(n.id)}/${wn.length}</small></button>
        <div class="row">
          <button class="big-btn blue" data-a="sheet:chars">${ht("characters")}<span>${k("characters")}</span></button>
          <button class="play-btn" data-a="play"><span>${k("play")}</span></button>
          <button class="big-btn orange" data-a="sheet:build">${ht("build")}<span>${k("build")}</span>${e.build?'<i class="badge">!</i>':""}</button>
        </div>
      </div>`;o!==this._lobbyHTML&&(this._lobbyHTML=o,this.lobbyEl.innerHTML=o,this._updateTimers(this.lobbyEl))}topBar(){let t=Yt();return`<div class="topbar">
      <button class="pill" data-a="open:shop:gold">${ht("gold")}<b>${Ke(t.gold)}</b><i class="plus">+</i></button>
      <button class="pill" data-a="open:shop:gems">${ht("gems")}<b>${Ke(t.gems)}</b><i class="plus">+</i></button>
      <button class="pill" data-a="open:shop:items">${ht("batteries")}<b>${Ke(t.batteries)}</b><i class="plus">+</i></button>
      <button class="round-btn" data-a="open:settings">${ht("settings")}</button>
    </div>`}_lobbyDrag(){let t=null;this.lobbyEl.addEventListener("pointerdown",e=>{e.target.closest("button")||(t=e.clientX)}),window.addEventListener("pointermove",e=>{t!==null&&(this.app.game.dragLobby(e.clientX-t),t=e.clientX)}),window.addEventListener("pointerup",()=>{t=null})}renderHud(){this.hudEl.innerHTML=`
      <div class="hud-top">
        <div class="score-box"><div class="score" id="hScore">0</div><div class="mult" id="hMult">x1</div></div>
        <div class="hud-right">
          <div class="gold-count">${ht("gold")}<b id="hGold">0</b></div>
          <div class="gem-count hidden" id="hGemsBox">${ht("gems")}<b id="hGems">0</b></div>
          <div class="dist" id="hDist">0 ${k("m")}</div>
        </div>
        <button class="round-btn pause" data-a="pause">${ht("pause")}</button>
      </div>
      <div class="boss-bar hidden" id="hBoss">${ht("boss")}<div class="pips"></div></div>
      <div class="pu-list" id="hPu"></div>
      <div class="speech hidden" id="hSpeech"></div>
      <div class="tutorial hidden" id="hTut"></div>
      <button class="headstart hidden" id="hHead" data-a="headstart">${ht("headstart")}<span>${k("headstart")}</span><b id="hHeadN"></b></button>
      <div class="swipe-zone" id="swipeZone"></div>`,this.hud={score:Fe("#hScore"),mult:Fe("#hMult"),gold:Fe("#hGold"),dist:Fe("#hDist"),pu:Fe("#hPu"),boss:Fe("#hBoss"),speech:Fe("#hSpeech"),tut:Fe("#hTut"),head:Fe("#hHead"),headN:Fe("#hHeadN"),gems:Fe("#hGems"),gemsBox:Fe("#hGemsBox")},this.puShown=""}updateHud(t){if(!this.hud||(this.hudFrame++,this.hudFrame%2))return;let e=this.hud;e.score.textContent=fe(t.score),e.mult.textContent="x"+t.mult,e.gold.textContent=fe(t.gold),e.dist.textContent=fe(t.d)+" "+k("m"),t.gems>0&&(e.gemsBox.classList.remove("hidden"),e.gems.textContent=t.gems);let n=Ks.filter(r=>t.pu[r]>0),s=n.join(",");s!==this.puShown&&(this.puShown=s,e.pu.innerHTML=n.map(r=>`<div class="pu" data-pu="${r}">${ht(r)}<svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="16" class="bg"/><circle cx="18" cy="18" r="16" class="fg" style="stroke:${hn(Vn[r].color)}"/></svg></div>`).join(""));for(let r of n){let a=e.pu.querySelector(`[data-pu="${r}"] .fg`);a&&(a.style.strokeDashoffset=String(100.5*(1-t.pu[r]/t.puMax[r])))}}setBoss(t,e){let n=this.hud&&this.hud.boss;n&&(t==="start"||t==="hit"?(n.classList.remove("hidden"),n.querySelector(".pips").innerHTML=Array.from({length:e.max},(s,r)=>`<i class="${r<e.max-e.hits?"on":""}"></i>`).join(""),t==="hit"&&(n.classList.remove("hit"),n.offsetWidth,n.classList.add("hit"))):(t==="defeat"||t==="end")&&(n.classList.add("hidden"),t==="defeat"&&this.toast(`+${e.gold}`,"gold",{icon:"gold"})))}speech(t){let e=this.hud&&this.hud.speech;e&&(e.textContent=t,e.classList.remove("hidden"),clearTimeout(this._sp),this._sp=setTimeout(()=>e.classList.add("hidden"),2200))}tutorial(t){if(!this.hud||this.lastTut===t)return;this.lastTut=t;let e=this.hud.tut;if(!t){e.classList.add("hidden");return}let n={jump:k("tutJump"),slide:k("tutSlide"),lane:k("tutLane")}[t];e.className="tutorial "+t,e.innerHTML=`<div class="hand">${ht("swipe")}</div><p>${n}</p>`}headstartOffer(t,e){this.hud&&(this.hud.head.classList.toggle("hidden",!t),this.hud.headN.textContent="\xD7"+e)}openSheet(t){this.sheet=t;let e=Yt();t==="chars"&&(this.viewChar=e.char,this.viewSkin=e.skins[e.char]),this.app.game.setView(t==="chars"?"char":"house"),this.sheetEl.classList.remove("hidden"),requestAnimationFrame(()=>this.sheetEl.classList.add("show")),this.renderSheet(),this.renderLobby()}closeSheet(t){this.sheet&&(this.sheet=null,this.sheetEl.classList.remove("show"),setTimeout(()=>{this.sheet||this.sheetEl.classList.add("hidden")},200),this.app.game.setView("home"),this.app.syncLobby(),t||this.renderLobby())}renderSheet(){let t=this.sheet==="chars"?this.charsHTML():this.sheet==="build"?this.buildHTML():"";if(t!==this._sheetHTML){let e=this.sheetEl.querySelector(".char-strip"),n=e?e.scrollLeft:0;this._sheetHTML=t,this.sheetEl.innerHTML=t;let s=this.sheetEl.querySelector(".char-strip");s&&(s.scrollLeft=n)}if(this.sheet==="chars"){let e=Ie(this.viewChar),n=e.skins.find(s=>s.id===this.viewSkin)||e.skins[0];this.app.previewSkin(n)}else this.app.syncLobby()}charsHTML(){let t=Yt(),e=Ie(this.viewChar),n=$n(e.id),s=e.skins.find(l=>l.id===this.viewSkin)||e.skins[0],r=Ui(e.id,s.id),a=Object.entries(e.perk).map(([l,c])=>`<span class="chip perk">${l==="score"?ht("star"):ht(l)}${k("perk_"+l)} +${Math.round(c*100)}%</span>`).join(""),o;return n?r?t.char===e.id&&t.skins[e.id]===s.id?o=`<button class="btn grey wide" disabled>${ht("check")}${k("selected")}</button>`:o=`<button class="btn green wide" data-a="char:select">${k("select")}</button>`:o=`<button class="btn ${s.cost.gems?"purple":"gold"} wide" data-a="skin:buy">${k("buy")} ${Je(s.cost)}</button>`:e.unlock.type==="gems"?o=`<button class="btn purple wide" data-a="char:unlock">${k("unlock")} ${Je({gems:e.unlock.gems})}</button>`:o=`<div class="locked-note">${ht("lock")}${k("unlockByHouse",{w:ye(Gn(e.unlock.world).name)})}</div>`,`
      <div class="sheet-head"><button class="round-btn" data-a="sheet:close">${ht(Ii()==="ar"?"arrowR":"arrowL")}</button><h2>${k("characters")}</h2>${this.miniWallet()}</div>
      <div class="char-strip">${Qr.map(l=>{let c=$n(l.id),h=c?ss(l.id):l.skins[0];return`<button class="char-card ${l.id===e.id?"on":""} ${c?"":"locked"} ${t.char===l.id?"cur":""}" data-a="char:view:${l.id}">${ru(h,54)}<span>${ye(l.name)}</span>${c?"":ht("lock","lk")}</button>`}).join("")}</div>
      <div class="char-detail">
        <h3>${ye(e.name)} <small>${ye(s.name)}</small></h3>
        <p>${ye(e.bio)}</p>
        <div class="perks">${a}</div>
        <div class="skins"><span class="lbl">${k("skins")}</span>${e.skins.map(l=>{let c=Ui(e.id,l.id);return`<button class="skin ${l.id===s.id?"on":""}" data-a="skin:view:${l.id}" style="--b:${hn(l.body)};--a:${hn(l.accent)}"><i></i>${c?"":`<small>${l.cost.gems?ht("gems")+l.cost.gems:ht("gold")+Ke(l.cost.gold)}</small>`}</button>`}).join("")}</div>
      </div>
      <div class="sheet-actions">${o}</div>`}miniWallet(){let t=Yt();return`<div class="mini-wallet"><span>${ht("gold")}${Ke(t.gold)}</span><span>${ht("gems")}${Ke(t.gems)}</span></div>`}buildHTML(){let t=Yt(),e=Gn(t.world),n=Tn(e.id),s=hi(e.id),a=Qe.filter(d=>ki(d.id)).length>1,o=Mu.map((d,f)=>{let g=Yt()&&(f>=n&&f===n?s:null);return`<li class="${f<n?"done":f===n?"next":"todo"}"><span class="num">${f<n?ht("check"):f+1}</span><span class="nm">${ye(d)}</span>${g?Je(g):""}</li>`}).join(""),l=Qe[tr(e.id)+1],c=n<wn.length?`<p class="hint">${k("multiplierInfo")}</p>`:`<p class="hint done">${ht("check")} ${k("complete")}</p>`,h;s?ir(s)?h=`<button class="btn gold wide pulse" data-a="build">${ht("build")}${k("buildHouse")} ${Je(s)}</button>`:h=`<button class="btn grey wide" data-a="build">${k("needMore")} ${Je(s)}</button>`:h=`<button class="btn grey wide" disabled>${k("complete")}</button>`;let u=e.unlocks?`<div class="unlock-preview">${ru(Ie(e.unlocks).skins[0],40)}<span>${ye(Ie(e.unlocks).name)}${l?" + "+ye(l.name):""}</span></div>`:"";return`
      <div class="sheet-head"><button class="round-btn" data-a="sheet:close">${ht(Ii()==="ar"?"arrowR":"arrowL")}</button>
        <h2>${a?`<button class="mini" data-a="world:prev">${ht(Ii()==="ar"?"arrowR":"arrowL")}</button>`:""}${k("houseOf",{w:ye(e.name)})}${a?`<button class="mini" data-a="world:next">${ht(Ii()==="ar"?"arrowL":"arrowR")}</button>`:""}</h2>${this.miniWallet()}</div>
      <div class="build-progress"><div class="bar"><i style="width:${n/wn.length*100}%"></i></div><b>${n}/${wn.length}</b><span class="chip mult">x${Di()}</span></div>
      ${u}
      <ul class="stages">${o}</ul>
      ${c}
      <div class="sheet-actions">${h}</div>`}openShop(t="gems"){if(this.shopTab=t,this.hasModal("shop")){this._renderModal(this.modals.find(e=>e.id==="shop"));return}this.openModal("shop",()=>this.shopHTML(),{title:()=>k("shop"),size:"tall"})}shopHTML(){let t=Yt(),e=["gems","gold","offers","items"],n={gems:k("tabGems"),gold:k("tabGold"),offers:k("tabOffers"),items:k("tabItems")},s=(a,o,l)=>`
      <div class="prod ${a.tag?"tagged":""}">${a.tag?`<span class="tag">${k("tag_"+a.tag)}</span>`:""}
        <div class="pile">${ht(l)}${o>400?ht(l,"b2"):""}${o>2e3?ht(l,"b3"):""}</div>
        <b class="amt">${fe(o)}</b>
        <button class="btn green" data-a="buy:${a.id}">${Yo(bn.price(a.id))}</button></div>`,r="";if(this.shopTab==="gems")r=`<div class="grid3">${En.filter(a=>a.id.startsWith("gems_")).map(a=>s(a,a.grant[0].n,"gems")).join("")}</div>`;else if(this.shopTab==="gold")r=`<div class="grid3">${En.filter(a=>a.id.startsWith("gold_")&&a.consumable).map(a=>s(a,a.grant[0].n,"gold")).join("")}
        ${sa.filter(a=>a.give.k==="gold").map(a=>`<div class="prod"><div class="pile">${ht("gold")}</div><b class="amt">${fe(a.give.n)}</b><button class="btn purple" data-a="gemoffer:${a.id}">${ht("gems")}${a.gems}</button></div>`).join("")}</div>`;else if(this.shopTab==="offers"){let a=En.find(c=>c.id==="starter_pack"),o=En.find(c=>c.id==="gold_doubler"),l=En.find(c=>c.id==="ebot_club");r=`
        <div class="offer-card starter ${t.iap.starter?"owned":""}"><span class="tag">${k("tag_starter")}</span>
          <h3>${k("p_starter_pack")}</h3><div class="items">${a.grant.map(c=>Zs(c)).join("")}</div>
          ${t.iap.starter?`<button class="btn grey" disabled>${ht("check")}${k("purchased")}</button>`:`<button class="btn green" data-a="buy:starter_pack">${Yo(bn.price("starter_pack"))}</button>`}</div>
        <div class="offer-card doubler ${t.iap.doubler?"owned":""}"><span class="tag">${k("tag_forever")}</span>
          <h3>${ht("double")}${k("p_gold_doubler")}</h3><p>${k("p_gold_doubler_d")}</p>
          ${t.iap.doubler?`<button class="btn grey" disabled>${ht("check")}${k("owned")}</button>`:`<button class="btn green" data-a="buy:gold_doubler">${Yo(bn.price("gold_doubler"))}</button>`}</div>
        <div class="offer-card club ${hs()?"owned":""}"><span class="tag">${k("tag_club")}</span>
          <h3>${ht("club")}${k("p_ebot_club")}</h3><p>${k("p_ebot_club_d")}</p><div class="items">${ia.map(c=>Zs(c)).join("")}</div>
          ${hs()?`<button class="btn grey" disabled>${ht("check")}${k("active")}</button>`:`<button class="btn green" data-a="buy:ebot_club">${Yo(bn.price("ebot_club"))}${k("perMonth")}</button>`}</div>`}else r=`<div class="grid3">${sa.filter(a=>a.give.k!=="gold").map(a=>`<div class="prod"><div class="pile">${ht(a.give.k)}</div><b class="amt">\xD7${a.give.n}</b><small>${k(a.give.k)}</small><button class="btn purple" data-a="gemoffer:${a.id}">${ht("gems")}${a.gems}</button></div>`).join("")}</div>`;return`
      <div class="wallet-row">${this.miniWallet()}<span>${ht("batteries")}${t.batteries}</span><span>${ht("headstart")}${t.headstart}</span></div>
      <div class="tabs">${e.map(a=>`<button class="${a===this.shopTab?"on":""}" data-a="shoptab:${a}">${n[a]}</button>`).join("")}</div>
      ${r}
      ${bn.mode==="demo"?`<p class="demo-note">${ht("info")}${k("demoStore")}</p>`:""}
      <button class="link" data-a="restore">${k("restore")}</button>`}openUpgrades(){this.openModal("upgrades",()=>{let t=Yt();return`<div class="wallet-row">${this.miniWallet()}</div>`+Ks.map(e=>{let n=t.upgrades[e]||0,s=ra(e),r=sr(e),a=s!=null?(Vn[e].base+Vn[e].perLevel*(n+1))*(1+is(t.char,e)):null;return`<div class="upg">
          <div class="upg-ic">${ht(e)}</div>
          <div class="upg-info"><h4>${k("pu_"+e)}</h4><p>${k("pu_"+e+"_d")}</p>
            <div class="pips">${Array.from({length:ta},(o,l)=>`<i class="${l<n?"on":""}"></i>`).join("")}</div>
            <small>${k("duration")}: <b>${r.toFixed(1)}${k("sec")}</b>${a?` \u2192 <b class="up">${a.toFixed(1)}${k("sec")}</b>`:""}</small></div>
          ${s!=null?`<button class="btn ${t.gold>=s?"gold":"grey"}" data-a="upgrade:${e}">${Je({gold:s})}</button>`:`<span class="maxed">${k("max")}</span>`}
        </div>`}).join("")},{title:()=>k("upgrades")})}openWorlds(){this.openModal("worlds",()=>{let t=Yt();return`<div class="worlds">${Qe.map((e,n)=>{let s=ki(e.id),r=Tn(e.id),a=Qe[n-1];return`<div class="world-card ${s?"":"locked"} ${t.world===e.id?"cur":""}" style="--s1:${hn(e.sky[0])};--s2:${hn(e.sky[1])};--g:${hn(e.ground)}">
          <div class="wc-art"><i class="sun"></i><i class="hill"></i><i class="road"></i></div>
          <div class="wc-info"><h4>${ye(e.name)}</h4><p>${ye(e.desc)}</p>
          ${s?`<div class="bar"><i style="width:${r/wn.length*100}%"></i></div><small>${r}/${wn.length}</small>`:`<small class="lk">${ht("lock")}${k("worldLocked",{w:ye(a.name)})}</small>`}</div>
          ${s?t.world===e.id?`<span class="chip">${k("currentWorld")}</span>`:`<button class="btn green" data-a="world:go:${e.id}">${k("go")}</button>`:""}
        </div>`}).join("")}</div>`},{title:()=>k("worlds"),size:"tall"})}openVaults(){this.openModal("vaults",()=>{let t=Yt(),e=Date.now(),n=t.vaults.some(a=>a.unlockAt&&a.unlockAt>e),s=[];for(let a=0;a<er;a++){let o=t.vaults[a];if(!o){s.push(`<div class="slot empty"><span>${k("emptySlot")}</span></div>`);continue}let l;rs(o)?l=`<button class="btn green" data-a="vault:open:${o.id}">${k("open")}</button>`:o.unlockAt?l=`<small class="timer" data-until="${o.unlockAt}"></small><button class="btn purple" data-a="vault:instant:${o.id}">${k("openNow")} ${Je({batteries:or(o)})}</button>`:l=`<small>${Se[o.type].unlockH}${k("h")}</small>${n?`<button class="btn purple" data-a="vault:instant:${o.id}">${Je({batteries:or(o)})}</button>`:`<button class="btn blue" data-a="vault:start:${o.id}">${k("startUnlock")}</button>`}`,s.push(`<div class="slot ${o.type}">${ht("vault_"+o.type)}<b>${ye(Se[o.type].name)}</b>${l}</div>`)}let r=as()?`<button class="btn green" data-a="vault:wood">${k("free")}</button>`:`<small class="timer" data-until="${t.woodNext}" data-tpl="freeVaultIn"></small>`;return`
        <div class="wallet-row">${this.miniWallet()}<span>${ht("batteries")}${t.batteries}</span></div>
        <div class="vault-free ${as()?"ready":""}">${ht("vault_wood")}<div><b>${ye(Se.wood.name)}</b><small>${k("contains",{n:Se.wood.rolls})}</small></div>${r}<button class="link" data-a="odds:wood">${k("odds")}</button></div>
        <h4 class="sec">${k("vaultSlots")}</h4>
        <div class="slots">${s.join("")}</div>
        <div class="vault-shop">
          <div class="vs">${ht("vault_steel")}<b>${ye(Se.steel.name)}</b><button class="btn gold" data-a="vault:buySteel">${Je({gold:Se.steel.goldPrice})}</button><button class="link" data-a="odds:steel">${k("odds")}</button></div>
          <div class="vs">${ht("vault_diamond")}<b>${ye(Se.diamond.name)}</b><div class="btn-col"><button class="btn purple" data-a="vault:diamond:bat">${Je({batteries:Se.diamond.batteryPrice})}</button><button class="btn purple" data-a="vault:diamond:gems">${Je({gems:Se.diamond.gemPrice})}</button></div><button class="link" data-a="odds:diamond">${k("odds")}</button></div>
        </div>`},{title:()=>k("vaults"),size:"tall"})}showVaultOpen(t){t&&(wt.play("build"),this.openModal("vaultopen",()=>`
      <div class="vault-anim">${ht("vault_"+t.type)}</div>
      <div class="items reveal">${t.items.map((e,n)=>`<span style="animation-delay:${.7+n*.25}s">${Zs(e,!0)}</span>`).join("")}</div>
      <button class="btn green wide" data-a="modal:close">${k("collect")}</button>`,{title:()=>ye(Se[t.type].name),size:"small reward",static:!0}),setTimeout(()=>wt.play("reward"),700))}showOdds(t){let e=ml(t).map(s=>`<tr><td>${ht(s.k)} ${k(s.k)}</td><td>${fe(s.min)}\u2013${fe(s.max)}</td><td>${s.pct.toFixed(1)}%</td></tr>`).join(""),n=Se[t].guaranteeGems?`<p class="hint">${ht("gems")} 100% \xD71</p>`:"";this.info(k("odds")+" \u2014 "+ye(Se[t].name),`<table class="odds">${e}</table><p class="hint">${k("contains",{n:Se[t].rolls})}</p>${n}`)}openWheel(){let t=an.segments,e=t.length,n=360/e,s=o=>{let c=(o*n-90-n/2)*Math.PI/180,h=((o+1)*n-90-n/2)*Math.PI/180;return`M0 0 L${(Math.cos(c)*100).toFixed(2)} ${(Math.sin(c)*100).toFixed(2)} A100 100 0 0 1 ${(Math.cos(h)*100).toFixed(2)} ${(Math.sin(h)*100).toFixed(2)} Z`},r=`<svg viewBox="-104 -104 208 208" class="wheel-svg">${t.map((o,l)=>`<path d="${s(l)}" fill="${o.color}" stroke="#fff" stroke-width="2"/>`).join("")}
      ${t.map((o,l)=>`<g transform="rotate(${l*n}) translate(0 -66)"><g transform="translate(-14 -16) scale(0.44)">${su[o.k].replace('class="ico"','width="64" height="64"')}</g><text y="30" text-anchor="middle" font-size="14" font-weight="900" fill="#1b1b3a">${o.jackpot?"\u2605":""}${Ke(o.n)}</text></g>`).join("")}
      <circle r="16" fill="#fff" stroke="#1f3a8a" stroke-width="4"/></svg>`;return this.wheelAngle=this.wheelAngle||0,this.openModal("wheel",()=>{let o=Yt(),l=lr();return`<div class="wheel-box"><div class="pointer"></div><div class="wheel-rot" style="transform:rotate(${this.wheelAngle}deg)">${r}</div></div>
        <div class="btn-row">${l?`<button class="btn green wide" data-a="spin:free">${k("spinFree")}</button>`:`<button class="btn purple wide" data-a="spin:paid">${k("spinFor",{n:an.spinGemCost})} ${ht("gems")}</button>`}</div>
        ${l?"":`<p class="hint" data-until="${o.wheelNext}" data-tpl="nextSpin"></p>`}
        <button class="link" data-a="odds:wheel">${k("odds")}</button>`},{title:()=>k("wheel")})}spin(t){let e=this.modals.find(u=>u.id==="wheel");if(!e||e.busy)return;let n=gl(t);if(!n){this.toast(k("notEnough"),"warn"),wt.play("error");return}e.busy=!0;let s=an.segments.length,r=360/s,a=this.wheelAngle%360,o=360*5+(360-n.index*r)-a+(Math.random()-.5)*r*.6;this.wheelAngle+=o;let l=e.el.querySelector(".wheel-rot");l.style.transition="transform 4.2s cubic-bezier(.12,.75,.16,1)",l.style.transform=`rotate(${this.wheelAngle}deg)`,e.el.querySelectorAll('[data-a^="spin"]').forEach(u=>{u.disabled=!0});let c=0,h=setInterval(()=>{wt.play("tick"),++c>26&&clearInterval(h)},150);setTimeout(()=>{e.busy=!1,l.style.transition="";let u=an.segments[n.index];this.popup(u.jackpot?k("jackpot"):k("reward"),n.items),this._renderModal(e)},4400)}showWheelOdds(){let t=xl().map(e=>`<tr><td>${ht(e.k)} ${k(e.k)}</td><td>${fe(e.n)}</td><td>${e.pct.toFixed(1)}%</td></tr>`).join("");this.info(k("odds")+" \u2014 "+k("wheel"),`<table class="odds">${t}</table>`)}openDaily(){this.openModal("daily",()=>{let t=Yt(),e=ls(),n=ua();return`<div class="daily">${ea.map((s,r)=>{let a=e?r<n?"past":r===n?"today":"future":r<=n?"past":"future";return`<div class="day ${a} ${r===6?"d7":""}"><small>${k("day",{n:r+1})}</small><div class="items">${s.map(o=>Zs(o)).join("")}</div>${a==="past"?`<span class="done">${ht("check")}</span>`:""}</div>`}).join("")}</div>
      ${e?`<button class="btn green wide pulse" data-a="daily:claim">${k("claim")}</button>`:`<p class="hint">${k("comeBack")}</p>`}`},{title:()=>k("dailyTitle")})}openMissions(){this.openModal("missions",()=>{let t=Yt();return t.missions.map((e,n)=>{let s=Wn(e.id),r=cs(e,null),a=Math.min(100,r/s.n*100);return`<div class="mission ${e.done?"done":""}">
          <div class="m-info"><p>${k("m_"+s.stat,{n:fe(s.n)})}${s.scope==="run"?` <small>(${k("inOneRun")})</small>`:""}</p>
            <div class="bar"><i style="width:${a}%"></i></div><small>${fe(r)}/${fe(s.n)}</small></div>
          <div class="m-rew">${Zs(s.reward)}${e.done?`<button class="btn green" data-a="mission:claim:${n}">${k("claim")}</button>`:""}</div>
        </div>`}).join("")+`<div class="records"><h4 class="sec">${ht("trophy")} ${k("records")}</h4>${(t.records||[]).slice(0,5).map((e,n)=>`<div class="rec"><b>#${n+1}</b><span>${fe(e.score)}</span><small>${fe(e.dist)} ${k("m")} \xB7 ${ye(Ie(e.char).name)}</small></div>`).join("")||'<p class="hint">\u2014</p>'}</div>`},{title:()=>k("missionsTitle")})}openSettings(){this.openModal("settings",()=>{let t=Yt(),e=t.settings,n=(r,a,o)=>`<div class="set-row">${ht(a)}<span>${o}</span><button class="toggle ${e[r]?"on":""}" data-a="set:${r}"><i></i></button></div>`,s=t.stats;return`
        ${n("sound","sound",k("sound"))}
        ${n("music","music",k("music"))}
        ${n("vibe","vibe",k("vibration"))}
        <div class="set-row">${ht("globe")}<span>${k("language")}</span><div class="seg"><button class="${Ii()==="ar"?"on":""}" data-a="lang:ar">\u0627\u0644\u0639\u0631\u0628\u064A\u0629</button><button class="${Ii()==="en"?"on":""}" data-a="lang:en">English</button></div></div>
        <div class="set-row">${ht("star")}<span>${k("quality")}</span><div class="seg"><button class="${e.quality==="low"?"on":""}" data-a="quality:low">${k("qLow")}</button><button class="${e.quality!=="low"?"on":""}" data-a="quality:high">${k("qHigh")}</button></div></div>
        <h4 class="sec">${k("stats")}</h4>
        <div class="stats-grid">
          <div><small>${k("st_best")}</small><b>${fe(t.best)}</b></div><div><small>${k("st_bestDist")}</small><b>${fe(t.bestDist)} ${k("m")}</b></div>
          <div><small>${k("st_runs")}</small><b>${fe(s.runs)}</b></div><div><small>${k("st_dist")}</small><b>${Ke(s.dist)} ${k("m")}</b></div>
          <div><small>${k("st_gold")}</small><b>${Ke(s.gold)}</b></div><div><small>${k("st_bosses")}</small><b>${fe(t.missionTotals.bosses||0)}</b></div>
        </div>
        <div class="btn-col">
          <button class="btn blue" data-a="restore">${k("restore")}</button>
          ${this.app.isAndroid()?`<button class="btn gold" data-a="rate">${ht("star")}${k("rate")}</button>`:""}
          <button class="btn grey" data-a="privacy">${k("privacy")}</button>
          <button class="btn red" data-a="reset">${k("resetProgress")}</button>
        </div>
        <p class="hint ver">${k("title")} \xB7 ${k("version")} ${vu}${bn.mode==="play"?" \xB7 Google Play":" \xB7 Web"}</p>`},{title:()=>k("settings"),size:"tall"})}openPause(){this.openModal("pause",()=>`
      <div class="btn-col">
        <button class="btn green wide" data-a="resume">${ht("play")}${k("resume")}</button>
        <button class="btn blue wide" data-a="restart">${k("restart")}</button>
        <button class="btn grey wide" data-a="home">${k("home")}</button>
      </div>
      <div class="quick-toggles">
        <button class="toggle-ic ${Yt().settings.sound?"on":""}" data-a="set:sound">${ht("sound")}</button>
        <button class="toggle-ic ${Yt().settings.music?"on":""}" data-a="set:music">${ht("music")}</button>
      </div>`,{title:()=>k("paused"),size:"small",noClose:!0})}openRevive(t,e){let n=Yt(),s=Qs[Math.min(t,Qs.length-1)],r=s*yu,a=5;this.reviveChoice=e;let o=this.openModal("revive",()=>`
      <div class="revive-ring"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" class="bg"/><circle cx="60" cy="60" r="52" class="fg" id="revRing"/></svg><b id="revNum">${a}</b></div>
      <p class="msg">${k("reviveQ")}</p>
      <div class="btn-col">
        ${n.batteries>=s?`<button class="btn green wide" data-a="revive:battery">${k("reviveWith",{n:""})}${Je({batteries:s})}</button>`:""}
        ${n.gems>=r?`<button class="btn purple wide" data-a="revive:gems">${k("reviveWith",{n:""})}${Je({gems:r})}</button>`:""}
        ${n.batteries<s&&n.gems<r?`<button class="btn gold wide" data-a="revive:shop">${k("getMore")} ${ht("gems")}</button>`:""}
        <button class="btn grey" data-a="revive:skip">${k("skip")}</button>
      </div>`,{title:()=>k("revive"),size:"small",noClose:!0,static:!0}),l=o.el.querySelector("#revRing");requestAnimationFrame(()=>{l&&(l.style.transition="stroke-dashoffset 5s linear",l.style.strokeDashoffset="327")}),this.reviveTimer=setInterval(()=>{if(o.paused)return;a--;let c=o.el.querySelector("#revNum");c&&(c.textContent=Math.max(0,a)),wt.play("tick"),a<=0&&this.resolveRevive("skip")},1e3),o.cost=s,o.gemCost=r}resolveRevive(t){clearInterval(this.reviveTimer);let e=this.modals.find(s=>s.id==="revive");if(!e)return;let n=this.reviveChoice;this.reviveChoice=null,!(t==="battery"&&!en({batteries:e.cost}))&&(t==="gems"&&!en({gems:e.gemCost})||(this.closeModal("revive"),n&&n(t==="battery"||t==="gems")))}showResults(t){let e=Yt();this.lastResult=t,this.openModal("results",()=>{let n=e.missions.map(s=>{let r=Wn(s.id),a=cs(s,null);return`<div class="mini-mission ${s.done?"done":""}"><span>${k("m_"+r.stat,{n:fe(r.n)})}</span><div class="bar"><i style="width:${Math.min(100,a/r.n*100)}%"></i></div></div>`}).join("");return`
        ${t.isBest?`<div class="ribbon">${ht("trophy")}${k("newBest")}</div>`:""}
        <div class="res-score"><small>${k("score")}</small><b>${fe(t.score)}</b><small>${k("best")}: ${fe(e.best)}</small></div>
        <div class="res-rows">
          <div><span>${k("distance")}</span><b>${fe(t.dist)} ${k("m")}</b></div>
          <div><span>${ht("gold")}${k("goldCollected")}</span><b>${fe(t.gold)}${t.doubled?" \xD72":""}</b></div>
          ${t.gems?`<div><span>${ht("gems")}${k("gems")}</span><b>+${t.gems}</b></div>`:""}
          ${t.vaults?`<div><span>${ht("vault_steel")}${k("vault")}</span><b>+${t.vaults}</b></div>`:""}
          <div><span>${k("multiplier")}</span><b>x${Di()}</b></div>
        </div>
        ${t.gold>0&&!t.doubled?`<button class="btn purple wide" data-a="results:double">${k("doubleIt",{n:""})}${Je({gems:t.doubleCost})}</button>`:""}
        <div class="res-missions">${n}</div>
        <div class="btn-row"><button class="btn blue" data-a="results:home">${k("home")}</button><button class="btn green" data-a="results:again">${k("playAgain")}</button></div>`},{title:()=>k("results"),size:"tall",noClose:!0})}async action(t,e){let[n,s,r]=t.split(":"),a=this.app,o=Yt();switch(n){case"modal":this.closeModal();break;case"confirm":{let l=this.modals.find(c=>c.id==="confirm");l&&l.resolve&&l.resolve(s==="yes");break}case"play":a.startRun();break;case"open":s==="shop"?this.openShop(r):s==="daily"?this.openDaily():s==="missions"?this.openMissions():s==="wheel"?this.openWheel():s==="vaults"?this.openVaults():s==="settings"?this.openSettings():s==="upgrades"?this.openUpgrades():s==="worlds"&&this.openWorlds();break;case"shoptab":this.shopTab=s,this._renderModal(this.modals.find(l=>l.id==="shop"));break;case"gift":{if(!os()){this.toast(k("giftIn",{t:jr(o.giftNext-Date.now())}),"info");break}let l=_l();l&&this.popup(k("gift"),l);break}case"club":{let l=wl();l?this.popup(k("clubClaim"),l):this.toast(k("clubActive"),"info");break}case"sheet":s==="close"?this.closeSheet():this.openSheet(s);break;case"char":s==="view"?(this.viewChar=r,this.viewSkin=$n(r)?o.skins[r]:Ie(r).skins[0].id,this.renderSheet()):s==="select"?(oa(this.viewChar,this.viewSkin),rr(this.viewChar),a.game.celebrateLobby(),wt.play("buy")):s==="unlock"&&(cl(this.viewChar)?(wt.play("fanfare"),this.viewSkin=Ie(this.viewChar).skins[0].id,rr(this.viewChar),a.game.celebrateLobby()):this.notEnough("gems"));break;case"skin":if(s==="view")this.viewSkin=r,$n(this.viewChar)&&Ui(this.viewChar,r)&&oa(this.viewChar,r),this.renderSheet();else if(s==="buy"){let l=Ie(this.viewChar).skins.find(h=>h.id===this.viewSkin);if(!await this.confirm(k("costIs",{c:Je(l.cost)})))break;hl(this.viewChar,this.viewSkin)?(wt.play("fanfare"),rr(this.viewChar),a.game.celebrateLobby()):this.notEnough(l.cost.gems?"gems":"gold")}break;case"build":{let l=o.world,c=ll(l);if(!c.ok){this.notEnough(hi(l)&&o.gold<hi(l).gold?"gold":"gems");break}wt.play("build"),a.game.buildPulse(),a.syncLobby(),c.completed&&(wt.play("fanfare"),c.unlockedChar&&this.popup(k("newChar"),[],`<div class="unlock-big">${ru(Ie(c.unlockedChar).skins[0],90)}<h3>${ye(Ie(c.unlockedChar).name)}</h3></div>`),c.unlockedWorld&&this.popup(k("newWorld"),[],`<div class="unlock-big">${ht("map")}<h3>${ye(Gn(c.unlockedWorld).name)}</h3></div>`),c.rewards&&this.popup(k("complete"),c.rewards));break}case"world":{let l=Qe.filter(u=>ki(u.id));if(s==="go"){aa(r),a.syncLobby(),this.closeModal("worlds");break}let c=l.findIndex(u=>u.id===o.world),h=l[(c+(s==="next"?1:-1)+l.length)%l.length];aa(h.id),a.syncLobby();break}case"upgrade":ol(s)?wt.play("buy"):this.notEnough("gold");break;case"vault":{if(s==="wood")this.showVaultOpen(dl());else if(s==="start")ul(r);else if(s==="open")this.showVaultOpen(ca(r));else if(s==="instant"){let l=ca(r,!0);l?this.showVaultOpen(l):this.notEnough("batteries")}else if(s==="buySteel")la()<=0?this.toast(k("slotsFull"),"warn"):fl()?wt.play("buy"):this.notEnough("gold");else if(s==="diamond"){let l=pl(r==="gems");l?this.showVaultOpen(l):this.notEnough(r==="gems"?"gems":"batteries")}break}case"odds":s==="wheel"?this.showWheelOdds():this.showOdds(s);break;case"spin":this.spin(s==="paid");break;case"daily":{let l=vl();l&&this.popup(k("dailyTitle"),l);break}case"mission":{let l=Ml(+s);l&&this.popup(k("missionDone"),l);break}case"buy":bn.buy(s);break;case"gemoffer":{let l=sa.find(c=>c.id===s);l&&en({gems:l.gems})?(Be([l.give]),wt.play("buy"),this.toast(`+${fe(l.give.n)}`,"ok",{icon:l.give.k})):this.notEnough("gems");break}case"restore":bn.restore();break;case"set":a.toggleSetting(s);break;case"lang":a.setLanguage(s);break;case"quality":a.setQuality(s);break;case"privacy":this.info(k("privacy"),`<p class="msg">${k("privacyText")}</p>`);break;case"rate":a.rate();break;case"reset":await this.confirm(k("resetConfirm"))&&a.resetProgress();break;case"pause":a.pause();break;case"resume":this.closeModal("pause"),a.resume();break;case"restart":this.closeModal("pause"),a.endRun(!0);break;case"home":this.closeModal("pause"),a.endRun(!1);break;case"revive":if(s==="shop"){let l=this.modals.find(h=>h.id==="revive");l&&(l.paused=!0),this.openShop("gems");let c=this.modals.find(h=>h.id==="shop");c&&(c.opts.onClose=()=>{this.closeModal("revive"),clearInterval(this.reviveTimer);let h=this.reviveChoice;this.reviveChoice=null,this.openRevive(a.game.run.revives,h)})}else this.resolveRevive(s);break;case"results":if(s==="double"){let l=this.lastResult;en({gems:l.doubleCost})?(Be([{k:"gold",n:l.gold}]),l.doubled=!0,wt.play("reward"),this._renderModal(this.modals.find(c=>c.id==="results"))):this.notEnough("gems")}else s==="home"?(this.closeModal("results"),a.goLobby()):s==="again"&&(this.closeModal("results"),a.startRun());break;case"headstart":a.useHeadstart();break;default:break}}notEnough(t){wt.play("error"),this.toast(k("notEnough")+" "+k(t),"warn",{icon:t})}back(){if(this.modals.length){let t=this.topModal();return t.id==="revive"?(this.resolveRevive("skip"),!0):t.id==="results"?(this.closeModal("results"),this.app.goLobby(),!0):t.id==="pause"?(this.closeModal("pause"),this.app.resume(),!0):(t.busy||this.closeModal(),!0)}return this.sheet?(this.closeSheet(),!0):this.app.inRun()?(this.app.pause(),!0):!1}};var Jo=()=>window.EbotNative||null,kv=/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent),au=class{constructor(){let t=xu();sl(t);let e=t.settings;e.lang||(e.lang=(navigator.language||"ar").toLowerCase().startsWith("ar")||Jo()?"ar":"en"),e.quality||(e.quality=kv&&(navigator.hardwareConcurrency||4)<=4?"low":"high"),Ko(e.lang),wt.setSfx(e.sound),wt.setMusic(e.music),this.game=new Xo(document.getElementById("game"),this.hooks(),e.quality),this.ui=new Zo(this),this.syncLobby(),this.setupInput(),this.setupBilling(),this.setupLifecycle(),document.title=k("title"),me()}isAndroid(){return!!Jo()}inRun(){return this.game.mode==="run"&&this.game.run&&this.game.run.state!=="over"}syncLobby(){let t=Yt(),e=Gn(t.world);this.game.setLobby(e,Tn(e.id),ss())}previewSkin(t){let e=Yt(),n=Gn(e.world);this.game.setLobby(n,Tn(n.id),t)}hooks(){return{onTick:t=>{if(this.ui.updateHud(t),this._tick=(this._tick||0)+1,this._tick%30===0)for(let e of bl(t.stats))this.ui.toast(k("missionDone"),"gold",{icon:"missions"})},event:(t,e)=>this.onGameEvent(t,e),onCrash:({revives:t})=>{if(t>=Qs.length){this.finishRun();return}this.ui.openRevive(t,e=>{e?this.game.revive():this.finishRun()})},foundVault:()=>ar("steel"),vibrate:t=>{if(!Yt().settings.vibe)return;let e=Jo();try{e&&e.vibrate?e.vibrate(t):navigator.vibrate&&navigator.vibrate(t)}catch{}}}}onGameEvent(t,e){let n=this.ui;switch(t){case"toast":n.toast(e.key?k(e.key):e.text,e.kind||"info",{icon:e.icon,big:e.big,center:!0});break;case"thief":n.speech(k(e.key));break;case"powerup":n.toast(k("pu_"+e.type),"power",{icon:e.type,center:!0});break;case"boss":n.setBoss(e.phase,e);break;case"tutorial":n.tutorial(e.kind);break;case"tutorialDone":{let s=Yt();s.tutorialDone=!0,me(),n.toast(k("tutGo"),"gold",{big:!0,center:!0,dur:2200});break}case"headstartOffer":n.headstartOffer(e.show&&Yt().headstart>0,Yt().headstart);break;default:break}}startRun(){let t=Yt();wt.unlock();let e=t.char,n={};for(let s of["magnet","shield","jet","double"])n[s]=sr(s,e);this.ui.showHud(),this.game.startRun({world:Gn(t.world),skin:ss(e),durations:n,mult:Di(),doubler:t.iap.doubler,scoreBonus:is(e,"score"),tutorial:!t.tutorialDone,headstarts:t.headstart}),wt.startMusic("run")}useHeadstart(){let t=Yt();t.headstart<=0||this.game.useHeadstart()&&(t.headstart--,me())}pause(){!this.inRun()||this.game.paused||this.game.run.state==="crashed"||(this.game.pause(),this.ui.openPause())}resume(){this.game.resume()}finishRun(){let t=this.game.finishRun(),e=Yt();Be([{k:"gold",n:t.gold},{k:"gems",n:t.gems}],{silent:!0}),da({...t.stats,runs:1});let n=fa({score:t.score,dist:t.dist,gold:t.gold});return this.ui.showResults({...t,isBest:n,doubled:!1,doubleCost:Math.max(5,Math.ceil(t.gold/50))}),n&&wt.play("fanfare"),t}endRun(t){let e=this.game.finishRun();Be([{k:"gold",n:e.gold},{k:"gems",n:e.gems}],{silent:!0}),da({...e.stats,runs:1}),fa({score:e.score,dist:e.dist,gold:e.gold}),t?this.startRun():this.goLobby()}goLobby(){this.game.showLobby(),this.ui.closeAllModals(),this.syncLobby(),this.ui.showLobby(),wt.startMusic("lobby")}toggleSetting(t){let e=Yt().settings;e[t]=!e[t],t==="sound"&&wt.setSfx(e.sound),t==="music"&&wt.setMusic(e.music),me()}setLanguage(t){Yt().settings.lang=t,Ko(t),document.title=k("title"),me()}setQuality(t){Yt().settings.quality=t,this.game.setQuality(t),me()}rate(){let t=Jo();t&&t.openStorePage&&t.openStorePage()}resetProgress(){let t=Yt(),e=Kr();e.iap=t.iap,e.settings=t.settings,e.woodNext=Date.now(),al(e),Li(e),this.ui.closeAllModals(),this.syncLobby(),this.ui.renderLobby()}setupBilling(){let t=this.ui;bn.demoConfirm=e=>t.confirm(`${k("demoConfirm",{p:this.productName(e)})}<br><small>${k("demoStore")}</small>`),bn.init({grant:(e,n,s,r)=>this.grantPurchase(e,n,s,r),message:(e,n)=>t.toast(k(e),n==="error"?"warn":n==="ok"?"ok":"info",{center:!0}),onPrices:()=>t.refresh(),onReady:()=>t.refresh(),onRestore:e=>{let n=Yt();e.ok&&!(e.subsActive||[]).includes("ebot_club")&&n.iap.clubUntil>Date.now()&&(n.iap.clubUntil=Date.now(),me()),e.manual&&t.toast(k("restored"),"ok",{center:!0})}})}productName(t){return t.id.startsWith("gems_")?`${fe(t.grant[0].n)} ${k("gems")}`:t.id.startsWith("gold_")&&t.consumable?`${fe(t.grant[0].n)} ${k("gold")}`:k("p_"+t.id)}grantPurchase(t,e,n,s){let r=Yt(),a=r.iap.tokens.includes(n);if(t.type==="subs")return r.iap.clubUntil=Math.max(r.iap.clubUntil,Date.now()+2*24*3600*1e3),a||(r.iap.tokens.push(n),this.ui.popup(k("p_ebot_club"),[],`<p class="msg">${k("p_ebot_club_d")}</p>`)),me(),!a;if(a)return t.id==="starter_pack"&&(r.iap.starter=!0),t.entitlement==="doubler"&&(r.iap.doubler=!0),me(),!1;r.iap.tokens.push(n),r.iap.tokens.length>300&&(r.iap.tokens=r.iap.tokens.slice(-300)),t.id==="starter_pack"&&(r.iap.starter=!0),t.entitlement==="doubler"&&(r.iap.doubler=!0);let o=[];for(let c=0;c<e;c++)o.push(...t.grant);let l=Be(o,{silent:!0});return me(),Li(r),l.length?this.ui.popup(k("purchaseOk"),l):this.ui.popup(k("purchaseOk"),[],`<p class="msg">${k("p_"+t.id)}</p>`),!0}setupInput(){window.addEventListener("keydown",a=>{if(a.repeat)return;let o=a.key;if(o==="Escape"){this.ui.back();return}if(!this.inRun()||this.ui.modals.length)return;let l={ArrowLeft:"left",a:"left",A:"left",ArrowRight:"right",d:"right",D:"right",ArrowUp:"up",w:"up",W:"up"," ":"up",ArrowDown:"down",s:"down",S:"down"};l[o]&&(a.preventDefault(),this.game.input(l[o])),(o==="p"||o==="P")&&this.pause()});let t=0,e=0,n=!1,s=!1,r=26;window.addEventListener("pointerdown",a=>{!this.inRun()||this.ui.modals.length||a.target.closest("button")||(t=a.clientX,e=a.clientY,n=!0,s=!1)},{passive:!0}),window.addEventListener("pointermove",a=>{if(!n||s)return;let o=a.clientX-t,l=a.clientY-e;Math.max(Math.abs(o),Math.abs(l))<r||(s=!0,Math.abs(o)>Math.abs(l)?this.game.input(o>0?"right":"left"):this.game.input(l>0?"down":"up"))},{passive:!0}),window.addEventListener("pointerup",()=>{n=!1},{passive:!0}),window.addEventListener("pointercancel",()=>{n=!1},{passive:!0}),document.addEventListener("contextmenu",a=>a.preventDefault())}setupLifecycle(){window.ebotOnBack=()=>this.ui.back(),window.ebotOnPause=()=>{this.pause(),wt.suspend(),Li(Yt())},window.ebotOnResume=()=>{wt.resume()},window.ebotSetInsets=(t,e)=>{document.documentElement.style.setProperty("--safe-top",t+"px"),document.documentElement.style.setProperty("--safe-bottom",e+"px")},document.addEventListener("visibilitychange",()=>{document.hidden?(this.pause(),wt.suspend(),Li(Yt())):wt.resume()}),window.addEventListener("pagehide",()=>Li(Yt()))}};function Cf(){let i=document.getElementById("splash"),t;try{t=new au,window.__ebot=t,window.__ebotPR=pa}catch(n){console.error(n),i.querySelector(".hint").textContent="Error: "+n.message;return}i.querySelector(".bar i").style.width="100%",i.querySelector(".hint").textContent=k("tapToStart"),i.querySelector("h1").textContent=k("title"),i.querySelector(".sub").textContent=k("subtitle"),i.classList.add("ready");let e=()=>{i.removeEventListener("pointerup",e),wt.unlock(),wt.startMusic("lobby"),i.classList.add("out"),setTimeout(()=>i.remove(),500),t.ui.showLobby()};if(i.addEventListener("pointerup",e),window.EbotNative&&window.EbotNative.appReady)try{window.EbotNative.appReady()}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Cf):Cf();})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2024 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
