EBOT Gold Chase - offline web build / ايبوت: مطاردة الذهب - نسخة ويب أوفلاين

Open index.html with a double-click (Chrome, Edge, Firefox, Safari). No internet, server or database needed.
افتح الملف index.html بنقرة مزدوجة. لا يحتاج إنترنت ولا خادم ولا قاعدة بيانات.

Progress is saved in this browser only. The store in the web build is a demo (no payment).
يُحفظ التقدم في هذا المتصفح فقط. المتجر في نسخة الويب تجريبي بدون دفع.
